﻿<%@ Page Title="" Language="C#" MasterPageFile="~/LibroFly.Master" AutoEventWireup="true" CodeBehind="InicioSesion.aspx.cs" Inherits="LibroFlyWA.InicioSesion" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="cph_Contenido" runat="server">
     <div class="container d-flex justify-content-center align-items-center" style="margin-top: 5rem" >
        <div class="card p-4" style="width: 100%; max-width: 400px;">
            <h3 class="card-title text-center mb-4">Inicio de Sesión</h3>
                <div class="form-group">
                    <label for="txtUsername">Usuario</label>
                    <asp:TextBox ID="txtCorreo" runat="server" CssClass="form-control" placeholder="Ingrese su usuario"></asp:TextBox>
                </div>
                <div class="form-group mt-3">
                    <label for="txtPassword">Contraseña</label>
                    <asp:TextBox ID="txtPassword" runat="server" TextMode="Password" CssClass="form-control" placeholder="Ingrese su contraseña"></asp:TextBox>
                </div>
                <div class="form-group mt-2">
                    <asp:Label ID="lblExito" runat="server" CssClass="text-success text-center d-block" EnableViewState="false"></asp:Label>
                    <asp:Label ID="lblMensaje" runat="server" CssClass="text-danger text-center d-block" EnableViewState="false"></asp:Label>
                </div>
                <div class="text-center mt-3">
                    <asp:Button ID="btnLogin" runat="server" Text="Ingresar" OnClick="btnLogin_Click" CssClass="btn btn-primary w-100" BorderColor="#F59106" BackColor="#F59106"/>
                </div>
                <div class="text-center mt-3">
                    <asp:Button ID="btnRegistrar" runat="server" Text="Registrarse" CssClass="btn btn-primary w-100" BorderColor="#F59106" BackColor="#F59106" OnClick="btnRegistrar_Click"/>
                </div>
        </div>
    </div>
</asp:Content>
