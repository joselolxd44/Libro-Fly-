﻿<%@ Page Title="" Language="C#" MasterPageFile="~/LibroFly.Master" AutoEventWireup="true" CodeBehind="RegistrarUsuario.aspx.cs" Inherits="LibroFlyWA.RegistrarUsuario" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="cph_Contenido" runat="server">
    <div class="container p-4">
        <div class="card-header">
            <h2 class="m-auto text-center">
                <asp:Label ID="lblTitulo" runat="server" Text="REGISTRAR"></asp:Label>
            </h2>
        </div>
        <div class="card-body m-auto mt-4 w-75">
            <div class="d-block col-7 w-100">
                <div style="width: 30%" class="mt-3 w-100">
                    <asp:TextBox BorderWidth="2px" ID="txtNombres" CssClass="form-control" runat="server" placeholder="Nombres"></asp:TextBox>
                </div>
                <div style="width: 30%" class= "mt-3 w-100">
                    <asp:TextBox BorderWidth="2px" ID="txtApellidos" CssClass="form-control" runat="server" placeholder="Apellidos"></asp:TextBox>
                </div>
                <div class="d-flex align-items-center col-4 w-100">
                    <div style="width: 30%" class="m-3">
                        <asp:Label ID="lblTipoDoc" runat="server" Text="Tipo de Documento"></asp:Label>
                        <asp:DropDownList CssClass="form-select" ID="ddlTipoDoc" runat="server"></asp:DropDownList>
                    </div>

                    <div style="width: 60%" class="m-3">
                        <asp:TextBox BorderWidth="2px" ID="txtNumdocumento" CssClass="form-control" runat="server" placeholder="Numero de Documento" style="margin-top:25px;"></asp:TextBox>
                    </div>
                </div>
                </div>
                <div style="width: 30%" class="mt-3 w-100">
                    <asp:TextBox BorderWidth="2px" ID="txtDireccion" CssClass="form-control" runat="server" placeholder="Direccion"></asp:TextBox>
                </div>
                <div style="width: 30%" class="mt-3 w-100">
                    <asp:TextBox BorderWidth="2px" ID="txtTelefono" CssClass="form-control" runat="server" placeholder="Telefono"></asp:TextBox>
                </div>
                <div style="width: 30%" class="mt-3 w-100">
                    <asp:TextBox BorderWidth="2px" ID="txtCorreoElectronico" CssClass="form-control" runat="server" placeholder="Correo Electronico"></asp:TextBox>
                </div>
                <div style="width: 30%" class="mt-3 w-100">
                    <asp:TextBox BorderWidth="2px" ID="txtContrasenha" CssClass="form-control" runat="server" TextMode="Password" placeholder="Contraseña"></asp:TextBox>
                </div>
                <div style="width: 30%" class="mt-3 w-100">
                    <asp:TextBox BorderWidth="2px" ID="txtContraRep" CssClass="form-control" runat="server" TextMode="Password" placeholder="Confirmar contraseña"></asp:TextBox>
                </div>
            <div style="width:fit-content" class="d-flex col-2 m-auto mt-3">
                    <asp:Button  Width="200px" BackColor="#F59106" CssClass="btn text-white m-3" ID="btnAddBook" runat="server" Text="REGISTRAR" OnClick="btnRegistrarNuevo_Click"/>
                    <asp:Button Width="200px" CssClass="btn btn-danger m-3" ID="btnCancelBook" runat="server" Text="CANCELAR" />
            </div>
            <asp:Label ID="lblError" runat="server" ForeColor="Red"></asp:Label>
</asp:Content>
