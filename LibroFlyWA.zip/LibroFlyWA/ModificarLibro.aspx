﻿<%@ Page Title="" Language="C#" MasterPageFile="~/LibroFly.Master" AutoEventWireup="true" CodeBehind="ModificarLibro.aspx.cs" Inherits="LibroFlyWA.ModificarLibro" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="cph_Contenido" runat="server">
    <div class="container p-4">
    <div class="card-header">
        <h2 class="m-auto text-center">
            <asp:Label ID="lblTitulo" runat="server" Text="MODIFICAR LIBRO"></asp:Label>
        </h2>
    </div>
    <div class="card-body mt-4">
        <div class="d-flex col-2 w-100">
            <div style="width: 60%" class="m-4">
                <asp:Label ID="Label1" runat="server" Text="Titulo "></asp:Label>
                <asp:TextBox ID="txtTituloLibro" CssClass="form-control" runat="server" Enabled="false"></asp:TextBox>
            </div>
            <div style="width: 45%" class="m-4">
                <asp:Label ID="lblAutor" runat="server" Text="Autor/Autores"></asp:Label>
                <asp:TextBox ID="txtAutor" CssClass="form-control" runat="server" Enabled="false"></asp:TextBox>
            </div>
        </div>
        <div class="d-flex col-3 w-100">
            <div style="width: 100%" class="m-4">
                <asp:Label ID="LabelDescripcion" runat="server" Text="Descripción del libro"></asp:Label>
                <asp:TextBox ID="txtDescripcion" CssClass="form-control" runat="server" Enabled="false"></asp:TextBox>
            </div>
        </div>
        <div class="d-flex col-4 w-100">
            <div style="width: 30%" class="m-4">
                <asp:Label ID="LabelAnho" runat="server" Text="Año"></asp:Label>
                <asp:TextBox ID="txtAnho" CssClass="form-control" runat="server" Enabled="false"></asp:TextBox>
            </div>
            <div style="width: 30%" class="m-4">
                <asp:Label ID="LabelPeso" runat="server" Text="Peso"></asp:Label>
                <asp:TextBox ID="txtPeso" CssClass="form-control" runat="server" Enabled="false"></asp:TextBox>
            </div>
            <div style="width: 30%" class="m-4">
                <asp:Label ID="LabelAncho" runat="server" Text="Ancho"></asp:Label>
                <asp:TextBox ID="txtAncho" CssClass="form-control" runat="server" Enabled="false"></asp:TextBox>
            </div>
            <div style="width: 25%" class="m-4">
                <asp:Label ID="LabelAlto" runat="server" Text="Alto"></asp:Label>
                <asp:TextBox ID="txtAlto" CssClass="form-control" runat="server" Enabled="false"></asp:TextBox>
            </div>
            <div style="width: 30%" class="m-4">
                <asp:Label ID="LabelNumPag" runat="server" Text="Número de páginas"></asp:Label>
                <asp:TextBox TextMode="Number" ID="txtNumPag" CssClass="form-control" runat="server" Enabled="false"></asp:TextBox>
            </div>
        </div>
        <div class="d-flex col-5 w-100">
            <div style="width: 30%" class="m-4">
                <asp:Label ID="lblGenero" runat="server" Text="Genero"></asp:Label>
                <asp:TextBox ID="txtGenero" CssClass="form-control" runat="server" Enabled="false"></asp:TextBox>
            </div>
            <div style="width: 30%" class="m-4">
                <asp:Label ID="lblEditorial" runat="server" Text="Editorial"></asp:Label>
                <asp:TextBox ID="txtEditorial" CssClass="form-control" runat="server" Enabled="false"></asp:TextBox>
            </div>
            <div style="width: 30%" class="m-4">
                <asp:Label ID="lblIsbn" runat="server" Text="Isbn"></asp:Label>
                <asp:TextBox ID="txtIsbn" CssClass="form-control" runat="server" Enabled="false"></asp:TextBox>
            </div>
            <div style="width: 25%" class="m-4">
                <asp:Label ID="lblPrecio" runat="server" Text="Precio"></asp:Label>
                <asp:TextBox ID="txtPrecio" CssClass="form-control" runat="server"></asp:TextBox>
            </div>
            <div style="width: 30%" class="m-4">
                <asp:Label ID="lblStock" runat="server" Text="Stock"></asp:Label>
                <asp:TextBox TextMode="Number" ID="txtStock" CssClass="form-control" runat="server"></asp:TextBox>
            </div>
        </div>
        <div class="d-flex col-6 w-100">
            <div style="width: 30%" class="m-4">
                <asp:Label ID="LabelFormato" runat="server" Text="Formato"></asp:Label>
                <asp:TextBox ID="txtFormato" CssClass="form-control" runat="server"></asp:TextBox>
            </div>
            <div style="width: 30%" class="m-4">
                <asp:Label ID="LabelUrlImg" runat="server" Text="Url de la portada"></asp:Label>
                <asp:TextBox ID="txtUrl" CssClass="form-control" runat="server"></asp:TextBox>
            </div>
            </div>
        <div style="width:fit-content" class="d-flex col-2 m-auto   ">
                <asp:Button  Width="200px" BackColor="#F59106" CssClass="btn text-white m-3" ID="btnAddBook" OnClick="btnAddBook_Click" runat="server" Text="GUARDAR" />
                <asp:Button Width="200px" BorderColor="Black" BorderWidth="2px" CssClass="btn btn-close-white m-3" ID="btnCancelBook" OnClick="btnCancelBook_Click" runat="server" Text="CANCELAR" />
                <asp:Button Width="200px" CssClass="btn btn-danger m-3" ID="BtnEliminarLibro" OnClick="BtnEliminarLibro_Click"  runat="server" Text="ELIMINAR" />
        </div>
        <asp:Label ID="lblError" runat="server" ForeColor="Red"></asp:Label>
    </div>
</div>
</asp:Content>
