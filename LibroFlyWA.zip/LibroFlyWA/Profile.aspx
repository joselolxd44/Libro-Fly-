﻿<%@ Page Title="" Language="C#" MasterPageFile="~/LibroFly.Master" AutoEventWireup="true" CodeBehind="Profile.aspx.cs" Inherits="LibroFlyWA.Profile" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Cuenta Personal
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
   
</asp:Content>
<asp:Content ID="cph_Contenido" ContentPlaceHolderID="cph_Contenido" runat="server">
    <div class="d-flex col-3 mt-5" style="width:95%">
        <div class="w-25">
            
            <div class="d-block">
                <i class='fa-solid fa-user m-auto w-100 h-100 text-center' style='color: #F59106; font-size:100px'></i>
                <div class="m-auto mt-2" style="width: fit-content">
                    <asp:Label CssClass="w-100 fs-4" ID="lblNombres" runat="server" Text="Nombres"></asp:Label>
                </div>
                <div class="mt-3 d-block">
                    <div class="m-auto mt-3" style="width: fit-content">
                        DNI: 
                        <asp:Label ID="lblDNI" runat="server" Text="Nombres"></asp:Label>
                    </div>
                    <div class="m-auto mt-2" style="width: fit-content">
                        Direccion: 
                        <asp:Label ID="lblDireccion" runat="server" Text="Nombres"></asp:Label>
                    </div>
                    <div class="m-auto mt-2" style="width: fit-content">
                        Telefono: 
                        <asp:Label ID="lblNumero" runat="server" Text="Nombres"></asp:Label>
                    </div>
                    <div class="m-auto mt-2" style="width: fit-content">
                        <b>Correo electronico</b>: 
                        <asp:Label ID="lblCorreo" runat="server" Text="Nombres"></asp:Label>
                    </div>
                    <div class="m-auto mt-2" style="width: fit-content">
                        <asp:Button  Width="200px" BackColor="#F59106" CssClass="btn text-white m-3" ID="btnEditarPerfil" 
                            OnClick="btnEditarPerfil_Click" runat="server" Text="EDITAR" />
                    </div>
                </div>
            </div>
        </div>
        
        <div class="w-50 ">
            <asp:Label ID="lblMensaje" runat="server" CssClass="d-block text-center" />
            <div class="container row p-5 m-3" style="border: solid; border-color:#F59106; border-radius: 20px; width:95%">
                <h3>Historial de pedidos</h3>
                <asp:GridView ID="dgvClientePedidos" runat="server" AutoGenerateColumns="false"
                    OnRowDataBound="dgvClientePedidos_RowDataBound"  Enabled="true"
                    CssClass="table table-hover table-responsive table-striped mt-3">
                    <Columns>
                        <asp:BoundField HeaderText="FECHA" ControlStyle-CssClass="align-middle"/>
                        <asp:BoundField HeaderText="ESTADO" ControlStyle-CssClass="align-middle"/>
                        <asp:BoundField HeaderText="TOTAL" ControlStyle-CssClass="align-middle"/>
                    </Columns>
                </asp:GridView>
            </div>
        </div>
        
        <div class="w-25">
             <div class="container row p-5 m-3" style="border: solid; border-color:#F59106; border-radius: 20px">
                <h3>Géneros más comprados</h3>
                 <div>
                    <asp:ListView ID="dgvGenerosMasVendidos" GroupItemCount="1" runat="server">
                        <GroupTemplate>
                            <tr>
                                <asp:PlaceHolder runat="server" ID="itemPlaceholder" />
                            </tr>
                        </GroupTemplate>
                        <LayoutTemplate>
                            <table class="w-100">
                                <asp:PlaceHolder ID="groupPlaceholder" runat="server" />
                            </table>
                        </LayoutTemplate>
                        <ItemTemplate>
                            <td class=" d-flex mt-3" style="height:200px">
                                <div class="container-sm w-100" style="display:flex">
                                     <asp:Label ID="lblNombreGenero" CssClass="w-100" runat="server" Text='<%# Eval("descripcion") %>'></asp:Label><br />
                                </div>
                            </td>
                        </ItemTemplate>
                    </asp:ListView>
                    <hr />
                </div>
            </div>
        </div>
    </div>
</asp:Content>
