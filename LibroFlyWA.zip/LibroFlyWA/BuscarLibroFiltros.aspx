﻿<%@ Page Title="" Language="C#" MasterPageFile="~/LibroFly.Master" AutoEventWireup="true" CodeBehind="BuscarLibroFiltros.aspx.cs" Inherits="LibroFlyWA.BuscarLibroFiltros" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="cph_Contenido" runat="server">
    <style>
        .custom-radio-list td {
            display: flex;
            width: 100%;
        }

        .custom-radio-list label {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size : 17.5px;
            width: 100%; /* Asegura que ocupe todo el ancho de la celda */
        }

        .custom-radio-list input[type="radio"] {
            margin-left: auto; /* Empuja el círculo al final */
            -webkit-appearance: none; /* Elimina el estilo predeterminado */
            -moz-appearance: none;    /* Para navegadores Mozilla */
            appearance: none;         
            width: 20px;              
            height: 20px;             
            border: 1px solid #555;  
            border-radius: 2px;         
            outline: none;            
            cursor: pointer;          
        }

        .custom-radio-list input[type="radio"]:checked {
            background-color: #F59106; 
            border-color: #555;     
        }

        h2 {
            color: #F59106;
        }
    </style>
    <div class="d-flex m-auto" style="width:90%">
        <div class="d-block w-25">
            <div class="w-100 m-auto">
                <div class="w-100 text-center">
                    <h2>Géneros</h2>
                 
                    <asp:RadioButtonList CssClass="w-100 custom-radio-list" TextAlign="Left" CellPadding="2" ID="dgvGenerosFiltros" runat="server">
                    </asp:RadioButtonList>
                </div>
            </div>
            <div class="w-100 m-auto d-block mt-3">
                <div class="w-100 text-center">
                    <h2>Precio</h2>
                </div>
                <div class="w-100 d-flex align-items-center">
                    <span class="w-50">Precio Inicial: </span>
                    <asp:TextBox TextMode="Number" ID="txtPrecioInicial" CssClass="w-50 form-control end-100" runat="server"></asp:TextBox>
                </div>
                <div class="d-flex mt-3">
                    <span class="w-50 start-0">Precio Final: </span>
                    <asp:TextBox TextMode="Number" ID="txtPrecioFinal" CssClass="w-50 form-control end-100" runat="server"></asp:TextBox>
                </div>
            </div>
        </div>
        <div class="container mt-2">
            <asp:Label ID="lblMensaje" runat="server" CssClass="d-block text-center" />

            <!-- Buscando por título -->
            <div class="m-auto d-flex align-items-center"  style="width:85%">
                <label style="width:10%" class="text-start"><b>Autor: </b></label> 
                <input class="form-control" type="Search" placeholder="Autor del libro" aria-label="Search" />
            </div>

            <!-- List de Libros -->
            <asp:ListView ID="dgvLibros" OnItemDataBound="lvItems_ItemDataBound" runat="server" GroupItemCount="4">
                <GroupTemplate>
                    <tr>
                      <asp:PlaceHolder runat="server" ID="itemPlaceholder" />
                    </tr>
                </GroupTemplate>
                <LayoutTemplate>
                    <table class="w-100">
                      <asp:PlaceHolder ID="groupPlaceholder" runat="server" />
                    </table>
                </LayoutTemplate>
                <ItemTemplate>
                    <td class="w-25 text-center m-auto p-4">
                      <div class="d-block">
                          <!--<img class="w-50 h-auto" src="https://i.pinimg.com/564x/25/9e/ee/259eeeb138f099368003026a868704d3.jpg"/> -->
                          <asp:ImageButton CssClass="w-50 h-auto" ImageUrl="https://i.pinimg.com/564x/25/9e/ee/259eeeb138f099368003026a868704d3.jpg" ID="btnBookSelected" runat="server" CommandArgument='<%# Eval("id_libro") %>' OnClick="btnMostrarLibroImage_Click"/>
                          <br />
                          <asp:LinkButton CssClass="w-100 text-decoration-none text-black" ID="btnLibro" runat="server" Text='<%# Eval("titulo") %>' CommandArgument='<%# Eval("id_libro") %>'
                              OnClick="lblMostrarLibro_Click"
                              >LinkButton</asp:LinkButton><br />
                          <div class="w-100 text-center">
                              <b>S/.</b>
                              <asp:Label  ID="Label1" runat="server"
                                    Text='<%# Eval("precio") %>'/> <br />
                          </div>
                          <div class="w-100 m-auto" >
                              <asp:Button ID="btnModificar" CommandArgument='<%# Eval("id_libro") %>' OnClick="btnModificar_Click" Visible="false" Width="200px" BackColor="#F59106" CssClass="end-100 btn text-white m-3" 
                                    runat="server" Text="MODIFICAR" />
                          </div>
                      </div>
                    </td>
                  </ItemTemplate>
            </asp:ListView>
        </div>
    </div>
</asp:Content>
