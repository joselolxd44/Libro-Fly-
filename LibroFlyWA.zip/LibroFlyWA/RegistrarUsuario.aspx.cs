﻿using LibroFlyWA.GeneroWS;
using LibroFlyWA.UsuarioWS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibroFlyWA
{
    public partial class RegistrarUsuario : System.Web.UI.Page
    {
        private UsuarioWSClient usuarioWSClient;
        BindingList<string> listaTiposDocumento;
        protected void Page_Load(object sender, EventArgs e)
        {
            usuarioWSClient = new UsuarioWSClient();
            listaTiposDocumento = new BindingList<string>(usuarioWSClient.listarTiposDocumento());
            ddlTipoDoc.DataSource = listaTiposDocumento;
            ddlTipoDoc.DataBind();
        }

        protected void btnRegistrarNuevo_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombres.Text) ||
                string.IsNullOrWhiteSpace(txtApellidos.Text) ||
                string.IsNullOrWhiteSpace(txtContrasenha.Text) ||
                string.IsNullOrWhiteSpace(txtCorreoElectronico.Text) ||
                string.IsNullOrWhiteSpace(txtDireccion.Text) ||
                string.IsNullOrWhiteSpace(txtNumdocumento.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text))
            {
                lblError.Text = "Todos los campos de texto son obligatorios.";
                return;
            }
            string contraseña = txtContrasenha.Text;
            string contraseñaRepetida = txtContraRep.Text;
            if (!contraseña.Equals(contraseñaRepetida))
            {
                lblError.Text = "Las contraseñas no coinciden.";
                return;
            }
            usuariosDTO usuario = new usuariosDTO();
            usuario.nombres = txtNombres.Text;
            usuario.apellidos = txtApellidos.Text;
            usuario.contrasenha = txtContrasenha.Text;
            usuario.correo = txtCorreoElectronico.Text;
            usuario.direccion_envio = txtDireccion.Text;
            int seleccionadoIndex = ddlTipoDoc.SelectedIndex;
            listaTiposDocumento = new BindingList<string>(usuarioWSClient.listarTiposDocumento());
            string tipo_documento = listaTiposDocumento[seleccionadoIndex];
            //string tipo_documento = txtTipoDocumento.Text;
            //List<String> nombresGeneros = listaTiposDocumento.ToList();
            usuario.numero_documento = txtNumdocumento.Text;
            usuario.telefono = txtTelefono.Text;
            usuario.rol = "";
            usuario.tipo = "CLIENTE";
            int resultado = usuarioWSClient.regitrarUsuario(usuario.correo,usuario.contrasenha,usuario.nombres,usuario.apellidos,
                usuario.direccion_envio,usuario.telefono,tipo_documento,usuario.numero_documento,usuario.rol,usuario.tipo);
            if(resultado != 0)
                Response.Redirect("InicioSesion.aspx?mensaje=exito");
        }
    }
}