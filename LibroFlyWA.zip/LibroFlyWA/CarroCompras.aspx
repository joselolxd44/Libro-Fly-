﻿<%@ Page Title="" Language="C#" MasterPageFile="~/LibroFly.Master" AutoEventWireup="true" CodeBehind="CarroCompras.aspx.cs" Inherits="LibroFlyWA.CarroCompras" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <script src="Scripts/LibroFly/finalizarCompra.js"></script>
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="cph_Contenido" runat="server">

    <div style="width:80%;height:fit-content" class="m-auto d-flex align-content-center">
        <div class="w-75 p-5 m-3" style="border: solid; border-color:#F59106; border-radius: 20px; height:fit-content">
            <asp:Label ID="lblNumeroProductos" runat="server" Text="0"></asp:Label>
            <asp:Label ID="lblCarritoProductos" runat="server" Text=" Libros en el Carrito de Compras"></asp:Label>
            <hr />
            <div>
                <asp:ListView ID="dgvProductosCarrito" GroupItemCount="1" runat="server">
                    <GroupTemplate>
                        <tr>
                            <asp:PlaceHolder runat="server" ID="itemPlaceholder" />
                        </tr>
                    </GroupTemplate>
                    <LayoutTemplate>
                        <table class="w-100">
                            <asp:PlaceHolder ID="groupPlaceholder" runat="server" />
                        </table>
                    </LayoutTemplate>
                    <ItemTemplate>
                        <td class=" d-flex mt-3" style="height:200px">
                            <div class="container-sm w-100" style="display:flex">
                                    <div class="w-auto">
                                        <img class="h-100" src="https://th.bing.com/th/id/OIP.Avjupdy0kshKFGl_7kyPRQHaLF?r=0&rs=1&pid=ImgDetMain&cb=idpwebp1&o=7&rm=3"/>
                                    </div>
                                    <div class="w-75 align-content-center" style="margin-left: 20px; display:">
                                        <asp:Label ID="lblTitulo" CssClass="h-25 w-100" runat="server" Text='<%# Eval("libro.titulo") %>'></asp:Label><br />
                                        <span><b>Cantidad: </b></span>
                                        <asp:Label ID="lblCantidadProducto" CssClass="h-25 w-100 text-end" runat="server" Text='<%# Eval("cantidad") %>'></asp:Label><br />
                                        <span><b>Precio: </b>S/.</span>
                                            <asp:Label ID="Label3" CssClass="h-25 w-100" runat="server" Text='<%# CalcularPrecioFinal(Container.DataItem) %>'></asp:Label><br />
                                        <asp:LinkButton ID="btnQuitar" runat="server" Text="Quitar libro" CssClass="btn text-white w-50 mt-2" Style="background-color:#F59106" OnClick="btnQuitarLibro_Click" CommandArgument='<%# Eval("libro.id_libro") %>' />
                                    
                                    </div>
                            </div>
                        </td>
                    </ItemTemplate>
                </asp:ListView>
                <hr />
            </div>
        </div>
        <div class="w-50">
            <div class="w-100 p-5 m-3 d-block" style="border: solid; border-color:#F59106; border-radius: 20px">
                <asp:Label ID="Label2" runat="server" Text="RESUMEN DE COMPRA"></asp:Label>
                <hr />
                <div class="w-100 d-flex">
                    <asp:Label ID="lblPrecioLibros" CssClass="w-75" runat="server" Text="Precio total de los libros: "></asp:Label>
                    <asp:Label ID="lblPrecioLibrosValor" CssClass="w-25 text-end" runat="server" Text="0.0"></asp:Label>
                </div>
                <div class="w-100 d-flex">
                    <asp:Label ID="lblIGV" CssClass="w-75" runat="server" Text="IGV"></asp:Label>
                    <asp:Label ID="lblIGVValor" CssClass="text-end w-25" runat="server" Text="0.0"></asp:Label>
                </div>
                <hr />
                <div class="w-100 d-flex">
                    <asp:Label ID="lblPrecioFinal" CssClass="w-75" runat="server" Text="Precio Final"></asp:Label>
                    <asp:Label ID="lblPrecioFinalValor" CssClass="text-end w-25" runat="server" Text="0.0"></asp:Label>
                </div>
            </div>
            <div class="text-center w-100 p-4 m-3 d-block" style="border: solid; border-color:#F59106; border-radius: 20px; font-size:20px">
                <asp:Label ID="Label1" CssClass="text-center fw-bold" runat="server" Text="METODO DE PAGO"></asp:Label>
                <hr />
                <div class="w-100 d-flex">
                    <asp:Label ID="Label5" CssClass="text-start w-75" runat="server" Text="Pago con Tarjeta Visa"></asp:Label>
                    <asp:RadioButton ID="rbPagoTarjeta" CssClass="w-25 text-end" GroupName="metodo" runat="server" />
                </div>
                <div class="w-100 d-flex">
                    <asp:Label ID="Label6" CssClass="text-start w-75" runat="server" Text="Pago en Tienda"></asp:Label>
                    <asp:RadioButton ID="rbPagoTienda" CssClass="w-25 text-end" BorderColor="#F59106" GroupName="metodo" runat="server" />
                </div>
            </div>
            <div class="text-center w-100 p-0 m-3 d-block">
                <asp:LinkButton CssClass="btn text-white w-50 mt-2" OnClick="BtnComprar" BackColor="#F59106" ID="Button1" runat="server" Text="FINALIZAR COMPRA" />
            </div>
        </div>
    </div>
    <div class="modal fade" id="modalPago" tabindex="-1" aria-labelledby="modalPagoLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content payment-form">
                <div class="modal-header">
                    <h2 class="modal-title" id="modalPagoLabel">Pago con Tarjeta</h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" class="form-control" placeholder="test@example.com" required>
                    </div>
                    <div class="form-group">
                        <label for="card-info">Card Information</label>
                        <input type="text" id="card-info" class="form-control" placeholder="4242 4242 4242 4242" required>
                    </div>
                    <div class="form-group">
                        <label for="expiry">Expiry Date</label>
                        <input type="text" id="expiry" class="form-control" placeholder="MM / YY" required>
                    </div>
                    <div class="form-group">
                        <label for="cvc">CVC</label>
                        <input type="text" id="cvc" class="form-control" placeholder="123" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Name on Card</label>
                        <input type="text" id="name" class="form-control" placeholder="Zhang San" required>
                    </div>
                    <div class="form-group">
                        <label for="country">Country or Region</label>
                        <select id="country" class="form-select" required>
                            <option value="US">United States</option>
                            <option value="PE">Peru</option>
                            <option value="MX">Mexico</option>
                            <!-- Agrega más países si es necesario -->
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                     <asp:LinkButton Onclick="btnTerminarCompra" runat="server" ID="txtTermCompra" class="btn btn-primary" Text="Pay 🔒"/>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
