﻿using LibroFlyWA.UsuarioWS;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibroFlyWA
{
    public partial class Profile : System.Web.UI.Page
    {
        private List<pedidosDTO> pedidos;
        private List<generosDTO> generos;
        private UsuarioWSClient usuarioWSClient;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["mensaje"] == "exito")
            {
                lblMensaje.Text = "¡El usuario fue modificado con exito!";
                lblMensaje.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                if (Request.QueryString["mensaje"] == "compra")
                {
                    lblMensaje.Text = "¡Compra realizada exitosamente!";
                    lblMensaje.ForeColor = System.Drawing.Color.Green;
                }
            }
            usuariosDTO usuario = (usuariosDTO)Session["usuario"];
            if(usuario == null)
            {
                Response.Redirect("InicioSesion.aspx");
            }else
            {
                

                usuarioWSClient = new UsuarioWSClient();
                lblNombres.Text = usuario.nombres;
                lblCorreo.Text = usuario.correo;
                lblNumero.Text = usuario.telefono;
                lblDireccion.Text = usuario.direccion_envio;
                lblDNI.Text = usuario.numero_documento;
                try
                {
                    //generos = usuarioWSClient.generosPorUsuario(usuario.id_usuario).ToList();
                    pedidos = usuarioWSClient.listarPedidosUsuario(usuario.id_usuario).ToList();
                    dgvClientePedidos.DataSource = pedidos;
                    dgvClientePedidos.DataBind();
                    dgvGenerosMasVendidos.DataSource = generos;
                    dgvGenerosMasVendidos.DataBind();
                }
                catch (Exception ex) { 
                    dgvClientePedidos.Enabled = false;
                }
                

            }
                
        }

        protected void dgvClientePedidos_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow) {
                e.Row.Cells[0].Text = DataBinder.Eval(e.Row.DataItem, "fecha").ToString();
                e.Row.Cells[1].Text = DataBinder.Eval(e.Row.DataItem, "estado").ToString();
                //e.Row.Cells[2].Text = DataBinder.Eval(e.Row.DataItem, "cantidad").ToString();
                e.Row.Cells[2].Text = DataBinder.Eval(e.Row.DataItem, "total").ToString();
            }
        }

        protected void btnEditarPerfil_Click(object sender, EventArgs e)
        {
            Response.Redirect("ModificarUsuario.aspx");
        }
    }
}