﻿let modalForm;
function mostrarModalPago() {
    modalForm = new bootstrap.Modal(document.getElementById('modalPago'));
    modalForm.show();
}