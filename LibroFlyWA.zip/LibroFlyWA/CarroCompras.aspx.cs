﻿using LibroFlyWA.CarritoWS;
using LibroFlyWA.LibroFlyWS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibroFlyWA
{
    public partial class CarroCompras : System.Web.UI.Page
    {
        private CarritoWSClient carritoWSClient = new CarritoWSClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            UsuarioWS.usuariosDTO usuario = (UsuarioWS.usuariosDTO)Session["usuario"];
            if(usuario == null)
            {
                Response.Redirect("InicioSesion.aspx");
            }else
            {
                if(!IsPostBack)
                {
                    LoadProductos();
                }
            }
        }

        protected void LoadProductos()
        {
            //List<Tuple<LibroFlyWS.librosDTO, int, double>> productos = (List<Tuple<LibroFlyWS.librosDTO, int, double>>)Session["productosSeleccionados"];
            UsuarioWS.usuariosDTO usuario = (UsuarioWS.usuariosDTO)Session["usuario"];
            CarritoWS.lineasCarritoDTO[] lista = carritoWSClient.listarCarritoUsuario(usuario.id_usuario);
            if(lista != null)
            {
                List<CarritoWS.lineasCarritoDTO> productos = lista.ToList();
                dgvProductosCarrito.DataSource = productos;
                dgvProductosCarrito.DataBind();
                lblNumeroProductos.Text = productos.Count.ToString();
                lblPrecioLibrosValor.Text = productos.Sum(linea => linea.libro.precio * linea.cantidad).ToString();
                lblPrecioFinalValor.Text = lblPrecioLibrosValor.Text;
            }
        }

        protected float CalcularPrecioFinal(Object item)
        {
            CarritoWS.lineasCarritoDTO linea = (CarritoWS.lineasCarritoDTO)item;
            return linea.libro.precio * linea.cantidad;
        }

        protected void BtnComprar(object sender, EventArgs e)
        {
            try
            {
                if (rbPagoTarjeta.Checked)
                {
                    CallJavascritp("");
                }
                else
                {
                    Response.Redirect("Profile.aspx?mensaje=compra");
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void CallJavascritp(string function)
        {
            string script = "mostrarModalPago();";
            ScriptManager.RegisterStartupScript(this, GetType(), "modalPago", script, true);
        }

        protected void btnQuitarLibro_Click(Object sender, EventArgs e)
        {
            UsuarioWS.usuariosDTO usuario = (UsuarioWS.usuariosDTO)Session["usuario"];
            int idLibro = Int32.Parse(((LinkButton)sender).CommandArgument);
            carritoWSClient.eliminarLineaCarrito(usuario.id_usuario, idLibro);
            Response.Redirect("CarroCompras.aspx");
        }

        protected void btnTerminarCompra(object sender, EventArgs e)
        {
            Response.Redirect("Profile.aspx?mensaje=compra");
        }

    }
}