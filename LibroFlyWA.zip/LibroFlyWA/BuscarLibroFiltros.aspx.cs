﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LibroFlyWA.GeneroWS;
using LibroFlyWA.LibroFlyWS;
using LibroFlyWA.UsuarioWS;

namespace LibroFlyWA
{
    public partial class BuscarLibroFiltros : System.Web.UI.Page
    {
        private LibroWSClient libroWSClient;
        private GeneroWSClient generoWSClient;
        protected void Page_Load(object sender, EventArgs e)
        {
            usuariosDTO usuarioActual = (usuariosDTO)Session["usuario"];
            libroWSClient = new LibroFlyWS.LibroWSClient();
            if (!IsPostBack)
            {
                LoadLibros();
                LoadGeneros();
            }

            if (Request.QueryString["mensaje"] == "exito")
            {
                lblMensaje.Text = "¡El libro se registró con éxito!";
                lblMensaje.ForeColor = System.Drawing.Color.Green;
            }
            if (Request.QueryString["mensajemodificacion"] == "exito")
            {
                lblMensaje.Text = "¡El libro fue modificado con éxito!";
                lblMensaje.ForeColor = System.Drawing.Color.Green;
            }
        }

        private void LoadLibros()
        {
            List<LibroFlyWS.librosDTO> libros = libroWSClient.listarLibros().ToList();
            dgvLibros.DataSource = libros;
            dgvLibros.DataBind();
        }

        protected void lvItems_ItemDataBound(object sender, ListViewItemEventArgs e)
        {
            usuariosDTO usuarioActual = (usuariosDTO)Session["usuario"];
            if (e.Item.ItemType == ListViewItemType.DataItem)
            {
                Button btnModificar = (Button)e.Item.FindControl("btnModificar");
                if (usuarioActual != null)
                {
                    if (usuarioActual.tipo.Equals("ADMINISTRADOR"))
                    {
                        btnModificar.Visible = true;
                    }
                    else
                    {
                        btnModificar.Visible = false;
                    }
                }

            }
        }
        protected void lblMostrarLibro_Click(object sender, EventArgs e)
        {
            int idLibro = Int32.Parse(((LinkButton)sender).CommandArgument);
            LibroFlyWS.librosDTO libro = libroWSClient.obtenerLibroPorId(idLibro);
            Session["mostrarLibro"] = libro;
            Response.Redirect("LibroSeleccionado.aspx");
        }

        protected void btnMostrarLibroImage_Click(object sender, EventArgs e)
        {
            int idLibro = Int32.Parse(((ImageButton)sender).CommandArgument);
            LibroFlyWS.librosDTO libro = libroWSClient.obtenerLibroPorId(idLibro);
            Session["mostrarLibro"] = libro;
            Response.Redirect("LibroSeleccionado.aspx");
        }
        protected void btnModificar_Click(object sender, EventArgs e)
        {
            int idLibro = Int32.Parse(((Button)sender).CommandArgument);
            LibroFlyWS.librosDTO libro = libroWSClient.obtenerLibroPorId(idLibro);
            Session["libroModificar"] = libro;
            Response.Redirect("ModificarLibro.aspx");
        }

        protected void LoadGeneros()
        {
            generoWSClient = new GeneroWSClient();
            List<String> generosDTOs = generoWSClient.listarGeneros().Select(genero => genero.descripcion).ToList();
            dgvGenerosFiltros.DataSource = generosDTOs; 
            dgvGenerosFiltros.DataBind();
        }

        protected void dgvGenerosFiltros_ItemDataBound(object sender, ListViewItemEventArgs e)
        {
            if (e.Item.ItemType == ListViewItemType.DataItem)
            {
                RadioButton rb = (RadioButton)e.Item.FindControl("RadioButton1");

                if (rb != null)
                {
                    rb.GroupName = "metodo";
                }
            }
        }
    }
}