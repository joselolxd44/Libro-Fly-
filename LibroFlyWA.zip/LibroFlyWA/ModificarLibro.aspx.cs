﻿using LibroFlyWA.GeneroWS;
using LibroFlyWA.LibroFlyWS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibroFlyWA
{
    public partial class ModificarLibro : System.Web.UI.Page
    {
        private LibroWSClient libroWSClient = new LibroWSClient();
        private GeneroWSClient generoWSClient;
        List<GeneroWS.generosDTO> listaGeneros;
        protected void Page_Load(object sender, EventArgs e)
        {
            generoWSClient = new GeneroWSClient();
            if (!IsPostBack)
            {
                listaGeneros = generoWSClient.listarGeneros().ToList();
                List<String> nombresGeneros = listaGeneros.Select(genero => genero.descripcion).ToList();
                //ddlGenero.DataSource = nombresGeneros;
                //ddlGenero.DataBind();
                librosDTO libro = (librosDTO)Session["libroModificar"];
                txtGenero.Text = listaGeneros[libro.genero.id_genero-1].descripcion.ToString();
                txtTituloLibro.Text = libro.titulo;
                txtDescripcion.Text = libro.descripcion;
                txtAnho.Text = libro.anho.ToString();
                txtAncho.Text = libro.ancho.ToString();
                txtPeso.Text = libro.peso.ToString();
                txtAlto.Text = libro.alto.ToString();
                txtNumPag.Text = libro.numero_paginas.ToString();
                txtFormato.Text = libro.formato.ToString(); 
                BindingList<LibroFlyWS.autoresLibroDTO> autores = new BindingList<LibroFlyWS.autoresLibroDTO>(libroWSClient.listarAutoresLibro(libro.id_libro));
                BindingList<string> nombresAutores = new BindingList<string>(autores.Select(autor => autor.autor.nombre_completo).ToList());
                string cadena = "";
                int primero = 1;
                foreach (string nombre in nombresAutores)
                {
                    if (primero != 1)
                        cadena += ", ";
                    else
                        primero = 0;
                    cadena += nombre;
                }
                txtAutor.Text = cadena;
                txtEditorial.Text = libro.editorial;
                txtIsbn.Text = libro.isbn;
                txtPrecio.Text = libro.precio.ToString();
                txtStock.Text = libro.stock.ToString();
                //ddlGenero.SelectedIndex = libro.genero_id.id_genero - 1;
            }
            
        }

        protected void btnCancelBook_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");

        }

        protected void btnAddBook_Click(object sender, EventArgs e)
        {
            librosDTO libroSession = (librosDTO)Session["libroModificar"];
            librosDTO libro = new librosDTO();
            //libro.titulo = txtTituloLibro.Text;
            //string autores = txtAutor.Text;
            //libro.descripcion = txtDescripcion.Text;
            //libro.anho = Int32.Parse(txtAnho.Text);
            //libro.ancho = float.Parse(txtAncho.Text);
            //libro.alto = float.Parse(txtAlto.Text);
            //libro.peso = float.Parse(txtPeso.Text);
            libro.precio = float.Parse(txtPrecio.Text);
            if(libro.precio < 0)
            {
                lblError.Text = "Precio inválido.";
                return;
            }
            libro.stock = Int32.Parse(txtStock.Text);
            if (libro.stock < 0)
            {
                lblError.Text = "Stock inválido.";
                return;
            }
            //if(libro.stock == 0)
            //{
            //    libro.disponibilidad = "no disponible";
            //}else
            //{
            //    libro.disponibilidad = "en venta";
            //}
            libroWSClient.modificarLibro(libroSession.id_libro,libro.precio, libro.stock);
            Response.Redirect("Home.aspx?mensajemodificacion=exito");
        }

        protected void BtnEliminarLibro_Click(object sender, EventArgs e)
        {
            librosDTO libroSession = (librosDTO)Session["libroModificar"];
            libroWSClient.eliminarLibro(libroSession.id_libro);
            Response.Redirect("Home.aspx");
        }
    }
}