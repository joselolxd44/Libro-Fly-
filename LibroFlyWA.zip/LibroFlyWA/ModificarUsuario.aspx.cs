﻿using LibroFlyWA.UsuarioWS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibroFlyWA
{
    public partial class ModificarUsuario : System.Web.UI.Page
    {
        private UsuarioWSClient usuarioWSClient;
        BindingList<string> listaTiposDocumento;
        protected void Page_Load(object sender, EventArgs e)
        {
            usuarioWSClient = new UsuarioWSClient();
            if (!IsPostBack)
            {
                usuariosDTO usuario = (usuariosDTO)Session["usuario"];
                txtNombres.Text = usuario.nombres;
                txtApellidos.Text = usuario.apellidos;
                txtCorreoElectronico.Text = usuario.correo;
                txtDireccion.Text = usuario.direccion_envio;
                txtNumdocumento.Text = usuario.numero_documento;
                txtTelefono.Text = usuario.telefono;
                listaTiposDocumento = new BindingList<string>(usuarioWSClient.listarTiposDocumento());
                ddlTipoDoc.DataSource = listaTiposDocumento;
                ddlTipoDoc.DataBind();
                string contraseña = "";
                for (int i = 0; i < usuario.contrasenha.Length; i++)
                {
                    contraseña += '*';
                }
                txtContrasenha.Text = contraseña;
            }
        }

        protected void btnModificarUsuario_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombres.Text) ||
                string.IsNullOrWhiteSpace(txtApellidos.Text) ||
                string.IsNullOrWhiteSpace(txtCorreoElectronico.Text) ||
                string.IsNullOrWhiteSpace(txtDireccion.Text) ||
                string.IsNullOrWhiteSpace(txtNumdocumento.Text))
            {
                lblError.Text = "No se pueden dejar campos vacios.";
                return;
            }


            usuariosDTO usuario = (usuariosDTO)Session["usuario"];
            usuarioWSClient = new UsuarioWSClient();
            usuario.nombres = txtNombres.Text;
            usuario.apellidos = txtApellidos.Text;
            //usuario.correo = txtCorreoElectronico.Text;
            usuario.direccion_envio = txtDireccion.Text;
            usuario.numero_documento = txtNumdocumento.Text;
            int seleccionadoIndex = ddlTipoDoc.SelectedIndex;
            listaTiposDocumento = new BindingList<string>(usuarioWSClient.listarTiposDocumento());
            string tipo_documento = listaTiposDocumento[seleccionadoIndex];
            //usuario.contrasenha = txtContrasenha.Text;
            usuario.telefono = txtTelefono.Text;
            //if(usuario.rol.Equals("ADMINISTRADOR"))
            //{
            //    usuario.tipo = "";
            //}else
            //{
            //    usuario.tipo = "C";
            //}
            usuarioWSClient.editarPerfil(usuario.id_usuario,usuario.nombres,usuario.apellidos,
                usuario.direccion_envio,usuario.telefono,tipo_documento,usuario.numero_documento);
            Response.Redirect("Profile.aspx?mensaje=exito");
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Profile.aspx");
        }

        protected void btnCambiarContrasenha_Click(object sender, EventArgs e)
        {
            
        }
    }
}