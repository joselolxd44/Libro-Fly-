﻿using LibroFlyWA.UsuarioWS;
using LibroFlyWA.LibroFlyWS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace LibroFlyWA
{
    public partial class InicioSesion : System.Web.UI.Page
    {
        private UsuarioWSClient usuarioWsClient;
        private List<Tuple<LibroFlyWS.librosDTO,int,double>> productosCarrito;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["mensaje"] == "exito")
            {
                lblExito.Text = "¡El usuario se registró con éxito!";
                lblExito.ForeColor = System.Drawing.Color.Green;
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            lblMensaje.Text = "";
            String correo = txtCorreo.Text;
            String contrasenah = txtPassword.Text;
            usuarioWsClient = new UsuarioWSClient();
            int resultado = usuarioWsClient.verificarSesion(correo, contrasenah);
            if (resultado > 0)
            {
                productosCarrito = new List<Tuple<LibroFlyWS.librosDTO, int, double>>();
                Session["productosSeleccionados"] = productosCarrito;
                usuariosDTO usuario = new usuariosDTO();
                usuario = usuarioWsClient.obtenerUsuarioPorId(resultado);
                Session["usuario"] = usuario;
                FormsAuthenticationTicket tkt;
                string cookiestr;
                HttpCookie ck;

                tkt = new FormsAuthenticationTicket(1, usuario.nombres, DateTime.Now, DateTime.Now.AddMinutes(60),true,"datos adicionales");

                cookiestr = FormsAuthentication.Encrypt(tkt);
                ck = new HttpCookie(FormsAuthentication.FormsCookieName, cookiestr);
                ck.Expires = tkt.Expiration;
                ck.Path = FormsAuthentication.FormsCookiePath;
                Response.Cookies.Add(ck);
                string strRedirect;
                strRedirect = Request["ReturnUrl"];
                if(strRedirect == null)
                {
                    Response.Redirect("Home.aspx");
                }
                Response.Redirect(strRedirect,true);
            }
            else
            {
                if(resultado == 0)
                {
                    lblMensaje.Text = "Correo electrónico y/o contraseña inválidos";
                }
            }
        }

        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
            Response.Redirect("RegistrarUsuario.aspx");
        }
    }
}