﻿using LibroFlyWA.GeneroWS;
using LibroFlyWA.LibroFlyWS;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibroFlyWA
{
    public partial class RegistrarLibro : System.Web.UI.Page
    {
        private GeneroWSClient generoWSClient;
        private LibroWSClient libroWSCliente;
        List<GeneroWS.generosDTO> listaGeneros;
        protected void Page_Load(object sender, EventArgs e)
        {
            generoWSClient = new GeneroWSClient();
            libroWSCliente = new LibroWSClient();
            if (!IsPostBack)
            {
                listaGeneros = generoWSClient.listarGeneros().ToList();
                List<String> nombresGeneros = listaGeneros.Select(genero => genero.descripcion).ToList();
                ddlGenero.DataSource = nombresGeneros;
                ddlGenero.DataBind();
            }
        }

        protected void btnCancelBook_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        protected void btnAddBook_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTituloLibro.Text) ||
                string.IsNullOrWhiteSpace(txtAutor.Text) ||
                string.IsNullOrWhiteSpace(txtEditorial.Text) ||
                string.IsNullOrWhiteSpace(txtIsbn.Text))
            {
                lblError.Text = "Falta rellenar todos los campos obligatorios.";
                return;
            }
            float precio;
            if (!float.TryParse(txtPrecio.Text, out precio) || precio < 0)
            {
                lblError.Text = "Ingrese un precio válido y positivo.";
                return;
            }

            // Validar stock
            int stock;
            if (!int.TryParse(txtStock.Text, out stock) || stock < 0)
            {
                lblError.Text = "Ingrese un stock válido y positivo.";
                return;
            }
            librosDTO nuevoLibro = new librosDTO();
            nuevoLibro.titulo = txtTituloLibro.Text;
            string autores = txtAutor.Text;
            nuevoLibro.descripcion = txtDescripcion.Text;
            nuevoLibro.anho = Int32.Parse(txtAnho.Text);
            nuevoLibro.ancho = float.Parse(txtAncho.Text);
            nuevoLibro.alto = float.Parse(txtAlto.Text);
            nuevoLibro.peso = float.Parse(txtPeso.Text);
            if(nuevoLibro.ancho <= 0)
            {
                lblError.Text = "Ingrese un ancho positivo.";
                return;
            }
            if (nuevoLibro.alto <= 0)
            {
                lblError.Text = "Ingrese un alto positivo.";
                return;
            }
            if (nuevoLibro.peso <= 0)
            {
                lblError.Text = "Ingrese un peso positivo.";
                return;
            }
            if (nuevoLibro.anho > 2025 || nuevoLibro.anho < 1800)
            {
                lblError.Text = "Ingrese un año válido.";
                return;
            }
            nuevoLibro.numero_paginas = Int32.Parse(txtNumPag.Text);
            if (nuevoLibro.numero_paginas <= 0)
            {
                lblError.Text = "Ingrese un número de páginas positivo.";
                return;
            }
            nuevoLibro.precio = float.Parse(txtPrecio.Text);
            nuevoLibro.formato = txtFormato.Text;
            nuevoLibro.editorial = txtEditorial.Text;
            nuevoLibro.isbn = txtIsbn.Text;
            nuevoLibro.url_portada = txtUrl.Text;
            nuevoLibro.stock = Int32.Parse(txtStock.Text);
            float pre = nuevoLibro.precio;
            int seleccionadoIndex = ddlGenero.SelectedIndex;
            listaGeneros = generoWSClient.listarGeneros().ToList();
            GeneroWS.generosDTO genero = listaGeneros[seleccionadoIndex];
            
            
            libroWSCliente.insertarLibro(nuevoLibro.titulo,nuevoLibro.descripcion, nuevoLibro.anho, 
                nuevoLibro.peso, nuevoLibro.ancho, nuevoLibro.alto, nuevoLibro.numero_paginas, nuevoLibro.formato, autores, nuevoLibro.editorial, nuevoLibro.isbn,
                nuevoLibro.precio, nuevoLibro.stock, nuevoLibro.url_portada, genero.id_genero);

            Response.Redirect("Home.aspx?mensaje=exito");
        }
    }
}