﻿using LibroFlyWA.LibroFlyWS;
using LibroFlyWA.UsuarioWS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibroFlyWA
{
    public partial class Home : System.Web.UI.Page
    {
        private LibroWSClient libroWSClient;
        protected void Page_Load(object sender, EventArgs e)
        {
            usuariosDTO usuarioActual = (usuariosDTO)Session["usuario"];
            libroWSClient = new LibroFlyWS.LibroWSClient();
            if (!IsPostBack)
            {
                LoadLibros();
            }
            if (usuarioActual != null)
            {
                if (usuarioActual.tipo.Equals("ADMINISTRADOR"))
                {
                    btnAgregarLibro.Visible = true;
                }else
                {
                    btnAgregarLibro.Visible=false;
                }
            }
            if (Request.QueryString["mensaje"] == "exito")
            {
                lblMensaje.Text = "¡El libro se registró con éxito!";
                lblMensaje.ForeColor = System.Drawing.Color.Green;
            }
            if (Request.QueryString["mensajemodificacion"] == "exito")
            {
                lblMensaje.Text = "¡El libro fue modificado con éxito!";
                lblMensaje.ForeColor = System.Drawing.Color.Green;
            }

        }

        protected void lvItems_ItemDataBound(object sender, ListViewItemEventArgs e)
        {
            usuariosDTO usuarioActual = (usuariosDTO)Session["usuario"];
            if (e.Item.ItemType == ListViewItemType.DataItem)
            {
                Button btnModificar = (Button)e.Item.FindControl("btnModificar");
                if (usuarioActual != null)
                {
                    if(usuarioActual.tipo.Equals("ADMINISTRADOR"))
                    {
                        btnModificar.Visible = true;
                    }else
                    {
                        btnModificar.Visible=false;
                    }
                }

            }
        }

        private void LoadLibros()
        {
            List<LibroFlyWS.librosDTO> libros = libroWSClient.listarLibros().ToList();
            dgvLibros.DataSource = libros;
            dgvLibros.DataBind();
        }
        
        protected void lblMostrarLibro_Click(object sender, EventArgs e)
        {
            int idLibro = Int32.Parse(((LinkButton)sender).CommandArgument);
            LibroFlyWS.librosDTO libro = libroWSClient.obtenerLibroPorId(idLibro);
            Session["mostrarLibro"] = libro;
            Response.Redirect("LibroSeleccionado.aspx");
        }

        protected void btnMostrarLibroImage_Click(object sender, EventArgs e)
        {
            int idLibro = Int32.Parse(((ImageButton)sender).CommandArgument);
            LibroFlyWS.librosDTO libro = libroWSClient.obtenerLibroPorId(idLibro);
            Session["mostrarLibro"] = libro;
            Response.Redirect("LibroSeleccionado.aspx");
        }

        protected void btnAgregarLibro_Click(object sender, EventArgs e)
        {
            Response.Redirect("RegistrarLibro.aspx");
        }

        protected void btnModificar_Click(object sender, EventArgs e)
        {
            int idLibro = Int32.Parse(((Button)sender).CommandArgument);
            LibroFlyWS.librosDTO libro = libroWSClient.obtenerLibroPorId(idLibro);
            Session["libroModificar"] = libro;
            Response.Redirect("ModificarLibro.aspx");
        }
    }
}