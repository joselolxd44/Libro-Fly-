﻿using LibroFlyWA.CarritoWS;
using LibroFlyWA.LibroFlyWS;
using LibroFlyWA.UsuarioWS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.ServiceModel.Channels;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibroFlyWA
{
    public partial class LibroSeleccionado : System.Web.UI.Page
    {
        private LibroWSClient libroWSClient = new LibroWSClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            LibroFlyWS.librosDTO libroSeleccionado = (LibroFlyWS.librosDTO)Session["mostrarLibro"];
            //listaTiposDocumento = new BindingList<string>(usuarioWSClient.listarTiposDocumento());
            BindingList<LibroFlyWS.autoresLibroDTO> autores = new BindingList<LibroFlyWS.autoresLibroDTO>(libroWSClient.listarAutoresLibro(libroSeleccionado.id_libro));
            BindingList<string> nombresAutores = new BindingList<string>(autores.Select(autor => autor.autor.nombre_completo).ToList());
            string cadena = "";
            int primero = 1;
            foreach(string nombre in nombresAutores)
            {
                if (primero != 1)
                    cadena += ", ";
                else
                    primero = 0;
                cadena += nombre;
            }
            lblAutor.Text = cadena;
            lblEditorial.Text = libroSeleccionado.editorial;
            lblPrecio.Text = libroSeleccionado.precio.ToString();
            lblStock.Text = libroSeleccionado.stock.ToString();
            lblTitulo.Text = libroSeleccionado.titulo;
            lblAnho.Text = libroSeleccionado.anho.ToString();
            lblPeso.Text = libroSeleccionado.peso.ToString();
            lblAncho.Text = libroSeleccionado.ancho.ToString();
            lblAlto.Text = libroSeleccionado.alto.ToString();
            lblNumPag.Text = libroSeleccionado.numero_paginas.ToString();
            lblFormato.Text = libroSeleccionado.formato.ToString();
            lblIsbn.Text = libroSeleccionado.isbn.ToString();
            if(libroSeleccionado.stock == 0)
            {
                btnAddBookCarthShopping.Text = "AGOTADO";
                btnAddBookCarthShopping.Enabled = false;
            }
        }

        protected void addBookCarthShopping(object sender, EventArgs e)
        {
            UsuarioWS.usuariosDTO usuarioActual = (UsuarioWS.usuariosDTO)Session["usuario"];
            if (usuarioActual == null)
            {
                Response.Redirect("InicioSesion.aspx");
            }else
            {
                LibroFlyWS.librosDTO libroSeleccionado = (LibroFlyWS.librosDTO)Session["mostrarLibro"];

                //List<Tuple<LibroFlyWS.librosDTO, int, double>> productosCarrito = (List<Tuple<LibroFlyWS.librosDTO, int, double>>)Session["productosSeleccionados"];
                //bool existe = false;
                int cantidad = Int32.Parse(txtCantidadLibro.Text);
                CarritoWSClient carrito = new CarritoWSClient();
                carrito.insertarLineaCarrito(usuarioActual.id_usuario, libroSeleccionado.id_libro, cantidad);
                //for (int i = 0; i < productosCarrito.Count; i++) {
                //    if (productosCarrito[i].Item1.id_libro == libroSeleccionado.id_libro)
                //    {
                //        existe = true;
                //        int precioInt = (int)(libroSeleccionado.precio*100);
                //        double precioFinal = (double)precioInt / 100;
                //        int cantidadItem = productosCarrito[i].Item2 + cantidad;
                //        productosCarrito[i] = new Tuple<LibroFlyWS.librosDTO, int, double>(libroSeleccionado, cantidadItem, precioFinal*cantidadItem);
                //        break;
                //    }
                //}
                //if(!existe)
                //{
                //    int precioInt = (int)(libroSeleccionado.precio * 100);
                //    double precioFinal = (double)precioInt / 100;
                //    productosCarrito.Add(new Tuple<LibroFlyWS.librosDTO, int, double>(libroSeleccionado,cantidad,precioFinal*cantidad));
                //}
            }
        }
    }
}