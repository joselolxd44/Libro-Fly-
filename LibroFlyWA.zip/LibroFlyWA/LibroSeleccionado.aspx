﻿<%@ Page Title="" Language="C#" MasterPageFile="~/LibroFly.Master" AutoEventWireup="true" CodeBehind="LibroSeleccionado.aspx.cs" Inherits="LibroFlyWA.LibroSeleccionado" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_Contenido" runat="server">
    <style>
        .btn {
            border-radius: 26px;
            padding: 20px;
        }

        .precio {
            color: #F59106;
            font-size: 40px;
            font-weight: 500;
        }

    </style>
    <div class="mt-5 d-flex w-75 m-auto" style="height:500px">
        
        <div class="w-50 m-auto">
            <div class="w-50 m-auto">
                <img class="w-auto" style="height:500px" src="https://i.pinimg.com/564x/25/9e/ee/259eeeb138f099368003026a868704d3.jpg"/> 
            </div>
        </div>
        <div class="w-50" style="height:fit-content">
             <div class="mt-3" style="width: fit-content">
                <asp:Label SkinID="precio" ID="lblTitulo" runat="server" CssClass="fa-3x" Text="Nombres"></asp:Label>
            </div>
            <div class="mt-2" style="width: fit-content">
                <b>Autor(a)</b>: 
                <asp:Label ID="lblAutor" runat="server" Text="Nombres"></asp:Label>
            </div>
            <div class="mt-2" style="width: fit-content">
                <b>Editorial</b>: 
                <asp:Label ID="lblEditorial" runat="server" Text="Nombres"></asp:Label>
            </div>
            <div class="mt-2" style="width: fit-content">
                <b>Año</b>: 
                <asp:Label ID="lblAnho" runat="server" Text="Nombres"></asp:Label>
            </div>
            <div class="mt-2" style="width: fit-content">
                <b>Peso</b>: 
                <asp:Label ID="lblPeso" runat="server" Text="Nombres"></asp:Label>
            </div>
            <div class="mt-2" style="width: fit-content">
                <b>Ancho</b>: 
                <asp:Label ID="lblAncho" runat="server" Text="Nombres"></asp:Label>
            </div>
            <div class="mt-2" style="width: fit-content">
                <b>Alto</b>: 
                <asp:Label ID="lblAlto" runat="server" Text="Nombres"></asp:Label>
            </div>
            <div class="mt-2" style="width: fit-content">
                <b>Numero de páginas</b>: 
                <asp:Label ID="lblNumPag" runat="server" Text="Nombres"></asp:Label>
            </div>
            <div class="mt-2" style="width: fit-content">
                <b>ISBN</b>: 
                <asp:Label ID="lblIsbn" runat="server" Text="Nombres"></asp:Label>
            </div>
            <div class="mt-2" style="width: fit-content">
                <b>Formato</b>: 
                <asp:Label ID="lblFormato" runat="server" Text="Nombres"></asp:Label>
            </div>
            <div class="mt-2" style="width: fit-content">
                <b>Stock</b>: 
                <asp:Label ID="lblStock" runat="server" Text="0"></asp:Label>
                unidades
            </div>
            <div class="mt-2" style="width: fit-content">
                <b>Precio</b>:<br /> <span class="precio">S/.</span>
                <asp:Label SkinID="precio" CssClass="precio" ID="lblPrecio" runat="server" Text="Nombres"></asp:Label>
            </div>
            <div>
                <asp:TextBox Width="120px" TextMode="Number" CssClass=" form-control" ID="txtCantidadLibro" runat="server" Text="0"></asp:TextBox>
            </div>
            <div class="mt-5" style="width: fit-content">
                <asp:Button SkinID="btn" Width="200px" BackColor="#F59106" CssClass="btn text-white m-auto" ID="btnAddBookCarthShopping" OnClick="addBookCarthShopping" runat="server" Enabled="true" Text="AGREGAR AL CARRITO" />
            </div>
        </div>
    </div>
</asp:Content>
