﻿<%@ Page Title="" Language="C#" MasterPageFile="~/LibroFly.Master" AutoEventWireup="true" CodeBehind="Home.aspx.cs" Inherits="LibroFlyWA.Home" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="cph_Contenido" runat="server">
    <div class="d-block">
        <div class="d-flex m-auto" style="width:90%">
            <div class="w-75">
                <h3 class="text-start">Libros</h3>
            </div>
            <div class="w-25">
                <asp:Button Visible="false" ID="btnAgregarLibro" OnClick="btnAgregarLibro_Click" Width="200px" BackColor="#F59106" CssClass="end-100 btn text-white m-3" 
                    runat="server" Text="AGREGAR LIBRO" />
            </div>
        </div>
        <div class="container mt-2">
            <asp:Label ID="lblMensaje" runat="server" CssClass="d-block text-center" />

            <!-- List de Libros -->
            <asp:ListView ID="dgvLibros" OnItemDataBound="lvItems_ItemDataBound" runat="server" GroupItemCount="4">
                <GroupTemplate>
                    <tr>
                      <asp:PlaceHolder runat="server" ID="itemPlaceholder" />
                    </tr>
                </GroupTemplate>
                <LayoutTemplate>
                    <table class="w-100">
                      <asp:PlaceHolder ID="groupPlaceholder" runat="server" />
                    </table>
                </LayoutTemplate>
                <ItemTemplate>
                    <td class="w-25 text-center m-auto p-4">
                      <div class="d-block">
                          <!--<img class="w-50 h-auto" src="https://i.pinimg.com/564x/25/9e/ee/259eeeb138f099368003026a868704d3.jpg"/> -->
                          <asp:ImageButton CssClass="w-50 h-auto" ImageUrl="https://i.pinimg.com/564x/25/9e/ee/259eeeb138f099368003026a868704d3.jpg" ID="btnBookSelected" runat="server" CommandArgument='<%# Eval("id_libro") %>' OnClick="btnMostrarLibroImage_Click"/>
                          <br />
                          <asp:LinkButton CssClass="w-100 text-decoration-none text-black" ID="btnLibro" runat="server" Text='<%# Eval("titulo") %>' CommandArgument='<%# Eval("id_libro") %>'
                              OnClick="lblMostrarLibro_Click"
                              >LinkButton</asp:LinkButton><br />
                          <div class="w-100 text-center">
                              <b>S/.</b>
                              <asp:Label  ID="Label1" runat="server"
                                    Text='<%# Eval("precio") %>'/> <br />
                          </div>
                          <div class="w-100 m-auto" >
                              <asp:Button ID="btnModificar" CommandArgument='<%# Eval("id_libro") %>' OnClick="btnModificar_Click" Visible="false" Width="200px" BackColor="#F59106" CssClass="end-100 btn text-white m-3" 
                                    runat="server" Text="MODIFICAR" />
                          </div>
                          
                      </div>
                    </td>
                  </ItemTemplate>
            </asp:ListView>

        </div>
    </div>
</asp:Content>
