package pe.edu.pucp.librofly.bo;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Month;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PedidoBOTest {
    public PedidoBO pedido;
    
    public PedidoBOTest(){
        this.pedido = new PedidoBO();
    }
    
//    @Test
//    public void pruebaReporte(){
//        pedido=new PedidoBO();
//        pedido.reporteLibros(Date.valueOf(LocalDate.of(2024, Month.MARCH, 1)), Date.valueOf(LocalDate.of(2026, Month.MARCH, 1)));
//    }
    
//    @Test
//    public void pruebaHistorialPedidosUsuario(){
//        this.pedido.visualizarHistorialDeUsuario(4);
//    }
}
