/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package pe.edu.pucp.librofly.bo;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.model.LibrosDTO;

/**
 *
 * @author USUARIO
 */
public class LibroBOTest {
    private LibroBO libroBO;
    
    public LibroBOTest() {
        this.libroBO = new LibroBO();
    }
    
//    @Test
//    public void testCadena(){
//        String autores = "Mario,Luna,Vargas,";
//        this.libroBO.insertarAutoresLibro(autores,1);
//    }
     /* Test of visualizarCatalogo method, of class LibroBO.
     */
//    @Test
//    public void testVisualizarCatalogo() {
//        System.out.println("visualizarCatalogo");
//        LibroBO instance = new LibroBO();
////        ArrayList<LibrosDTO> expResult = null;
//        ArrayList<LibrosDTO> result = instance.visualizarCatalogo();
////        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
////        fail("The test case is a prototype.");
//    }

    /**
     * Test of visualizarDetallesLibro method, of class LibroBO.
//     */
//    @Test
//    public void testVisualizarDetallesLibro() {
//        System.out.println("visualizarDetallesLibro");
//        int id_libro = 0;
//        LibroBO instance = new LibroBO();
//        instance.visualizarDetallesLibro(id_libro);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of actualizarDisponibilidad method, of class LibroBO.
//     */
//    @Test
//    public void testActualizarDisponibilidad() {
//        System.out.println("actualizarDisponibilidad");
//        LibroBO instance = new LibroBO();
//        instance.actualizarDisponibilidad();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of buscarLibros method, of class LibroBO.
//     */
//    @Test
//    public void testBuscarLibros() {
//        System.out.println("buscarLibros");
//        String titulo = "";
//        String autor = "";
//        Float precio = null;
//        String disponibilidad = "";
//        GenerosDTO genero = null;
//        LibroBO instance = new LibroBO();
//        Boolean expResult = null;
//        Boolean result = instance.buscarLibros(titulo, autor, precio, disponibilidad, genero);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of Insertar method, of class LibroBO.
//     */
//    @Test
//    public void testInsertar() {
//        System.out.println("Insertar");
//        String titulo = "";
//        String autor = "";
//        String editorial = "";
//        String isbn = "";
//        Float precio = null;
//        Integer stock = null;
//        String disponibilidad = "";
//        GenerosDTO genero = null;
//        LibroBO instance = new LibroBO();
//        Integer expResult = null;
//        Integer result = instance.Insertar(titulo, autor, editorial, isbn, precio, stock, disponibilidad, genero);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of Modificar method, of class LibroBO.
//     */
//    @Test
//    public void testModificar() {
//        System.out.println("Modificar");
//        Integer id = null;
//        String titulo = "";
//        String autor = "";
//        String editorial = "";
//        String isbn = "";
//        Float precio = null;
//        Integer stock = null;
//        String disponibilidad = "";
//        GenerosDTO genero = null;
//        LibroBO instance = new LibroBO();
//        Integer expResult = null;
//        Integer result = instance.Modificar(id, titulo, autor, editorial, isbn, precio, stock, disponibilidad, genero);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of Eliminar method, of class LibroBO.
//     */
//    @Test
//    public void testEliminar() {
//        System.out.println("Eliminar");
//        Integer id = null;
//        LibroBO instance = new LibroBO();
//        Integer expResult = null;
//        Integer result = instance.Eliminar(id);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of ObtenerPorId method, of class LibroBO.
//     */
//    @Test
//    public void testObtenerPorId() {
//        System.out.println("ObtenerPorId");
//        int id = 0;
//        LibroBO instance = new LibroBO();
//        LibrosDTO expResult = null;
//        LibrosDTO result = instance.ObtenerPorId(id);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//    
}
