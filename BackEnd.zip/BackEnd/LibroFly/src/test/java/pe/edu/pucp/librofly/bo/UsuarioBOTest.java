/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package pe.edu.pucp.librofly.bo;

import java.util.ArrayList;
import java.util.Arrays;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import pe.edu.pucp.librofly.model.TipoDocumento;
import pe.edu.pucp.librofly.model.UsuariosDTO;

/**
 *
 * @author USUARIO
 */
public class UsuarioBOTest {
    
    UsuarioBO usuarioBO;
    
    public UsuarioBOTest() {
        this.usuarioBO=new UsuarioBO();
    }
    
    @Test
    public void TestRegistrar(){
        ArrayList<TipoDocumento> tipos = new ArrayList<>(Arrays.asList(TipoDocumento.values()));
        for(TipoDocumento tipo : tipos){
            System.out.println(tipo);
        }
    }
    
//    @Test
//    public void TestIniciarSesion(){
//        System.out.println("iniciar sesion");
//        Integer idSesion=this.usuarioBO.iniciarSesion("usuario@hotmail.com", "usuario123");
//        System.out.println(idSesion);
//    }
//    
//    @BeforeAll
//    public static void setUpClass() {
//    }
//    
//    @AfterAll
//    public static void tearDownClass() {
//    }
//    
//    @BeforeEach
//    public void setUp() {
//    }
//    
//    @AfterEach
//    public void tearDown() {
//    }
//
//    /**
//     * Test of registrarUsuario method, of class UsuarioBO.
//     */
//    @Test
//    public void testRegistrarUsuario() {
//        System.out.println("registrarUsuario");
//        String correo = "";
//        String contrasenha = "";
//        String nombres = "";
//        String apellidos = "";
//        String direccion_envio = "";
//        String telefono = "";
//        String dni_cliente = "";
//        UsuarioBO instance = new UsuarioBO();
//        Integer expResult = null;
//        Integer result = instance.registrarUsuario(correo, contrasenha, nombres, apellidos, direccion_envio, telefono, dni_cliente);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of editarPerfil method, of class UsuarioBO.
//     */
//    @Test
//    public void testEditarPerfil() {
//        System.out.println("editarPerfil");
//        Integer id_usuario = null;
//        String correo = "";
//        String direccion_envio = "";
//        String telefono = "";
//        UsuarioBO instance = new UsuarioBO();
//        Integer expResult = null;
//        Integer result = instance.editarPerfil(id_usuario, correo, direccion_envio, telefono);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of iniciarSesion method, of class UsuarioBO.
     */
//    @Test
//    public void testIniciarSesion() {
//        System.out.println("iniciarSesion");
//        String correo = "usuario@hotmail.com";
//        String contrasenha = "usuario123";
//        UsuarioBO instance = new UsuarioBO();
////        Integer expResult = null;
//        Integer result = instance.iniciarSesion(correo, contrasenha);
//        System.out.println(result);
////        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
////        fail("The test case is a prototype.");
//    }

    /**
     * Test of obtenerPorId method, of class UsuarioBO.
     */
//    @Test
//    public void testObtenerPorId() {
//        System.out.println("obtenerPorId");
//        Integer id_usuario = null;
//        UsuarioBO instance = new UsuarioBO();
//        UsuariosDTO expResult = null;
//        UsuariosDTO result = instance.obtenerPorId(id_usuario);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    
}
