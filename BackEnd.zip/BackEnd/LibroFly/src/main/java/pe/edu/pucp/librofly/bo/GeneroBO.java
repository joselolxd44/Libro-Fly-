package pe.edu.pucp.librofly.bo;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.persistance.dao.GeneroDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.GeneroDAOImpl;

public class GeneroBO {
    private GeneroDAO generoDAO;
    
    public GeneroBO(){
        generoDAO=new GeneroDAOImpl();
        
    }
    
    public Integer Insertar(String descripcion,GenerosDTO genero_principal_id){
        GenerosDTO generosDTO=new GenerosDTO();
        generosDTO.setDescripcion(descripcion);
        generosDTO.setGenero_principal_id(genero_principal_id);
        return generoDAO.insertar(generosDTO);
    }
    public Integer Modificar(Integer id_genero, String descripcion,GenerosDTO genero_principal_id){
        GenerosDTO generosDTO=new GenerosDTO(id_genero, descripcion, genero_principal_id);
        return generoDAO.modificar(generosDTO);
    }
    public Integer Eliminar(Integer id_genero){
        GenerosDTO generosDTO=new GenerosDTO();
        generosDTO.setId_genero(id_genero);
        return generoDAO.eliminar(generosDTO);
    }
    
    public GenerosDTO ObtenerPorId(int id){
        return generoDAO.obtenerPorId(id);
    }
    
    public ArrayList<GenerosDTO> generos() { 
        return generoDAO.listarTodos();
    }
}
