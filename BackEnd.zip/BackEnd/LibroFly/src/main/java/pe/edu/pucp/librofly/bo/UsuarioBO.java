package pe.edu.pucp.librofly.bo;

import java.util.ArrayList;
import pe.edu.pucp.librofly.db.util.Cifrado;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.model.TipoDocumento;
import pe.edu.pucp.librofly.model.UsuariosDTO;
import pe.edu.pucp.librofly.persistance.dao.UsuarioDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.UsuarioDAOImpl;

public class UsuarioBO {
    private UsuarioDAO usuarioDAO;
    
    public UsuarioBO(){
        this.usuarioDAO=new UsuarioDAOImpl();
    }
    
    public Integer registrarUsuario(String correo, String contrasenha, String nombres, 
            String apellidos, String direccion_envio, String telefono, String tipo_documento, 
            String numero_documento, String rol, String tipo){
        UsuariosDTO usuario=new UsuariosDTO();
        usuario.setCorreo(correo);
        usuario.setContrasenha(contrasenha);
        System.out.println("AAAA");
        usuario.setNombres(nombres);
        usuario.setApellidos(apellidos);
        usuario.setDireccion_envio(direccion_envio);
        usuario.setTelefono(telefono);
        usuario.setTipo_documento(TipoDocumento.valueOf(tipo_documento));
        System.out.println("AAAA");
        usuario.setNumero_documento(numero_documento);
        usuario.setTipo(tipo);
        usuario.setRol(rol);
        System.out.println("AAAA");
        return this.usuarioDAO.insertar(usuario);
    }
    
    public Integer editarPerfil(Integer id_usuario, String nombres, String apellidos, 
            String direccion_envio, String telefono, String tipo_documento, String numero_documento){
        UsuariosDTO usuario=obtenerPorId(id_usuario);
        usuario.setId_usuario(id_usuario);
        usuario.setNombres(nombres);
        usuario.setApellidos(apellidos);
        usuario.setDireccion_envio(direccion_envio);
        usuario.setTelefono(telefono);
        usuario.setTipo_documento(TipoDocumento.valueOf(tipo_documento));
        usuario.setNumero_documento(numero_documento);
        return this.usuarioDAO.modificar(usuario);
    }
    
    public Integer iniciarSesion(String correo, String contrasenha){
        UsuariosDTO usuario = this.usuarioDAO.obtenerPorCorreo(correo);
        if(contrasenha.equals(usuario.getContrasenha()))
            return usuario.getId_usuario();
        return 0;
    }
    
    public UsuariosDTO obtenerPorId(Integer id_usuario){
        return this.usuarioDAO.obtenerPorId(id_usuario);
    }
    
    public ArrayList<GenerosDTO> listarGenerosUsuario(Integer id_usuario){
        return this.usuarioDAO.generarReporteHistorial(id_usuario);
    }
    
    public ArrayList<String> listarTiposDocumento(){
        ArrayList<String> tipos = new ArrayList<>();
        for(TipoDocumento t : TipoDocumento.values()){
            tipos.add(t.toString());
        }
        return tipos;
    }
}
