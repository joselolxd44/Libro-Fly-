package pe.edu.pucp.librofly.bo;

import pe.edu.pucp.librofly.model.ComprobantesDTO;
import pe.edu.pucp.librofly.model.PedidosDTO;
import pe.edu.pucp.librofly.persistance.dao.ComprobanteDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.ComprobanteDAOImpl;

public class ComprobanteBO {
    private ComprobanteDAO comprobanteDAO;
    
    public ComprobanteBO(){
        comprobanteDAO=new ComprobanteDAOImpl();
    }
    
    public Integer Insertar(String tipo, String numero_serie, PedidosDTO pedido_id){
        ComprobantesDTO comprobantesDTO=new ComprobantesDTO();
        comprobantesDTO.setTipo(tipo);
        comprobantesDTO.setNumero_serie(numero_serie);
        comprobantesDTO.setPedido_id(pedido_id);
        return comprobanteDAO.insertar(comprobantesDTO);
    }
    public Integer Modificar(Integer id_comprobante, String tipo, String numero_serie, PedidosDTO pedido_id){
        ComprobantesDTO comprobantesDTO = new ComprobantesDTO();
//        ComprobantesDTO comprobantesDTO=new ComprobantesDTO(id_comprobante, tipo, numero_serie, pedido_id);
        return comprobanteDAO.modificar(comprobantesDTO);
    }
    public Integer Eliminar(Integer id_comprobante){
        ComprobantesDTO comprobantesDTO=new ComprobantesDTO();
        comprobantesDTO.setId_comprobante(id_comprobante);
        return comprobanteDAO.eliminar(comprobantesDTO);
    }
    
    public ComprobantesDTO ObtenerPorId(int id){
        
        return comprobanteDAO.obtenerPorId(id);
    }
}
