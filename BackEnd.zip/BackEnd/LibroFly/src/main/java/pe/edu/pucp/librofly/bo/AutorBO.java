/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.bo;

import pe.edu.pucp.librofly.model.AutoresDTO;
import pe.edu.pucp.librofly.persistance.dao.AutorDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.AutorDAOImpl;

/**
 *
 * @author USUARIO
 */
public class AutorBO {
    private AutorDAO autorDAO;
    
    public AutorBO(){
        this.autorDAO = new AutorDAOImpl();
    }
    
    public Integer insertar(String nombre){
        AutoresDTO autor= new AutoresDTO();
        autor.setNombre_completo(nombre);
        return this.autorDAO.insertar(autor);
    }
    
    public AutoresDTO obtenerPorNombre(String nombre_completo){
        return this.autorDAO.obtenerPorNombre(nombre_completo);
    }
    
    public Integer eliminar(AutoresDTO autor){
        return this.autorDAO.eliminar(autor);
    }
}
