package pe.edu.pucp.librofly.bo;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.AutoresDTO;
import pe.edu.pucp.librofly.model.AutoresLibroDTO;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.model.LibrosDTO;
import pe.edu.pucp.librofly.persistance.dao.LibroDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.LibroDAOImpl;

public class LibroBO {
    private LibroDAO libroDAO;
    
    public LibroBO(){
        libroDAO=new LibroDAOImpl();
    }
    
    public ArrayList<LibrosDTO> visualizarCatalogo(){
        ArrayList<LibrosDTO>listaLibros=this.libroDAO.listarPaginaLibros(0);
//        System.out.println("Catalogo: ");
//        System.out.println("Titulo ----- Precio");
//        for (LibrosDTO libro : listaLibros){
//            System.out.print(libro.getTitulo()+" ----- ");
//            System.out.println(libro.getPrecio());
//        }
        return listaLibros;
    }
    
    public void visualizarDetallesLibro(int id_libro){
        LibrosDTO libro=this.libroDAO.obtenerPorId(id_libro);
        System.out.println("Titulo: " + libro.getTitulo()); 
        System.out.println("Precio: " + libro.getPrecio()); 
        System.out.println("Editorial: " + libro.getEditorial()); 
    }
    
    public void actualizarDisponibilidad(){
//        ArrayList<LibrosDTO>listaLibros=this.libroDAO.listarTodos();
//        for (LibrosDTO libro : listaLibros){
//            if (libro.getStock()==0){
//                libro.setDisponibilidad("Agotado");
//                this.libroDAO.modificar(libro);
//            }
//        }
    }
    
    public ArrayList<LibrosDTO> buscarLibros(String cadena_ingresada){
        ArrayList<LibrosDTO> lista = new ArrayList<>();
//        Boolean encontrado=false;
//        ArrayList<LibrosDTO>listaLibros=this.libroDAO.listarTodos();
//        GeneroBO generoDAO = new GeneroBO();
//        System.out.println("Titulo ----- Precio");
//        for (LibrosDTO libro : listaLibros){
//            GenerosDTO generoAux=generoDAO.ObtenerPorId(libro.getGenero_id().getId_genero());
//            if (titulo.equals(libro.getTitulo()) || autor.equals(libro.getAutor())
//                    || precio.equals(libro.getPrecio()) || disponibilidad.equals(libro.getDisponibilidad())
//                    || genero.getDescripcion().equals(generoAux.getDescripcion())){
//                System.out.print(libro.getTitulo()+" ----- ");
//                System.out.println(libro.getPrecio());
//            }
//        }
        
        return lista;
    }
    
    public Integer Insertar(String titulo, String descripcion, Integer anho, Float peso, Float ancho, 
            Float alto, Integer numero_paginas, String formato, String autores, String editorial, 
            String isbn, Float precio, Integer stock, String url_portada, Integer generoId){
        GeneroBO generobo = new GeneroBO();
        GenerosDTO genero = generobo.ObtenerPorId(generoId);
        LibrosDTO libroDTO=new LibrosDTO();
        libroDTO.setTitulo(titulo);
        libroDTO.setDescripcion(descripcion);
        libroDTO.setAnho(anho);
        libroDTO.setPeso(peso);
        libroDTO.setAncho(ancho);
        libroDTO.setAlto(alto);
        libroDTO.setNumero_paginas(numero_paginas);
        libroDTO.setFormato(formato);
        libroDTO.setEditorial(editorial);
        libroDTO.setIsbn(isbn);
        libroDTO.setPrecio(precio);
        libroDTO.setStock(stock);
        libroDTO.setUrl_portada(url_portada);
        libroDTO.setGenero(genero);
        
        Integer id_libro = libroDAO.insertar(libroDTO);
        
        insertarAutoresLibro(autores,id_libro);
        
        return id_libro;
    }
    
    private void insertarAutoresLibro(String autores,Integer id_libro){
        AutorLibroBO autor_libroBO = new AutorLibroBO();
        String aux = autores;
        int indice;
        int posActual = 1;
        char delim = ',';
        while(autores.length() > posActual){
            indice = aux.indexOf(delim);
            if(indice != -1){
                autor_libroBO.insertar(aux.substring(0, indice),id_libro);
                aux = autores.substring(posActual+indice);
            }else{
                autor_libroBO.insertar(aux,id_libro);
                break;
            }
            posActual += indice+1;
        }
    }
    
    public Integer Modificar(Integer id_libro, Float precio, Integer stock){
        LibrosDTO libroDTO= ObtenerPorId(id_libro);
        if(libroDTO == null){
            return 0;
        }
        libroDTO.setPrecio(precio);
        libroDTO.setStock(stock);
        return libroDAO.modificar(libroDTO);
    }
    public Integer Eliminar(Integer id){
        LibrosDTO libroDTO=new LibrosDTO();
        libroDTO.setId_libro(id);
        return libroDAO.eliminar(libroDTO);
    }
    
    public LibrosDTO ObtenerPorId(int id){
        return libroDAO.obtenerPorId(id);
    }
    
    public ArrayList<AutoresLibroDTO> listarAutoresLibro(Integer id_libro){
        AutorLibroBO autor_libroBO = new AutorLibroBO();
        return autor_libroBO.listarAutoresLibro(id_libro);
    }
}
