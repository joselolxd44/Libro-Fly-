package pe.edu.pucp.librofly.bo;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.MetodosPagoDTO;
import pe.edu.pucp.librofly.persistance.dao.MetodoPagoDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.MetodoPagoDAOImpl;

public class MetodoPagoBO {
    private MetodoPagoDAO metodoPagoDAO;
    
    public MetodoPagoBO(){
        metodoPagoDAO=new MetodoPagoDAOImpl();
    }
    
    public Integer obtenerPKMetodo(String tipo_metodo){
        Integer noEncontrado=-1;
        ArrayList<MetodosPagoDTO>listaMetodos = this.metodoPagoDAO.listarTodos();
        for (MetodosPagoDTO metodoPago : listaMetodos) {
            if (tipo_metodo.equals(metodoPago.getTipo_metodo()))
                return metodoPago.getId_metodo_pago();
        }
        return noEncontrado;
    }
    
    public Integer Insertar(String tipo_metodo){
        MetodosPagoDTO metodosPagoDTO=new MetodosPagoDTO();
        metodosPagoDTO.setTipo_metodo(tipo_metodo);
        return metodoPagoDAO.insertar(metodosPagoDTO);
    }
    public Integer Modificar(Integer id_metodo_pago, String tipo_metodo){
        MetodosPagoDTO metodosPagoDTO=new MetodosPagoDTO(id_metodo_pago, tipo_metodo);
        return metodoPagoDAO.modificar(metodosPagoDTO);
    }
    public Integer Eliminar(Integer id_metodo_pago){
        MetodosPagoDTO metodosPagoDTO=new MetodosPagoDTO();
        metodosPagoDTO.setId_metodo_pago(id_metodo_pago);
        return metodoPagoDAO.eliminar(metodosPagoDTO);
    }
    
    public MetodosPagoDTO ObtenerPorId(int id){
        return metodoPagoDAO.obtenerPorId(id);
    }
}
