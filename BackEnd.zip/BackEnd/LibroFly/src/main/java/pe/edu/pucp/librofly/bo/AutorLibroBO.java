/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.bo;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.AutoresDTO;
import pe.edu.pucp.librofly.model.AutoresLibroDTO;
import pe.edu.pucp.librofly.model.LibrosDTO;
import pe.edu.pucp.librofly.persistance.dao.AutorLibroDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.AutorLibroDAOImpl;

/**
 *
 * @author USUARIO
 */
public class AutorLibroBO {
    private AutorLibroDAO autor_libroDAO;
    
    public AutorLibroBO(){
        this.autor_libroDAO = new AutorLibroDAOImpl();
    }
    
    public void insertar(String nombre_autor, Integer id_libro){
        AutoresLibroDTO autor_libro = new AutoresLibroDTO();
        AutorBO autorBO = new AutorBO();
        AutoresDTO autor = autorBO.obtenerPorNombre(nombre_autor);
        if(autor == null){
            Integer id_autor = autorBO.insertar(nombre_autor);
            autor = new AutoresDTO();
            autor.setId_autor(id_autor);
        }
        autor_libro.setAutor(autor);
        LibrosDTO libro = new LibrosDTO();
        libro.setId_libro(id_libro);
        autor_libro.setLibro(libro);
        this.autor_libroDAO.insertar(autor_libro);
    }
    
    public ArrayList<AutoresLibroDTO> listarAutoresLibro(Integer id_libro){
        return this.autor_libroDAO.listarAutoresDeLibro(id_libro);
    }
}
