package pe.edu.pucp.librofly.bo;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import pe.edu.pucp.librofly.model.UsuariosDTO;
import pe.edu.pucp.librofly.model.LibrosDTO;
import pe.edu.pucp.librofly.model.MetodosPagoDTO;
import pe.edu.pucp.librofly.model.PedidosDTO;
import pe.edu.pucp.librofly.persistance.dao.PedidoDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.PedidoDAOImpl;

public class PedidoBO {

    private PedidoDAO pedidoDAO;

    public PedidoBO() {
        pedidoDAO = new PedidoDAOImpl();
    }
    
    public Integer pagarLibros(Integer cantidad, LibrosDTO libro, UsuariosDTO usuario, MetodosPagoDTO metodoPago){
        Date fecha=Date.valueOf(LocalDate.now());
        Float total=libro.getPrecio()*cantidad;
        String estado="Cancelado";
        
        return this.Insertar(fecha, total, estado, cantidad, libro, usuario, metodoPago);
    }
    
    public ArrayList<PedidosDTO> visualizarHistorialDeUsuario(Integer id_usuario){
        System.out.println("Historial");
        ArrayList<PedidosDTO>listaPedidos=this.pedidoDAO.listarHistorialUsuario(id_usuario);
        return listaPedidos;
//        System.out.println("Historial de pedidos del usuario con id " + id_usuario);
//        System.out.printf("%-30s | %-10s | %-10s | %-10s | %-10s%n", "Titulo", "Cantidad", "Total", "Estado", "Fecha");
//        for (PedidosDTO pedido: listaPedidos){
//            System.out.printf("%-30s | %5d | %8f", pedido.getLibro_id().getTitulo(), pedido.getCantidad(), pedido.getTotal());
//            System.out.printf("%-15s | %tF%n", pedido.getEstado(), pedido.getFecha());
//        }
    }
    
    public void reporteLibros(Date fechaIni, Date fechaFin){
//        ArrayList<PedidosDTO>listaPedidos = this.pedidoDAO.listarPorPeriodo(fechaIni, fechaFin);
//        System.out.println("Libro ID ----- Fecha ----- Cantidad Vendida");
//        for (PedidosDTO pedido : listaPedidos){
//            System.out.println(pedido.getLibro_id().getId_libro() + " ----- " +
//                    pedido.getFecha() + " ----- " +
//                    pedido.getCantidad());
//        }
        
    }

    public Integer Insertar(Date fecha, Float total,
            String estado, Integer cantidad, LibrosDTO libro_id,
            UsuariosDTO cliente_id, MetodosPagoDTO metodo_pago_id) {

        PedidosDTO pedidosDTO = new PedidosDTO();
        pedidosDTO.setFecha(fecha);
        pedidosDTO.setTotal(total);
        pedidosDTO.setEstado(estado);
        pedidosDTO.setCantidad(cantidad);
        return pedidoDAO.insertar(pedidosDTO);
    }

    public Integer Modificar(Integer id_pedido, Date fecha, Float total,
            String estado, Integer cantidad, LibrosDTO libro_id,
            UsuariosDTO cliente_id, MetodosPagoDTO metodo_pago_id) {

        PedidosDTO pedidosDTO = new PedidosDTO();
        return pedidoDAO.modificar(pedidosDTO);
    }

    public Integer Eliminar(Integer id_pedido) {

        PedidosDTO pedidosDTO = new PedidosDTO();
        pedidosDTO.setId_pedido(id_pedido);
        return pedidoDAO.eliminar(pedidosDTO);
    }

    public PedidosDTO ObtenerPorId(int id) {
        return pedidoDAO.obtenerPorId(id);
    }
}
