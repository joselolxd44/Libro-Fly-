/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.bo;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.LibrosDTO;
import pe.edu.pucp.librofly.model.LineasCarritoDTO;
import pe.edu.pucp.librofly.model.UsuariosDTO;
import pe.edu.pucp.librofly.persistance.dao.LineaCarritoDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.LineaCarritoDAOImpl;

/**
 *
 * @author USUARIO
 */
public class CarritoBO {
    private LineaCarritoDAO linea_carritoDAO;
    
    public CarritoBO(){
        this.linea_carritoDAO = new LineaCarritoDAOImpl();
    }
    
    public Integer insertarLineaCarrito(Integer id_usuario, Integer id_libro, Integer cantidad){
        LineasCarritoDTO linea_carrito = this.linea_carritoDAO.obtenerPorId(id_usuario, id_libro);
        if(linea_carrito == null){
            linea_carrito = llenarIds(id_usuario, id_libro);
            linea_carrito.setCantidad(cantidad);
            return this.linea_carritoDAO.insertar(linea_carrito);
        }else{
            return modificarLineaCarrito(id_usuario, id_libro, linea_carrito.getCantidad()+cantidad);
        }
    }
    
    public Integer modificarLineaCarrito(Integer id_usuario, Integer id_libro, Integer cantidad){
        LineasCarritoDTO linea_carrito = llenarIds(id_usuario, id_libro);
        linea_carrito.setCantidad(cantidad);
        return this.linea_carritoDAO.modificar(linea_carrito);
    }
    
    public Integer eliminarLineaCarrito(Integer id_usuario, Integer id_libro){
        LineasCarritoDTO linea_carrito = llenarIds(id_usuario, id_libro);
        return this.linea_carritoDAO.eliminar(linea_carrito);
        
    }
    
    private LineasCarritoDTO llenarIds(Integer id_usuario, Integer id_libro){
        LineasCarritoDTO linea_carrito = new LineasCarritoDTO();
        UsuariosDTO usuario = new UsuariosDTO();
        LibrosDTO libro = new LibrosDTO();
        usuario.setId_usuario(id_usuario);
        libro.setId_libro(id_libro);
        linea_carrito.setUsuario(usuario);
        linea_carrito.setLibro(libro);
        return linea_carrito;
    }
    
    public Integer vaciarCarrito(Integer id_usuario){
        this.linea_carritoDAO.vaciarCarrito(id_usuario);
        return 1;
    }
    
    public ArrayList<LineasCarritoDTO> listarCarritoUsuario(Integer id_usuario){
        ArrayList<LineasCarritoDTO> lista = this.linea_carritoDAO.listarCarritoUsuario(id_usuario);
        if(lista == null){
            lista = new ArrayList<LineasCarritoDTO>();
        }
        return lista;
    }
}
