package pe.edu.pucp.librofly.db.util;

public enum MotorDeBaseDeDatos {
   MYSQL, MSSQL 
}
