package pe.edu.pucp.librofly.db;

import java.sql.Connection;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import pe.edu.pucp.librofly.db.util.Cifrado;

public class DBManagerTest {
    
    public DBManagerTest() {
    }
    
    //esto es para obtener la contraseña encriptada que va en properties
//    @Test
//    public void hallarContra(){
//        //luego de hallar su contraseña comenten esto
//        System.out.println("Contraseña encriptada:" + Cifrado.descifrarMD5("GFvzT/oALwhgBEPlFFB2EA=="));
//        System.out.println("Contraseña encriptada:" + Cifrado.descifrarMD5("4tSwh48vTQd35klmMjaRuQ=="));
//        System.out.println("Contraseña encriptada:" + Cifrado.cifrarMD5("usuario123"));
//        System.out.println("Contraseña encriptada:" + Cifrado.cifrarMD5("gokudios123"));
//        System.out.println("Contraseña encriptada:" + Cifrado.cifrarMD5("lab11veinteable"));
//    }
    
    @org.junit.jupiter.api.Test
    public void testGetInstance() {
        System.out.println("getInstance");                
        DBManager dBManager = DBManager.getInstance();
        assertNotNull(dBManager);
    }
    @org.junit.jupiter.api.Test
    public void testGetConnection() {
        System.out.println("getConnection");                
        DBManager dBManager = DBManager.getInstance();
        Connection conexion = dBManager.getConnection();
        assertNotNull(conexion);
    }
}
