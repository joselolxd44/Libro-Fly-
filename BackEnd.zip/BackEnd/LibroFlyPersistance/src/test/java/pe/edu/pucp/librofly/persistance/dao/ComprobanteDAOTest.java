package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import pe.edu.pucp.librofly.model.PedidosDTO;
import pe.edu.pucp.librofly.model.ComprobantesDTO;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.model.LibrosDTO;
import pe.edu.pucp.librofly.model.MetodosPagoDTO;
import pe.edu.pucp.librofly.model.UsuariosDTO;
import pe.edu.pucp.librofly.persistance.daoImpl.ComprobanteDAOImpl;
import pe.edu.pucp.librofly.persistance.daoImpl.GeneroDAOImpl;
import pe.edu.pucp.librofly.persistance.daoImpl.LibroDAOImpl;
import pe.edu.pucp.librofly.persistance.daoImpl.MetodoPagoDAOImpl;
import pe.edu.pucp.librofly.persistance.daoImpl.PedidoDAOImpl;
import pe.edu.pucp.librofly.persistance.daoImpl.UsuarioDAOImpl;

public class ComprobanteDAOTest {
    private ComprobanteDAO comprobanteDAO;
    
    public ComprobanteDAOTest(){
        this.comprobanteDAO=new ComprobanteDAOImpl();
    }
    
//    @Test
//    public void testInsertar(){
//        System.out.println("insertar (comprobante)");
//        ArrayList<Integer> listaComprobanteId=new ArrayList<>();
//        insertarComprobantes(listaComprobanteId);
//        eliminarTodo();
//    }
////    
//    private void insertarComprobantes(ArrayList<Integer> listaComprobanteId){
//        ComprobantesDTO comprobante;
//        Integer resultado;
//        PedidosDTO pedido;
//        LibrosDTO libro;
//        PedidoDAO pedidoDAO = new PedidoDAOImpl();
//        LibroDAO libroDAO = new LibroDAOImpl();
//        MetodoPagoDAO metodoPagoDAO = new MetodoPagoDAOImpl();
//        Integer id_pedido,id_libro,id_metodo,id_usuario;
//        
//        GenerosDTO generoAux=new GenerosDTO();
//        generoAux.setDescripcion("Drama");
//        GeneroDAO gen = new GeneroDAOImpl();
//        Integer id_genero = gen.insertar(generoAux);
//        generoAux.setId_genero(id_genero);
//        
//        MetodosPagoDTO metodo=new MetodosPagoDTO();
//        metodo.setTipo_metodo("Metodo");
//        id_metodo=metodoPagoDAO.insertar(metodo);
//        metodo.setId_metodo_pago(id_metodo);
//        
//        UsuariosDTO usuario = new UsuariosDTO();
//        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
//        usuario.setNombres("Usuario");
//        usuario.setApellidos("1");
//        usuario.setCorreo("usuario@hotmail.com");
//        usuario.setContrasenha("usuario123");
//        usuario.setDireccion_envio("Calle123");
//        usuario.setTelefono("964123415");
//        usuario.setDni_cliente("50203142");
//        usuario.setTipo('C');
//        id_usuario = usuarioDAO.insertar(usuario);
//        usuario.setId_usuario(id_usuario);
//
//        for(int i=0;i<3;i++){
//            libro=new LibrosDTO();
//            libro.setTitulo("titulo"+i);
//            libro.setAutor("autor"+i);
//            libro.setEditorial("editorial"+i);
//            libro.setIsbn("000111"+i);
//            libro.setPrecio((float)12.3+i);
//            libro.setStock(5+i);
//            libro.setDisponibilidad("en venta");
//            libro.setGenero_id(generoAux);
//            id_libro = libroDAO.insertar(libro);
//            libro.setId_libro(id_libro);
//            
//            pedido = new PedidosDTO();
//            pedido.setTotal((float)12.25);
//            pedido.setCantidad(3);
//            pedido.setLibro_id(libro);
//            pedido.setCliente_id(usuario);
//            pedido.setMetodo_pago_id(metodo);
//            id_pedido = pedidoDAO.insertar(pedido);
//            pedido.setId_pedido(id_pedido);
//            
//            comprobante = new ComprobantesDTO();
//            comprobante.setNumero_serie("12345678"+i);
//            comprobante.setPedido_id(pedido);
//            comprobante.setTipo("Boleta");
//            resultado=this.comprobanteDAO.insertar(comprobante);
//            assertTrue(resultado != 0);
//            
//            listaComprobanteId.add(resultado);
//        }
//        
//    }
//    
//     @Test
//    public void testObtenerPorId() {
//        System.out.println("obtenerPorId");
//        ArrayList<Integer> listaComprobantesId = new ArrayList<>();
//        insertarComprobantes(listaComprobantesId);
//        ComprobantesDTO comprobante = this.comprobanteDAO.obtenerPorId(listaComprobantesId.get(0));
//        assertEquals(comprobante.getId_comprobante(), listaComprobantesId.get(0));
//        
//        comprobante = this.comprobanteDAO.obtenerPorId(listaComprobantesId.get(1));
//        assertEquals(comprobante.getId_comprobante(), listaComprobantesId.get(1));
//        
//        comprobante = this.comprobanteDAO.obtenerPorId(listaComprobantesId.get(2));
//        assertEquals(comprobante.getId_comprobante(), listaComprobantesId.get(2));
//        eliminarTodo();
//    }
    
//    @Test
//    public void testListarTodos() {
//        System.out.println("listarTodos");
//        ArrayList<Integer> listaComprobantesId = new ArrayList<>();
//        insertarComprobantes(listaComprobantesId);
//        
//        ArrayList<ComprobantesDTO> listaComprobantes = this.comprobanteDAO.listarTodos();
//        assertEquals(listaComprobantesId.size(), listaComprobantes.size());
//        for (Integer i = 0; i < listaComprobantes.size(); i++) {
//            assertEquals(listaComprobantesId.get(i), listaComprobantes.get(i).getId_comprobante());
//        }
//        eliminarTodo();
//    }
//    
    private void eliminarTodo(){   
//        LibroDAO libroDAO = new LibroDAOImpl();            
//        PedidoDAO pedidoDAO = new PedidoDAOImpl();
//        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
//        MetodoPagoDAO metodoPagoDAO = new MetodoPagoDAOImpl();
//        GeneroDAO gen = new GeneroDAOImpl();
//        ArrayList<ComprobantesDTO> listaComprobantes = this.comprobanteDAO.listarTodos();
//        for (Integer i = 0; i < listaComprobantes.size(); i++) {
//            Integer resultado = this.comprobanteDAO.eliminar(listaComprobantes.get(i));
//            assertNotEquals(0, resultado);
//            ComprobantesDTO comprobante = this.comprobanteDAO.obtenerPorId(listaComprobantes.get(i).getId_comprobante());
//            assertNull(comprobante);
//            System.out.println(listaComprobantes.get(i).getPedido_id().getLibro_id().getId_libro());
//            pedidoDAO.eliminar(listaComprobantes.get(i).getPedido_id());
//            libroDAO.eliminar(listaComprobantes.get(i).getPedido_id().getLibro_id());
//        }
//        gen.eliminar(listaComprobantes.get(0).getPedido_id().getLibro_id().getGenero_id());
//        usuarioDAO.eliminar(listaComprobantes.get(0).getPedido_id().getCliente_id());
//        metodoPagoDAO.eliminar(listaComprobantes.get(0).getPedido_id().getMetodo_pago_id());
    }
}
