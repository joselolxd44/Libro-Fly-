package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import pe.edu.pucp.librofly.model.MetodosPagoDTO;
import pe.edu.pucp.librofly.persistance.daoImpl.MetodoPagoDAOImpl;

public class MetodoPagoDAOTest {
    private MetodoPagoDAO metodoPagoDAO;
    
    public MetodoPagoDAOTest(){
        this.metodoPagoDAO=new MetodoPagoDAOImpl();
    }
    
//   @Test
//    public void testInsertar(){
//        System.out.println("insertar (metodo_pago)");
//        ArrayList<Integer> listaMetodoPagoId=new ArrayList<>();
//        insertarMetodosPago(listaMetodoPagoId);
//        eliminarTodo();
//    }
//    
//    private void insertarMetodosPago(ArrayList<Integer> listaMetodoPagoId){
//        MetodosPagoDTO metodo;
//        Integer resultado;
//        
//        for(int i=0;i<3;i++){
//            metodo=new MetodosPagoDTO();
//            metodo.setTipo_metodo("Metodo"+i);
//            resultado=this.metodoPagoDAO.insertar(metodo);
//            assertTrue(resultado != 0);
//            
//            listaMetodoPagoId.add(resultado);
//        }
//        
//    }
//    
//     @Test
//    public void testObtenerPorId() {
//        System.out.println("obtenerPorId");
//        ArrayList<Integer> listaMetodoPagoId = new ArrayList<>();
//        insertarMetodosPago(listaMetodoPagoId);
//        MetodosPagoDTO metodo = this.metodoPagoDAO.obtenerPorId(listaMetodoPagoId.get(0));
//        assertEquals(metodo.getId_metodo_pago(), listaMetodoPagoId.get(0));
//        
//        metodo = this.metodoPagoDAO.obtenerPorId(listaMetodoPagoId.get(1));
//        assertEquals(metodo.getId_metodo_pago(), listaMetodoPagoId.get(1));
//        
//        metodo = this.metodoPagoDAO.obtenerPorId(listaMetodoPagoId.get(2));
//        assertEquals(metodo.getId_metodo_pago(), listaMetodoPagoId.get(2));
//        eliminarTodo();
//    }
//    
//    @Test
//    public void testListarTodos() {
//        System.out.println("listarTodos");
//        ArrayList<Integer> listaMetodoPagoId = new ArrayList<>();
//        insertarMetodosPago(listaMetodoPagoId);
//        
//        ArrayList<MetodosPagoDTO> listaMetodosPago = this.metodoPagoDAO.listarTodos();
//        assertEquals(listaMetodoPagoId.size(), listaMetodosPago.size());
//        for (Integer i = 0; i < listaMetodosPago.size(); i++) {
//            assertEquals(listaMetodoPagoId.get(i), listaMetodosPago.get(i).getId_metodo_pago());
//        }
//        eliminarTodo();
//    }
//    
//    @Test
//    public void testModificar() {
//        System.out.println("modificar");
//        ArrayList<Integer> listaMetodoPagoId = new ArrayList<>();
//        insertarMetodosPago(listaMetodoPagoId);
//        
//        ArrayList<MetodosPagoDTO> listaMetodosPago = this.metodoPagoDAO.listarTodos();
//        assertEquals(listaMetodoPagoId.size(), listaMetodosPago.size());
//        for (Integer i = 0; i < listaMetodoPagoId.size(); i++) {
//            listaMetodosPago.get(i).setTipo_metodo("NuevoMetodo" + i.toString());
//            this.metodoPagoDAO.modificar(listaMetodosPago.get(i));
//        }
//        
//        ArrayList<MetodosPagoDTO> listaMetodosModificados = this.metodoPagoDAO.listarTodos();
//        assertEquals( listaMetodosPago.size(), listaMetodosModificados.size());
//        for (Integer i = 0; i < listaMetodosModificados.size(); i++) {
//            assertEquals(listaMetodosModificados.get(i).getTipo_metodo(), listaMetodosModificados.get(i).getTipo_metodo());
//        }
//        eliminarTodo();
//    }
//    
//    private void eliminarTodo(){                
//        ArrayList<MetodosPagoDTO> listaMetodosPago = this.metodoPagoDAO.listarTodos();
//        for (Integer i = 0; i < listaMetodosPago.size(); i++) {
//            Integer resultado = this.metodoPagoDAO.eliminar(listaMetodosPago.get(i));
//            assertNotEquals(0, resultado);
//            MetodosPagoDTO metodo = this.metodoPagoDAO.obtenerPorId(listaMetodosPago.get(i).getId_metodo_pago());
//            assertNull(metodo);
//        }
//    }
}
