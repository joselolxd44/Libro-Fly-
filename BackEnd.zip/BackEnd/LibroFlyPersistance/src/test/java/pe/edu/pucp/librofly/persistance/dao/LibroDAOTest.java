package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.model.LibrosDTO;
import pe.edu.pucp.librofly.persistance.daoImpl.GeneroDAOImpl;
//import pe.edu.pucp.librofly.persistance.dao.LibroDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.LibroDAOImpl;

public class LibroDAOTest {
    private LibroDAO libroDAO;
    
    public LibroDAOTest(){
        this.libroDAO=new LibroDAOImpl();
    }
    
//    @Test
//    public void testInsertar(){
//        System.out.println("insertar (libro)");
//        ArrayList<Integer> listaLibroId=new ArrayList<>();
//        insertarLibros(listaLibroId);
//        eliminarTodo();
//    }
//    
//    private void insertarLibros(ArrayList<Integer> listaLibroId){
//        LibrosDTO libro;
//        GenerosDTO generoAux;
//        Integer resultado;
//        Integer id_genero;
//        generoAux=new GenerosDTO();
//        generoAux.setDescripcion("Drama");
//        GeneroDAO gen = new GeneroDAOImpl();
//        id_genero = gen.insertar(generoAux);
//        generoAux.setId_genero(id_genero);
//        
//        for(int i=0;i<3;i++){
//            libro=new LibrosDTO();
//            libro.setTitulo("titulo"+i);
//            libro.setAutor("autor"+i);
//            libro.setEditorial("editorial"+i);
//            libro.setIsbn("000111"+i);
//            libro.setPrecio((float)12.3+i);
//            libro.setStock(5+i);
//            libro.setDisponibilidad("en venta");
//            libro.setGenero_id(generoAux);
//            resultado=this.libroDAO.insertar(libro);
//            assertTrue(resultado != 0);
//            
//            listaLibroId.add(resultado);
//        }
////        
////        gen.eliminar(generoAux);
//        
//    }
//    
//     @Test
//    public void testObtenerPorId() {
//        System.out.println("obtenerPorId");
//        ArrayList<Integer> listaLibrosId = new ArrayList<>();
//        insertarLibros(listaLibrosId);
//        LibrosDTO libro = this.libroDAO.obtenerPorId(listaLibrosId.get(0));
//        assertEquals(libro.getId_libro(), listaLibrosId.get(0));
//        
//        libro = this.libroDAO.obtenerPorId(listaLibrosId.get(1));
//        assertEquals(libro.getId_libro(), listaLibrosId.get(1));
//        
//        libro = this.libroDAO.obtenerPorId(listaLibrosId.get(2));
//        assertEquals(libro.getId_libro(), listaLibrosId.get(2));
//        eliminarTodo();
//    }
    
//    @Test
//    public void testListarTodos() {
//        System.out.println("listarTodos");
//        ArrayList<Integer> listaLibroId = new ArrayList<>();
//        insertarLibros(listaLibroId);
//        
//        ArrayList<LibrosDTO> listaLibros = this.libroDAO.listarTodos();
//        assertEquals(listaLibroId.size(), listaLibros.size());
//        for (Integer i = 0; i < listaLibros.size(); i++) {
//            assertEquals(listaLibroId.get(i), listaLibros.get(i).getId_libro());
//        }
//        eliminarTodo();
//    }
    
//    @Test
//    public void testModificar() {
//        System.out.println("modificar");
//        ArrayList<Integer> listaLibroId = new ArrayList<>();
//        insertarLibros(listaLibroId);
//        
//        ArrayList<LibrosDTO> listaLibros = this.libroDAO.listarTodos();
//        assertEquals(listaLibroId.size(), listaLibros.size());
//        for (Integer i = 0; i < listaLibroId.size(); i++) {
//            listaLibros.get(i).setAutor("NuevoNombre" + i.toString());
//            listaLibros.get(i).setEditorial("NuevaEditorial" + i.toString());
//            this.libroDAO.modificar(listaLibros.get(i));
//        }
//        
//        ArrayList<LibrosDTO> listaLibrosModificados = this.libroDAO.listarTodos();
//        assertEquals( listaLibros.size(), listaLibrosModificados.size());
//        for (Integer i = 0; i < listaLibros.size(); i++) {
//            assertEquals(listaLibros.get(i).getAutor(), listaLibrosModificados.get(i).getAutor());
//            assertEquals(listaLibros.get(i).getEditorial(), listaLibrosModificados.get(i).getEditorial());
//        }
//        eliminarTodo();
//    }
    
    private void eliminarTodo(){                
//        ArrayList<LibrosDTO> listaLibros = this.libroDAO.listarTodos();
//        for (Integer i = 0; i < listaLibros.size(); i++) {
//            Integer resultado = this.libroDAO.eliminar(listaLibros.get(i));
//            assertNotEquals(0, resultado);
//            LibrosDTO libro = this.libroDAO.obtenerPorId(listaLibros.get(i).getId_libro());
//            assertNull(libro);
//        }
//        GeneroDAO gen = new GeneroDAOImpl();
//        gen.eliminar(listaLibros.get(0).getGenero_id());
    }
}
