package pe.edu.pucp.librofly.persistance.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import pe.edu.pucp.librofly.model.LibrosDTO;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.model.MetodosPagoDTO;
import pe.edu.pucp.librofly.model.PedidosDTO;
import pe.edu.pucp.librofly.model.UsuariosDTO;
import pe.edu.pucp.librofly.persistance.daoImpl.GeneroDAOImpl;
import pe.edu.pucp.librofly.persistance.daoImpl.LibroDAOImpl;
import pe.edu.pucp.librofly.persistance.daoImpl.MetodoPagoDAOImpl;
import pe.edu.pucp.librofly.persistance.daoImpl.PedidoDAOImpl;
import pe.edu.pucp.librofly.persistance.daoImpl.UsuarioDAOImpl;

public class PedidoDAOTest {
    private PedidoDAO pedidoDAO;
    
    public PedidoDAOTest(){
        this.pedidoDAO=new PedidoDAOImpl();
    }
    
//    @Test
//    public void testInsertar(){
//        System.out.println("insertar (pedido)");
//        ArrayList<Integer> listaPedidoId=new ArrayList<>();
//        insertarPedidos(listaPedidoId);
////        eliminarTodo();
//    }
//    
//    private void insertarPedidos(ArrayList<Integer> listaPedidoId){
//        PedidosDTO pedido;
//        Integer resultado;
//        MetodosPagoDTO metodo;
//        MetodoPagoDAO metodoPagoDAO = new MetodoPagoDAOImpl();
//        LibrosDTO libro;
//        LibroDAO libroDAO = new LibroDAOImpl();
//        Integer id_libro, id_usuario, id_metodo;
//        
//        GenerosDTO genero=new GenerosDTO();
//        genero.setDescripcion("Drama");
//        GeneroDAO gen = new GeneroDAOImpl();
//        Integer id_genero = gen.insertar(genero);
//        genero.setId_genero(id_genero);
//        
//        UsuariosDTO usuario = new UsuariosDTO();
//        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
//        usuario.setNombres("Usuario");
//        usuario.setApellidos("1");
//        usuario.setCorreo("usuario@hotmail.com");
//        usuario.setContrasenha("usuario123");
//        usuario.setDireccion_envio("Calle123");
//        usuario.setTelefono("964123415");
//        usuario.setDni_cliente("50203142");
//        usuario.setTipo('C');
//        id_usuario = usuarioDAO.insertar(usuario);
//        usuario.setId_usuario(id_usuario);
//        
//        for(int i=0;i<3;i++){
//            libro=new LibrosDTO();
//            libro.setTitulo("titulo"+(i+1));
//            libro.setAutor("autor"+(i+1));
//            libro.setEditorial("editorial"+(i+1));
//            libro.setIsbn("000111"+i);
//            libro.setPrecio((float)12.3+i);
//            libro.setStock(5+i);
//            libro.setDisponibilidad("en venta");
//            libro.setGenero_id(genero);
//            id_libro = libroDAO.insertar(libro);
//            libro.setId_libro(id_libro);
//            
//            metodo=new MetodosPagoDTO();
//            metodo.setTipo_metodo("Metodo"+i);
//            id_metodo=metodoPagoDAO.insertar(metodo);
//            metodo.setId_metodo_pago(id_metodo);
//            
//            pedido = new PedidosDTO();
//            pedido.setCliente_id(usuario);
//            pedido.setLibro_id(libro);
//            pedido.setMetodo_pago_id(metodo);
//            pedido.setFecha(Date.valueOf(LocalDate.of(2025, Month.MARCH, 19+i)));
//            pedido.setCantidad(2);
//            pedido.setTotal(libro.getPrecio()*pedido.getCantidad());
//            pedido.setEstado("Pagado");
//            
//            resultado = pedidoDAO.insertar(pedido);
//            
//            assertTrue(resultado != 0);
//            
//            listaPedidoId.add(resultado);
//        }
//        
//    }
    
//     @Test
//    public void testObtenerPorId() {
//        System.out.println("obtenerPorId");
//        ArrayList<Integer> listaPedidoId = new ArrayList<>();
//        insertarPedidos(listaPedidoId);
//        PedidosDTO pedido = this.pedidoDAO.obtenerPorId(listaPedidoId.get(0));
//        assertEquals(pedido.getId_pedido(), listaPedidoId.get(0));
//        
//        pedido = this.pedidoDAO.obtenerPorId(listaPedidoId.get(1));
//        assertEquals(pedido.getId_pedido(), listaPedidoId.get(1));
//        
//        pedido = this.pedidoDAO.obtenerPorId(listaPedidoId.get(2));
//        assertEquals(pedido.getId_pedido(), listaPedidoId.get(2));
//        eliminarTodo();
//    }
    
//    @Test
//    public void testListarTodos() {
//        System.out.println("listarTodos");
//        ArrayList<Integer> listaPedidoId = new ArrayList<>();
//        insertarPedidos(listaPedidoId);
//        
//        ArrayList<PedidosDTO> listaPedidos = this.pedidoDAO.listarTodos();
//        assertEquals(listaPedidoId.size(), listaPedidos.size());
//        for (Integer i = 0; i < listaPedidos.size(); i++) {
//            assertEquals(listaPedidoId.get(i), listaPedidos.get(i).getId_pedido());
//        }
//        eliminarTodo();
//    }
//    
//    @Test
//    public void testModificar() {
//        System.out.println("modificar");
//        ArrayList<Integer> listaGeneroId = new ArrayList<>();
//        insertarPedidos(listaGeneroId);
//        
//        ArrayList<PedidosDTO> listaPedidos = this.pedidoDAO.listarTodos();
//        assertEquals(listaGeneroId.size(), listaPedidos.size());
//        for (Integer i = 0; i < listaGeneroId.size(); i++) {
//            listaPedidos.get(i).setEstado("Entregado");
//            this.pedidoDAO.modificar(listaPedidos.get(i));
//        }
//        
//        ArrayList<PedidosDTO> listaPedidosModificados = this.pedidoDAO.listarTodos();
//        assertEquals( listaPedidos.size(), listaPedidosModificados.size());
//        for (Integer i = 0; i < listaPedidos.size(); i++) {
//            assertEquals(listaPedidos.get(i).getEstado(), listaPedidosModificados.get(i).getEstado());
//        }
//        eliminarTodo();
//    }
    
//    private void eliminarTodo(){                
//        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
//        GeneroDAO generoDAO = new GeneroDAOImpl();
//        LibroDAO libroDAO = new LibroDAOImpl();
//        MetodoPagoDAO metodoDAO = new MetodoPagoDAOImpl();
//        ArrayList<PedidosDTO> listaPedidos = this.pedidoDAO.listarTodos();
//        for (Integer i = 0; i < listaPedidos.size(); i++) {
//                Integer resultado = this.pedidoDAO.eliminar(listaPedidos.get(i));
//                assertNotEquals(0, resultado);
//                PedidosDTO pedido = this.pedidoDAO.obtenerPorId(listaPedidos.get(i).getId_pedido());
//                assertNull(pedido);
//                libroDAO.eliminar(listaPedidos.get(i).getLibro_id());
//                metodoDAO.eliminar(listaPedidos.get(i).getMetodo_pago_id());
//        }
//        generoDAO.eliminar(listaPedidos.get(0).getLibro_id().getGenero_id());
//        usuarioDAO.eliminar(listaPedidos.get(0).getCliente_id());
//    }
//    
}
