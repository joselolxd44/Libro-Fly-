package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
//import pe.edu.pucp.librofly.db.util.Cifrado;
import pe.edu.pucp.librofly.model.UsuariosDTO;
import pe.edu.pucp.librofly.persistance.daoImpl.UsuarioDAOImpl;

public class UsuarioDAOTest {
    private UsuarioDAO usuarioDAO;
    
    public UsuarioDAOTest (){
        this.usuarioDAO = new UsuarioDAOImpl();
    }
    
//    @Test
//    public void testLogin(){
//        UsuariosDTO usuario;
//        usuario=this.usuarioDAO.obtenerPorCorreo("usuario@hotmail.com");
//        System.out.println(usuario.getCorreo());
//    }
    
//    @Test
//    public void testRegistro(){
//        UsuariosDTO usuario=new UsuariosDTO(Integer.MIN_VALUE, "correo1", "M7T48z9oZfJ77PtVTozbEg==", "nombres1", "apellidos1", "direccion_envio1", "telefono1", "dni_cliente1", "rol1", "tipo1");
//        Integer idPrincipal=this.usuarioDAO.insertar(usuario);
//        System.out.println(idPrincipal);
//    }
    
//    @Test
//    public void testInsertar(){
//        System.out.println("insertar (usuario)");
//        ArrayList<Integer> listaUsuarioId=new ArrayList<>();
////        insertarUsuarios(listaUsuarioId);
//        String correo = "Correo0@hotmail.com";
//        UsuariosDTO usuario = this.usuarioDAO.obtenerPorCorreo(correo);
//        System.out.println(usuario.getCorreo() + " " + usuario.getContrasenha());
////        eliminarClientes();
//    }
//    
//    private void insertarClientes(ArrayList<Integer> listaUsuarioId) {
//        UsuariosDTO usuario;
//        Integer resultado;
//        this.usuarioDAO = new ClienteDAOImpl();
//        usuario = new UsuariosDTO();
//        usuario.setCorreo("Correo@hotmail.com");
//        usuario.setContrasenha("Contrasenha");
//        usuario.setNombres("Nombre");
//        usuario.setApellidos("Apellido");
//        usuario.setDireccion_envio("Calle12");
//        usuario.setTelefono("124567");
//        usuario.setDni_cliente("9999999");
//        resultado = this.usuarioDAO.insertar(usuario);
//        listaUsuarioId.add(resultado);
//    }
//    
//    private void insertarUsuarios(ArrayList<Integer> listaUsuarioId){
//        UsuariosDTO usuario;
//        Integer resultado;
////        Integer id_genero;
//        for(int i=0;i<3;i++){
//            usuario = new UsuariosDTO();
//            usuario.setCorreo("Correo"+i+"@hotmail.com");
//            usuario.setContrasenha("Contrasenha"+i);
//            usuario.setNombres("Nombre"+(i+1));
//            usuario.setApellidos("Apellido"+(i+1));
//            if(i%2==0){
//                usuario.setDireccion_envio("Calle12"+i);
//                usuario.setTelefono("124567"+(2*i));
//                usuario.setDni_cliente("9999999"+(2*i));
//                usuario.setTipo('C');
//            }
//            else{
//                usuario.setRol("Jefe");
//                usuario.setTipo('A');
//            }
//            resultado=this.usuarioDAO.insertar(usuario);
//            assertTrue(resultado != 0);
//            
//            listaUsuarioId.add(resultado);
//        }
//        
//    }
//    
//     @Test
//    public void testObtenerPorId() {
//        this.usuarioDAO = new ClienteDAOImpl();
//        System.out.println("obtenerPorId");
//        ArrayList<Integer> listaUsuarioId = new ArrayList<>();
//        insertarUsuarios(listaUsuarioId);
//        UsuariosDTO usuario = this.usuarioDAO.obtenerPorId(1);
//        String cad = "";
//        cad += usuario.getId_usuario() + " ";
//        cad += usuario.getCorreo()+ " ";
//        cad += usuario.getContrasenha()+ " ";
//        cad += usuario.getNombres()+ " ";
//        cad += usuario.getApellidos()+ " ";
//        cad += usuario.getDireccion_envio()+ " ";
//        cad += usuario.getDni_cliente()+ " ";
//        cad += usuario.getTelefono()+ " ";
//        System.out.println(cad);
//        
//        usuario = this.usuarioDAO.obtenerPorId(listaUsuarioId.get(1));
//        assertEquals(usuario.getId_usuario(), listaUsuarioId.get(1));
//        
//        usuario = this.usuarioDAO.obtenerPorId(listaUsuarioId.get(2));
//        assertEquals(usuario.getId_usuario(), listaUsuarioId.get(2));
//        eliminarTodo();
//    }
    
//    @Test
//    public void testListarTodos() {
//        System.out.println("listarTodos");
//        ArrayList<Integer> listaUsuarioId = new ArrayList<>();
//        insertarUsuarios(listaUsuarioId);
//        
//        ArrayList<UsuariosDTO> listaUsuarios = this.usuarioDAO.listarTodos();
//        assertEquals(listaUsuarioId.size(), listaUsuarios.size());
//        for (Integer i = 0; i < listaUsuarios.size(); i++) {
//            assertEquals(listaUsuarioId.get(i), listaUsuarios.get(i).getId_usuario());
//        }
//        eliminarTodo();
//    }
//    
//    @Test
//    public void testModificar() {
//        System.out.println("modificar");
//        ArrayList<Integer> listaUsuarioId = new ArrayList<>();
//        insertarUsuarios(listaUsuarioId);
//        
//        ArrayList<UsuariosDTO> listaUsuarios = this.usuarioDAO.listarTodos();
//        assertEquals(listaUsuarioId.size(), listaUsuarios.size());
//        for (Integer i = 0; i < listaUsuarioId.size(); i++) {
//            listaUsuarios.get(i).setNombres("NuevoNombre" + i.toString());
//            listaUsuarios.get(i).setApellidos("NuevoApellido" + i.toString());
//            this.usuarioDAO.modificar(listaUsuarios.get(i));
//        }
//        
//        ArrayList<UsuariosDTO> listaUsuariosModificados = this.usuarioDAO.listarTodos();
//        assertEquals( listaUsuarios.size(), listaUsuariosModificados.size());
//        for (Integer i = 0; i < listaUsuarios.size(); i++) {
//            assertEquals(listaUsuarios.get(i).getNombres(), listaUsuariosModificados.get(i).getNombres());
//            assertEquals(listaUsuarios.get(i).getApellidos(), listaUsuariosModificados.get(i).getApellidos());
//        }
//        eliminarTodo();
//    }
    
    private void eliminarClientes(){                
//        ArrayList<UsuariosDTO> listaUsuarios = this.usuarioDAO.listarTodos();
//        for (Integer i = 0; i < listaUsuarios.size(); i++) {
//                Integer resultado = this.usuarioDAO.eliminar(listaUsuarios.get(i));
//                assertNotEquals(0, resultado);
//                UsuariosDTO usuario = this.usuarioDAO.obtenerPorId(listaUsuarios.get(i).getId_usuario());
//                assertNull(usuario);
//            }
        UsuariosDTO usuario = new UsuariosDTO();
        usuario.setId_usuario(1);
        Integer resultado = this.usuarioDAO.eliminar(usuario);
        assertNotEquals(0, resultado);
    }
    
    private void eliminarAdministradores(){                
//        ArrayList<UsuariosDTO> listaUsuarios = this.usuarioDAO.listarTodos();
//        for (Integer i = 0; i < listaUsuarios.size(); i++) {
//                Integer resultado = this.usuarioDAO.eliminar(listaUsuarios.get(i));
//                assertNotEquals(0, resultado);
//                UsuariosDTO usuario = this.usuarioDAO.obtenerPorId(listaUsuarios.get(i).getId_usuario());
//                assertNull(usuario);
//            }
    }
    
}
