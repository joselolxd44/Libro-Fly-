package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.persistance.daoImpl.GeneroDAOImpl;

public class GeneroDAOTest {
    private GeneroDAO generoDAO;
    
    public GeneroDAOTest(){
        this.generoDAO=new GeneroDAOImpl();
    }
    
//    @Test
//    public void testInsertar(){
//        System.out.println("insertar (genero)");
//        ArrayList<Integer> listaGeneroId=new ArrayList<>();
//        insertarGeneros(listaGeneroId);
//        eliminarTodo();
//    }
//    
//    private void insertarGeneros(ArrayList<Integer> listaGeneroId){
//        GenerosDTO genero;
//        Integer resultado;
//        GenerosDTO generoAux=new GenerosDTO();
//        generoAux.setDescripcion("GeneroA");
//        resultado = this.generoDAO.insertar(generoAux);
//        assertTrue(resultado != 0);
//        generoAux.setId_genero(resultado);
//        
//        for(int i=0;i<3;i++){
//            genero = new GenerosDTO();
//            genero.setDescripcion("Subgenero"+i);
//            genero.setGenero_principal_id(generoAux);
//            resultado=this.generoDAO.insertar(genero);
//            assertTrue(resultado != 0);
//            
//            listaGeneroId.add(resultado);
//        }
//        
//    }
//    
//     @Test
//    public void testObtenerPorId() {
//        System.out.println("obtenerPorId");
//        ArrayList<Integer> listaGeneroId = new ArrayList<>();
//        insertarGeneros(listaGeneroId);
//        GenerosDTO genero = this.generoDAO.obtenerPorId(listaGeneroId.get(0));
//        assertEquals(genero.getId_genero(), listaGeneroId.get(0));
//        
//        genero = this.generoDAO.obtenerPorId(listaGeneroId.get(1));
//        assertEquals(genero.getId_genero(), listaGeneroId.get(1));
//        
//        genero = this.generoDAO.obtenerPorId(listaGeneroId.get(2));
//        assertEquals(genero.getId_genero(), listaGeneroId.get(2));
//        eliminarTodo();
//    }
//    
//    @Test
//    public void testListarTodos() {
//        System.out.println("listarTodos");
//        ArrayList<Integer> listaGeneroId = new ArrayList<>();
//        insertarGeneros(listaGeneroId);
//        
//        ArrayList<GenerosDTO> listaGeneros = this.generoDAO.listarTodos();
//        assertEquals(listaGeneroId.size()+1, listaGeneros.size());
//        for (Integer i = 1; i < listaGeneros.size(); i++) {
//            assertEquals(listaGeneroId.get(i-1), listaGeneros.get(i).getId_genero());
//        }
//        eliminarTodo();
//    }
////    
//    @Test
//    public void testModificar() {
//        System.out.println("modificar");
//        ArrayList<Integer> listaGeneroId = new ArrayList<>();
//        insertarGeneros(listaGeneroId);
//        
//        ArrayList<GenerosDTO> listaGeneros = this.generoDAO.listarTodos();
//        assertEquals(listaGeneroId.size()+1, listaGeneros.size());
//        for (Integer i = 1; i < listaGeneroId.size()+1; i++) {
//            listaGeneros.get(i).setDescripcion("NuevoGenero" + i.toString());
//            this.generoDAO.modificar(listaGeneros.get(i));
//        }
//        
//        ArrayList<GenerosDTO> listaGenerosModificados = this.generoDAO.listarTodos();
//        assertEquals( listaGeneros.size(), listaGenerosModificados.size());
//        for (Integer i = 1; i < listaGeneros.size(); i++) {
//            assertEquals(listaGeneros.get(i).getDescripcion(), listaGenerosModificados.get(i).getDescripcion());
//        }
//        eliminarTodo();
//    }
//    
//    private void eliminarTodo(){                
//        ArrayList<GenerosDTO> listaGeneros = this.generoDAO.listarTodos();
//        for (Integer i = 1; i < listaGeneros.size(); i++) {
//            Integer resultado = this.generoDAO.eliminar(listaGeneros.get(i));
//            assertNotEquals(0, resultado);
//            GenerosDTO genero = this.generoDAO.obtenerPorId(listaGeneros.get(i).getId_genero());
//            assertNull(genero);
//        }
//        Integer resultado = this.generoDAO.eliminar(listaGeneros.get(0));
//        assertNotEquals(0, resultado);
//    }
}
