package pe.edu.pucp.librofly.persistance.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.persistance.dao.GeneroDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.util.Columna;

public class GeneroDAOImpl extends DAOImplBase implements GeneroDAO{
    
    private GenerosDTO genero;

    public GeneroDAOImpl() {
        super("VEN_GENEROS");
        this.retornarLlavePrimaria = true;
        this.genero = null;
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("ID_GENERO", true, true));
        this.listaColumnas.add(new Columna("DESCRIPCION", false, false));
        this.listaColumnas.add(new Columna("ID_GENERO_PRINCIPAL", false, false));
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setString(1, this.genero.getDescripcion());
        if(this.genero.getGenero_principal_id() != null)
            this.statement.setInt(2, this.genero.getGenero_principal_id().getId_genero());
        else
            this.statement.setNull(2, java.sql.Types.INTEGER);
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setString(1, this.genero.getDescripcion());
        this.statement.setInt(2, this.genero.getGenero_principal_id().getId_genero());
        this.statement.setInt(3, this.genero.getId_genero());
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.genero.getId_genero());
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        this.statement.setInt(1, this.genero.getId_genero());
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.genero=new GenerosDTO();
        this.genero.setId_genero(this.resultSet.getInt("ID_GENERO"));
        this.genero.setDescripcion(this.resultSet.getString("DESCRIPCION"));
        
        GeneroDAO generoDAO = new GeneroDAOImpl();
        GenerosDTO generoAux = new GenerosDTO();
        Integer id_genero = this.resultSet.getInt("ID_GENERO_PRINCIPAL");
        //Puede no tener un genero principal
        if(id_genero>0){
            generoAux = generoDAO.obtenerPorId(id_genero);
            this.genero.setGenero_principal_id(generoAux);
        }
    }

    @Override
    protected void limpiarObjetoDelResultSet() {
        this.genero = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDelResultSet();
        lista.add(this.genero);
    }

    @Override
    public Integer insertar(GenerosDTO genero) {
        this.genero = genero;
        return super.insertar();
    }

    @Override
    public GenerosDTO obtenerPorId(Integer id_genero) {
        this.genero = new GenerosDTO();
        this.genero.setId_genero(id_genero);
        super.obtenerPorId();
        return this.genero;
    }

    @Override
    public ArrayList<GenerosDTO> listarTodos() {
        return (ArrayList<GenerosDTO>) super.listarTodos();
    }

    @Override
    public Integer modificar(GenerosDTO genero) {
        this.genero = genero;
        return super.modificar();
    }

    @Override
    public Integer eliminar(GenerosDTO genero) {
        this.genero = genero;
        return super.eliminar();
    }
}
