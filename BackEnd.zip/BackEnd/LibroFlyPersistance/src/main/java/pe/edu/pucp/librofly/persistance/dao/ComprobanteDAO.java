package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.ComprobantesDTO;

public interface ComprobanteDAO {
    public Integer insertar(ComprobantesDTO comprobante);
    
    public ComprobantesDTO obtenerPorId(Integer comprobanteId);
    
//    public ArrayList<ComprobantesDTO> listarTodos();

    public Integer modificar(ComprobantesDTO comprobante);
    
    public Integer eliminar(ComprobantesDTO comprobante);
}
