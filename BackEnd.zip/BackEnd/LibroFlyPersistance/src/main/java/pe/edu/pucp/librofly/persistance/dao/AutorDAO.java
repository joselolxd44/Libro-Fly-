/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.persistance.dao;

import pe.edu.pucp.librofly.model.AutoresDTO;

/**
 *
 * @author USUARIO
 */
public interface AutorDAO {
    
    public Integer insertar(AutoresDTO autor);
    
    public AutoresDTO obtenerPorId(Integer autorId);
    public AutoresDTO obtenerPorNombre(String nombre_completo);
    
//    public ArrayList<ComprobantesDTO> listarTodos();

    public Integer modificar(AutoresDTO autor);
    
    public Integer eliminar(AutoresDTO autor);
}
