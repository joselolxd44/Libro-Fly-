/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.persistance.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.librofly.model.LibrosDTO;
import pe.edu.pucp.librofly.model.LineasCarritoDTO;
import pe.edu.pucp.librofly.model.LineasPedidoDTO;
import pe.edu.pucp.librofly.model.PedidosDTO;
import pe.edu.pucp.librofly.persistance.dao.LineaPedidoDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.util.Columna;

/**
 *
 * @author USUARIO
 */
public class LineaPedidoDAOImpl extends DAOImplBase implements LineaPedidoDAO{
    private LineasPedidoDTO linea_pedido;

    public LineaPedidoDAOImpl() {
        super("VEN_LINEAS_CARRITO");
        this.retornarLlavePrimaria = false;
        this.linea_pedido = null;
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("ID_PEDIDO", true, false));
        this.listaColumnas.add(new Columna("ID_LIBRO", false, false));
        this.listaColumnas.add(new Columna("CANTIDAD", false, false));
        this.listaColumnas.add(new Columna("SUBTOTAL", false, false));
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setInt(1, this.linea_pedido.getPedido().getId_pedido());
        this.statement.setInt(2, this.linea_pedido.getLibro().getId_libro());
        this.statement.setInt(3, this.linea_pedido.getCantidad());
        this.statement.setFloat(4, this.linea_pedido.getSubtotal());
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setInt(1, this.linea_pedido.getCantidad());
        this.statement.setFloat(2, this.linea_pedido.getSubtotal());
        this.statement.setInt(3, this.linea_pedido.getPedido().getId_pedido());
        this.statement.setInt(4, this.linea_pedido.getLibro().getId_libro());
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.linea_pedido.getPedido().getId_pedido());
        this.statement.setInt(2, this.linea_pedido.getLibro().getId_libro());
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        this.statement.setInt(1, this.linea_pedido.getPedido().getId_pedido());
        this.statement.setInt(2, this.linea_pedido.getLibro().getId_libro());
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.linea_pedido = new LineasPedidoDTO();
        
        PedidosDTO pedido = new PedidosDTO();
        pedido.setId_pedido(this.resultSet.getInt("ID_PEDIDO"));
        this.linea_pedido.setPedido(pedido);
        
        LibrosDTO libro = new LibrosDTO();
        libro.setId_libro(this.resultSet.getInt("ID_LIBRO"));
        this.linea_pedido.setLibro(libro);
        
        this.linea_pedido.setCantidad(this.resultSet.getInt("CANTIDAD"));
        this.linea_pedido.setSubtotal(this.resultSet.getFloat("SUBTOTAL"));
    }

    @Override
    protected void limpiarObjetoDelResultSet() {
        this.linea_pedido = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDelResultSet();
        lista.add(this.linea_pedido);
    }

    @Override
    public Integer insertar(LineasPedidoDTO linea_pedido) {
        this.linea_pedido = linea_pedido;
        return super.insertar();
    }

    @Override
    public LineasPedidoDTO obtenerPorId(Integer id_pedido,Integer id_libro) {
        this.linea_pedido = new LineasPedidoDTO();
        
        PedidosDTO pedido = new PedidosDTO();
        pedido.setId_pedido(id_pedido);
        this.linea_pedido.setPedido(pedido);
        
        LibrosDTO libro = new LibrosDTO();
        libro.setId_libro(id_libro);
        this.linea_pedido.setLibro(libro);
        
        super.obtenerPorId();
        return this.linea_pedido;
    }

//    @Override
    public ArrayList<LineasCarritoDTO> listarTodos() {
        return (ArrayList<LineasCarritoDTO>) super.listarTodos();
    }

//    @Override
    public Integer modificar(LineasPedidoDTO linea_pedido) {
        this.linea_pedido = linea_pedido;
        return super.modificar();
    }

//    @Override
    public Integer eliminar(LineasPedidoDTO linea_pedido) {
        this.linea_pedido = linea_pedido;
        return super.eliminar();
    }
}
