/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.LineasCarritoDTO;

/**
 *
 * @author USUARIO
 */
public interface LineaCarritoDAO {
    public Integer insertar(LineasCarritoDTO linea_carrito);
    
    public LineasCarritoDTO obtenerPorId(Integer id_carrito,Integer id_libro);
    
//    public ArrayList<ComprobantesDTO> listarTodos();

    public Integer modificar(LineasCarritoDTO linea_carrito);
    
    public Integer eliminar(LineasCarritoDTO linea_carrito);
    
    public ArrayList<LineasCarritoDTO> listarCarritoUsuario(Integer id_usuario);
    
    public void vaciarCarrito(Integer id_usuario);
}
