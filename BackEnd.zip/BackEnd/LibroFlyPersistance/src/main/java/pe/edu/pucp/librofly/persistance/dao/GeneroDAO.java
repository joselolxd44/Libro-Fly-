package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.GenerosDTO;

public interface GeneroDAO {
    public Integer insertar(GenerosDTO genero);
    
    public GenerosDTO obtenerPorId(Integer generoId);
    
    public ArrayList<GenerosDTO> listarTodos();

    public Integer modificar(GenerosDTO genero);
    
    public Integer eliminar(GenerosDTO genero);
}
