package pe.edu.pucp.librofly.persistance.daoImpl;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import pe.edu.pucp.librofly.model.LibrosDTO;
import pe.edu.pucp.librofly.model.MetodosPagoDTO;
import pe.edu.pucp.librofly.model.PedidosDTO;
import pe.edu.pucp.librofly.model.UsuariosDTO;
import pe.edu.pucp.librofly.persistance.dao.LibroDAO;
import pe.edu.pucp.librofly.persistance.dao.MetodoPagoDAO;
import pe.edu.pucp.librofly.persistance.dao.PedidoDAO;
import pe.edu.pucp.librofly.persistance.dao.UsuarioDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.util.Columna;
import pe.edu.pucp.librofly.persistance.daoImpl.util.PedidoParametros;

public class PedidoDAOImpl extends DAOImplBase implements PedidoDAO{
    private PedidosDTO pedido;

    public PedidoDAOImpl() {
        super("VEN_PEDIDOS");
        this.retornarLlavePrimaria = true;
        this.pedido = null;
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("ID_PEDIDO", true, true));
        this.listaColumnas.add(new Columna("FECHA", false, false));
        this.listaColumnas.add(new Columna("TOTAL", false, false));
        this.listaColumnas.add(new Columna("ESTADO", false, false));
        this.listaColumnas.add(new Columna("ID_CLIENTE", false, false));
        this.listaColumnas.add(new Columna("ID_METODO_PAGO", false, false));
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setDate(1, (Date) this.pedido.getFecha());
        this.statement.setFloat(2, this.pedido.getTotal());
        this.statement.setString(3, this.pedido.getEstado());
        this.statement.setInt(4, this.pedido.getCantidad());
        this.statement.setInt(5, this.pedido.getCliente().getId_usuario());
        this.statement.setInt(6, this.pedido.getMetodo_pago().getId_metodo_pago());
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setDate(1, (Date) this.pedido.getFecha());
        this.statement.setFloat(2, this.pedido.getTotal());
        this.statement.setString(3, this.pedido.getEstado());
        this.statement.setInt(4, this.pedido.getCantidad());
        this.statement.setInt(5, this.pedido.getCliente().getId_usuario());
        this.statement.setInt(6, this.pedido.getMetodo_pago().getId_metodo_pago());
        this.statement.setInt(7, this.pedido.getId_pedido());
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.pedido.getId_pedido());
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        this.statement.setInt(1, this.pedido.getId_pedido());
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.pedido=new PedidosDTO();
        this.pedido.setId_pedido(this.resultSet.getInt("ID_PEDIDO"));
        this.pedido.setFecha((java.util.Date)this.resultSet.getDate("FECHA"));
        this.pedido.setTotal(this.resultSet.getFloat("TOTAL"));
        this.pedido.setEstado(this.resultSet.getString("ESTADO"));
        this.pedido.setCantidad(this.resultSet.getInt("CANTIDAD"));
        
        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
        UsuariosDTO clienteAux=new UsuariosDTO();
        Integer usuario_id = this.resultSet.getInt("ID_USUARIO");
        clienteAux = usuarioDAO.obtenerPorId(usuario_id);
        this.pedido.setCliente(clienteAux);
        
        MetodoPagoDAO metodoDAO = new MetodoPagoDAOImpl();
        MetodosPagoDTO metodoPagoAux=new MetodosPagoDTO();
        Integer metodo_pago_id = this.resultSet.getInt("ID_METODO_PAGO");
        metodoPagoAux = metodoDAO.obtenerPorId(metodo_pago_id);
        this.pedido.setMetodo_pago(metodoPagoAux);
    }
    
    private void instanciarObjetoDeHistorialUsuario() throws SQLException {
        System.out.println("Llego");
        this.pedido=new PedidosDTO();
        this.pedido.setId_pedido(this.resultSet.getInt("ID_PEDIDO"));
        this.pedido.setFecha((java.util.Date)this.resultSet.getDate("FECHA"));
        this.pedido.setTotal(this.resultSet.getFloat("TOTAL"));
        this.pedido.setEstado(this.resultSet.getString("ESTADO"));
    }
    
    @Override
    protected void limpiarObjetoDelResultSet() {
        this.pedido = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDeHistorialUsuario();
        lista.add(this.pedido);
    }

    @Override
    public Integer insertar(PedidosDTO pedido) {
        this.pedido = pedido;
        return super.insertar();
    }

    @Override
    public PedidosDTO obtenerPorId(Integer id_pedido) {
        this.pedido = new PedidosDTO();
        this.pedido.setId_pedido(id_pedido);
        super.obtenerPorId();
        return this.pedido;
    }

    @Override
    public ArrayList<PedidosDTO> listarHistorialUsuario(Integer id_usuario) {
        this.pedido = new PedidosDTO();
        UsuariosDTO usuario = new UsuariosDTO();
        usuario.setId_usuario(id_usuario);
        this.pedido.setCliente(usuario);
        String sql = this.generarSQLParaListarPorUsuario();
        return (ArrayList<PedidosDTO>) super.listarTodos(sql,this::incluirValorDeParametrosParaListarPorUsuario, this.pedido);
    }
    
    private void incluirValorDeParametrosParaListarPorUsuario(Object objetoParametros){
        PedidosDTO parametros = (PedidosDTO) objetoParametros;
        try {
            this.statement.setInt(1, parametros.getCliente().getId_usuario());
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private String generarSQLParaListarPorUsuario() {
        String sql = "SELECT ";
        sql = sql.concat("p.ID_PEDIDO, ");
//        sql = sql.concat("l.titulo, ");
//        sql = sql.concat("p.cantidad, ");
        sql = sql.concat("p.TOTAL, ");
        sql = sql.concat("p.FECHA, ");
        sql = sql.concat("p.ESTADO ");
        sql = sql.concat("FROM VEN_PEDIDOS p ");
        sql = sql.concat("JOIN VEN_USUARIOS u ON p.ID_CLIENTE = u.ID_USUARIO ");
        sql = sql.concat("WHERE p.ID_CLIENTE = ? ");
        return sql;
    }

    @Override
    public Integer modificar(PedidosDTO pedido) {
        this.pedido = pedido;
        return super.modificar();
    }

    @Override
    public Integer eliminar(PedidosDTO pedido) {
        this.pedido = pedido;
        return super.eliminar();
    }
}
