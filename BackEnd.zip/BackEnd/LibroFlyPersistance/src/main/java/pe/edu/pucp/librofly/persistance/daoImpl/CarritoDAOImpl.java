/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.persistance.daoImpl;

import java.sql.SQLException;
import java.util.List;
import pe.edu.pucp.librofly.model.CarritosDTO;
import pe.edu.pucp.librofly.persistance.daoImpl.util.Columna;

/**
 *
 * @author USUARIO
 */
public class CarritoDAOImpl extends DAOImplBase{
    private CarritosDTO carrito;

    public CarritoDAOImpl() {
        super("VEN_CARRITOS");
        this.retornarLlavePrimaria = true;
        this.carrito = null;
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("ID_CARRITO", true, true));
        this.listaColumnas.add(new Columna("ID_USUARIO", false, false));
        this.listaColumnas.add(new Columna("CANTIDAD_LINEAS", false, false));
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setInt(1, this.carrito.getUsuario().getId_usuario());
        this.statement.setInt(2, this.carrito.getCantidad_lineas());
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setInt(1, this.carrito.getUsuario().getId_usuario());
        this.statement.setInt(2, this.carrito.getCantidad_lineas());
        this.statement.setInt(3, this.carrito.getId_carrito());
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.carrito.getId_carrito());
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        this.statement.setInt(1, this.carrito.getId_carrito());
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.carrito = new CarritosDTO();
//        this.comprobante.setId_comprobante(this.resultSet.getInt("ID_COMPROBANTE"));
//        this.comprobante.setTipo(this.resultSet.getString("TIPO"));
//        this.comprobante.setNumero_serie(this.resultSet.getString("NUMERO_SERIE"));
//        this.comprobante.setNumero_serie(this.resultSet.getString("RUC_CLIENTE"));
//        this.comprobante.setNumero_serie(this.resultSet.getString("RAZON_SOCIAL"));
//        
//        PedidosDTO pedidoAux = new PedidosDTO();
//        Integer id_pedido = this.resultSet.getInt("ID_PEDIDO");
//        pedidoAux.setId_pedido(id_pedido);
//        this.comprobante.setPedido_id(pedidoAux);
    }

    @Override
    protected void limpiarObjetoDelResultSet() {
        this.carrito = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDelResultSet();
        lista.add(this.carrito);
    }

//    @Override
    public Integer insertar(CarritosDTO carrito) {
        this.carrito = carrito;
        return super.insertar();
    }

//    @Override
    public CarritosDTO obtenerPorId(Integer id_comprobante) {
        this.carrito = new CarritosDTO();
        super.obtenerPorId();
        return this.carrito;
    }

}
