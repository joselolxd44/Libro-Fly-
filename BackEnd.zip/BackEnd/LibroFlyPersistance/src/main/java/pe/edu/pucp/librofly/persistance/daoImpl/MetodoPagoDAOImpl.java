package pe.edu.pucp.librofly.persistance.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.librofly.model.MetodosPagoDTO;
import pe.edu.pucp.librofly.persistance.dao.MetodoPagoDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.util.Columna;

public class MetodoPagoDAOImpl extends DAOImplBase implements MetodoPagoDAO{
    
    private MetodosPagoDTO metodoPago;

    public MetodoPagoDAOImpl() {
        super("VEN_METODOS_PAGO");
        this.retornarLlavePrimaria = true;
        this.metodoPago = null;
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("ID_METODO_PAGO", true, true));
        this.listaColumnas.add(new Columna("TIPO_METODO", false, false));
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setString(1, this.metodoPago.getTipo_metodo());
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setString(1, this.metodoPago.getTipo_metodo());
        this.statement.setInt(2, this.metodoPago.getId_metodo_pago());
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.metodoPago.getId_metodo_pago());
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        this.statement.setInt(1, this.metodoPago.getId_metodo_pago());
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.metodoPago=new MetodosPagoDTO();
        this.metodoPago.setId_metodo_pago(this.resultSet.getInt("ID_METODO_PAGO"));
        this.metodoPago.setTipo_metodo(this.resultSet.getString("TIPO_METODO"));
    }

    @Override
    protected void limpiarObjetoDelResultSet() {
        this.metodoPago = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDelResultSet();
        lista.add(this.metodoPago);
    }

    @Override
    public Integer insertar(MetodosPagoDTO metodoPago) {
        this.metodoPago = metodoPago;
        return super.insertar();
    }

    @Override
    public MetodosPagoDTO obtenerPorId(Integer id) {
        this.metodoPago = new MetodosPagoDTO();
        this.metodoPago.setId_metodo_pago(id);
        super.obtenerPorId();
        return this.metodoPago;
    }

    @Override
    public ArrayList<MetodosPagoDTO> listarTodos() {
        return (ArrayList<MetodosPagoDTO>) super.listarTodos();
    }

    @Override
    public Integer modificar(MetodosPagoDTO metodoPago) {
        this.metodoPago = metodoPago;
        return super.modificar();
    }

    @Override
    public Integer eliminar(MetodosPagoDTO metodoPago) {
        this.metodoPago = metodoPago;
        return super.eliminar();
    }
    
}
