package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.PedidosDTO;

public interface PedidoDAO {
    public Integer insertar(PedidosDTO pedido);
    
    public PedidosDTO obtenerPorId(Integer pedidoId);
    
    public ArrayList<PedidosDTO> listarHistorialUsuario(Integer id_usuario);

    public Integer modificar(PedidosDTO pedido);
    
    public Integer eliminar(PedidosDTO pedido);
}
