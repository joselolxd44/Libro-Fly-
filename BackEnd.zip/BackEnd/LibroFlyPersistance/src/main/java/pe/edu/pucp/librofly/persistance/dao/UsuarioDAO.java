package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.model.UsuariosDTO;

public interface UsuarioDAO {
    
    public Integer insertar(UsuariosDTO usuario);
    
    public UsuariosDTO obtenerPorId(Integer usuarioId);
    public UsuariosDTO obtenerPorCorreo(String correo);
    
//    public ArrayList<UsuariosDTO> listarTodos();

    public Integer modificar(UsuariosDTO usuario);
    
    public Integer eliminar(UsuariosDTO usuario);
    
    public ArrayList<GenerosDTO> generarReporteHistorial(Integer id_usuario);
}
