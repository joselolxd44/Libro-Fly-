package pe.edu.pucp.librofly.persistance.daoImpl;

import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import pe.edu.pucp.librofly.db.util.Cifrado;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.model.TipoDocumento;
import pe.edu.pucp.librofly.persistance.dao.UsuarioDAO;
import pe.edu.pucp.librofly.model.UsuariosDTO;
import pe.edu.pucp.librofly.persistance.daoImpl.util.Columna;

public class UsuarioDAOImpl extends DAOImplBase implements UsuarioDAO {

    private UsuariosDTO usuario;

    public UsuarioDAOImpl() {
        super("VEN_USUARIOS");
        this.retornarLlavePrimaria = true;
        this.usuario = null;
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("ID_USUARIO", true, true));
        this.listaColumnas.add(new Columna("CORREO", false, false));
        this.listaColumnas.add(new Columna("CONTRASENHA", false, false));
        this.listaColumnas.add(new Columna("NOMBRES", false, false));
        this.listaColumnas.add(new Columna("APELLIDOS", false, false));
        this.listaColumnas.add(new Columna("DIRECCION_ENVIO", false, false));
        this.listaColumnas.add(new Columna("TELEFONO", false, false));
        this.listaColumnas.add(new Columna("TIPO_DOCUMENTO", false, false));
        this.listaColumnas.add(new Columna("NUM_DOCUMENTO", false, false));
        this.listaColumnas.add(new Columna("ROL", false, false));
        this.listaColumnas.add(new Columna("TIPO", false, false));
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setString(1, this.usuario.getCorreo());
        this.statement.setString(2, Cifrado.cifrarMD5(this.usuario.getContrasenha()));
        this.statement.setString(3, this.usuario.getNombres());
        this.statement.setString(4, this.usuario.getApellidos());
        this.statement.setString(5, this.usuario.getDireccion_envio());
        this.statement.setString(6, this.usuario.getTelefono());
        this.statement.setString(7, this.usuario.getTipo_documento().toString());
        this.statement.setString(8, this.usuario.getNumero_documento());
        if(this.usuario.getRol() == null)
            this.statement.setNull(9, Types.VARCHAR);
        else
            this.statement.setString(9, this.usuario.getRol());
        this.statement.setString(10, this.usuario.getTipo());
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setString(1, this.usuario.getCorreo());
        this.statement.setString(2, Cifrado.cifrarMD5(this.usuario.getContrasenha()));
        this.statement.setString(3, this.usuario.getNombres());
        this.statement.setString(4, this.usuario.getApellidos());
        this.statement.setString(5, this.usuario.getDireccion_envio());
        this.statement.setString(6, this.usuario.getTelefono());
        this.statement.setString(7, this.usuario.getTipo_documento().toString());
        this.statement.setString(8, this.usuario.getNumero_documento());
        this.statement.setString(9, this.usuario.getRol());
        this.statement.setString(10, this.usuario.getTipo());
        this.statement.setInt(11, this.usuario.getId_usuario());
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.usuario.getId_usuario());
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        this.statement.setInt(1, this.usuario.getId_usuario());
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.usuario = new UsuariosDTO();
        this.usuario.setId_usuario(this.resultSet.getInt("ID_USUARIO"));
        this.usuario.setCorreo(this.resultSet.getString("CORREO"));
        this.usuario.setContrasenha(Cifrado.descifrarMD5(this.resultSet.getString("CONTRASENHA")));
        this.usuario.setNombres(this.resultSet.getString("NOMBRES"));
        this.usuario.setApellidos(this.resultSet.getString("APELLIDOS"));
        this.usuario.setDireccion_envio(this.resultSet.getString("DIRECCION_ENVIO"));
        this.usuario.setTelefono(this.resultSet.getString("TELEFONO"));
        this.usuario.setTipo_documento(TipoDocumento.valueOf(this.resultSet.getString("TIPO_DOCUMENTO")));
        this.usuario.setNumero_documento(this.resultSet.getString("NUM_DOCUMENTO"));
        this.usuario.setRol(this.resultSet.getString("ROL"));
        this.usuario.setTipo(this.resultSet.getString("TIPO"));
    }

    @Override
    protected void limpiarObjetoDelResultSet() {
        this.usuario = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDelResultSet();
        lista.add(this.usuario);
    }

    @Override
    public Integer insertar(UsuariosDTO usuario) {
        this.usuario = usuario;
        return super.insertar();
    }

    @Override
    public UsuariosDTO obtenerPorId(Integer usuario_id) {
        this.usuario = new UsuariosDTO();
        this.usuario.setId_usuario(usuario_id);
        super.obtenerPorId();
        return this.usuario;
    }
    
    @Override
    public UsuariosDTO obtenerPorCorreo(String correo){
        this.usuario = new UsuariosDTO();
        this.usuario.setCorreo(correo);
        String sql_predicado = "CORREO='" + correo + "'";
        super.obtenerPorAtributo(sql_predicado);
        return this.usuario;
    }

    @Override
    public ArrayList<UsuariosDTO> listarTodos() {
        return (ArrayList<UsuariosDTO>) super.listarTodos();
    }

    @Override
    public Integer modificar(UsuariosDTO usuario) {
        this.usuario = usuario;
        return super.modificar();
    }

    @Override
    public Integer eliminar(UsuariosDTO usuario) {
        this.usuario = usuario;
        return super.eliminar();
    }
    
    @Override
    public ArrayList<GenerosDTO> generarReporteHistorial(Integer id_usuario){
        String sql = "CALL sp_obtener_generos(?)";
        return (ArrayList<GenerosDTO>)listarTodos(sql, this::incluirValorDeParametrosHistorial, this.usuario);
    }
    
    private void incluirValorDeParametrosHistorial(Object objetoParametros){
        UsuariosDTO usuario = (UsuariosDTO)objetoParametros;
        try{
            this.statement.setInt(1, usuario.getId_usuario());
        }catch (SQLException ex){
            Logger.getLogger(PedidoDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
