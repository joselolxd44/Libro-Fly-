package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.MetodosPagoDTO;

public interface MetodoPagoDAO {
    public Integer insertar(MetodosPagoDTO metodo_pago);
    
    public MetodosPagoDTO obtenerPorId(Integer metodo_pagoId);
    
    public ArrayList<MetodosPagoDTO> listarTodos();

    public Integer modificar(MetodosPagoDTO metodo_pago);
    
    public Integer eliminar(MetodosPagoDTO metodo_pago);
}
