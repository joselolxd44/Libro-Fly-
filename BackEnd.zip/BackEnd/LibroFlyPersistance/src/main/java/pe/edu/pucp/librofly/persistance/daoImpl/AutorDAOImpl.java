/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.persistance.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.librofly.model.AutoresDTO;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.persistance.dao.AutorDAO;
import pe.edu.pucp.librofly.persistance.dao.GeneroDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.util.Columna;

/**
 *
 * @author USUARIO
 */
public class AutorDAOImpl extends DAOImplBase implements AutorDAO{
    private AutoresDTO autor;

    public AutorDAOImpl() {
        super("VEN_AUTORES");
        this.retornarLlavePrimaria = true;
        this.autor = null;
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("ID_AUTOR", true, true));
        this.listaColumnas.add(new Columna("NOMBRE_COMPLETO", false, false));
//        this.listaColumnas.add(new Columna("GENERO_PRINCIPAL_ID", false, false));
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setString(1, this.autor.getNombre_completo());
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setString(1, this.autor.getNombre_completo());
        this.statement.setInt(2, this.autor.getId_autor());
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.autor.getId_autor());
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        this.statement.setInt(1, this.autor.getId_autor());
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.autor=new AutoresDTO();
        
        this.autor.setId_autor(this.resultSet.getInt("ID_AUTOR"));
        this.autor.setNombre_completo(this.resultSet.getString("NOMBRE_COMPLETO"));
    }

    @Override
    protected void limpiarObjetoDelResultSet() {
        this.autor = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDelResultSet();
        lista.add(this.autor);
    }

    @Override
    public Integer insertar(AutoresDTO autor) {
        this.autor = autor;
        return super.insertar();
    }

    @Override
    public AutoresDTO obtenerPorId(Integer id_autor) {
        this.autor = new AutoresDTO();
        this.autor.setId_autor(id_autor);
        super.obtenerPorId();
        return this.autor;
    }

    @Override
    public AutoresDTO obtenerPorNombre(String nombre_completo){
        this.autor = new AutoresDTO();
        this.autor.setNombre_completo(nombre_completo);
        String sql_predicado = "NOMBRE_COMPLETO='" + nombre_completo + "'";
        super.obtenerPorAtributo(sql_predicado);
        return this.autor;
    }
    
    @Override
    public ArrayList<AutoresDTO> listarTodos() {
        return (ArrayList<AutoresDTO>) super.listarTodos();
    }

    @Override
    public Integer modificar(AutoresDTO autor) {
        this.autor = autor;
        return super.modificar();
    }

    @Override
    public Integer eliminar(AutoresDTO autor) {
        this.autor = autor;
        return super.eliminar();
    }
}
