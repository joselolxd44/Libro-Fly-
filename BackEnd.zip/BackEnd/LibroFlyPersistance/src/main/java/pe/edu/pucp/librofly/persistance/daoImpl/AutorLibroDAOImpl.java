/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.persistance.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import pe.edu.pucp.librofly.model.AutoresDTO;
import pe.edu.pucp.librofly.model.AutoresLibroDTO;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.model.LibrosDTO;
import pe.edu.pucp.librofly.persistance.dao.AutorLibroDAO;
import pe.edu.pucp.librofly.persistance.dao.GeneroDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.util.Columna;

/**
 *
 * @author USUARIO
 */
public class AutorLibroDAOImpl extends DAOImplBase implements AutorLibroDAO{
    private AutoresLibroDTO autor_libro;

    public AutorLibroDAOImpl() {
        super("VEN_AUTORES_LIBRO");
        this.retornarLlavePrimaria = true;
        this.autor_libro = null;
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("ID_AUTOR", true, false));
        this.listaColumnas.add(new Columna("ID_LIBRO", true, false));
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setInt(1, this.autor_libro.getAutor().getId_autor());
        this.statement.setInt(2, this.autor_libro.getLibro().getId_libro());
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.autor_libro=new AutoresLibroDTO();
        AutoresDTO autor = new AutoresDTO();
        autor.setId_autor(this.resultSet.getInt("ID_AUTOR"));
        autor.setNombre_completo(this.resultSet.getString("NOMBRE_COMPLETO"));
        this.autor_libro.setAutor(autor);
        
//        LibrosDTO libro = new LibrosDTO();
//        libro.setId_libro(this.resultSet.getInt("ID_LIBRO"));
//        this.autor_libro.setLibro(libro);
    }

    @Override
    protected void limpiarObjetoDelResultSet() {
        this.autor_libro = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDelResultSet();
        lista.add(this.autor_libro);
    }

    @Override
    public Integer insertar(AutoresLibroDTO autor_libro) {
        this.autor_libro = autor_libro;
        return super.insertar();
    }

    @Override
    public ArrayList<AutoresLibroDTO> listarAutoresDeLibro(Integer id_libro) {
        String sql = generarSqlParaListarAutores();
        LibrosDTO libro = new LibrosDTO();
        this.autor_libro = new AutoresLibroDTO();
        libro.setId_libro(id_libro);
        this.autor_libro.setLibro(libro);
        return (ArrayList<AutoresLibroDTO>) super.listarTodos(sql,this::incluirValorDeParametrosParaListarAutores,this.autor_libro);
    }

    private void incluirValorDeParametrosParaListarAutores(Object parametros){
        AutoresLibroDTO autor_libro = (AutoresLibroDTO) parametros;
        try{
            this.statement.setInt(1, autor_libro.getLibro().getId_libro());
        }catch (SQLException ex){
            Logger.getLogger(PedidoDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private String generarSqlParaListarAutores(){
        String sql = "";
        sql += "SELECT ";
        sql += "A.ID_AUTOR, ";
        sql += "A.NOMBRE_COMPLETO ";
//        sql += "T.ID_LIBRO ";
        sql += "FROM VEN_AUTORES_LIBRO T ";
        sql += "JOIN VEN_AUTORES A ON A.ID_AUTOR = T.ID_AUTOR ";
        sql += "WHERE T.ID_LIBRO = ? ";
        return sql;
    }
    
//    @Override
//    public Integer modificar(GenerosDTO genero) {
//        this.genero = genero;
//        return super.modificar();
//    }

    @Override
    public Integer eliminar(AutoresLibroDTO autor_libro) {
        this.autor_libro = autor_libro;
        return super.eliminar();
    }
}
