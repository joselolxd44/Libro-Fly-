package pe.edu.pucp.librofly.persistance.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.model.LibrosDTO;
import pe.edu.pucp.librofly.persistance.dao.LibroDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.util.Columna;

public class LibroDAOImpl extends DAOImplBase implements LibroDAO{
    private LibrosDTO libro;

    public LibroDAOImpl() {
        super("VEN_LIBROS");
        this.retornarLlavePrimaria = true;
        this.libro = null;
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("ID_LIBRO", true, true));
        this.listaColumnas.add(new Columna("TITULO", false, false));
        this.listaColumnas.add(new Columna("DESCRIPCION", false, false));
        this.listaColumnas.add(new Columna("ANHO", false, false));
        this.listaColumnas.add(new Columna("PESO", false, false));
        this.listaColumnas.add(new Columna("ANCHO", false, false));
        this.listaColumnas.add(new Columna("ALTO", false, false));
        this.listaColumnas.add(new Columna("NUM_PAGINAS", false, false));
        this.listaColumnas.add(new Columna("FORMATO", false, false));
        this.listaColumnas.add(new Columna("ISBN", false, false));
        this.listaColumnas.add(new Columna("PRECIO", false, false));
        this.listaColumnas.add(new Columna("STOCK", false, false));
        this.listaColumnas.add(new Columna("URL_PORTADA", false, false));
        this.listaColumnas.add(new Columna("EDITORIAL", false, false));
        this.listaColumnas.add(new Columna("ID_GENERO", false, false));
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setString(1, this.libro.getTitulo());
        this.statement.setString(2, this.libro.getDescripcion());
        this.statement.setInt(3, this.libro.getAnho());
        this.statement.setFloat(4, this.libro.getPeso());
        this.statement.setFloat(5, this.libro.getAncho());
        this.statement.setFloat(6, this.libro.getAlto());
        this.statement.setInt(7, this.libro.getNumero_paginas());
        this.statement.setString(8, this.libro.getFormato());
        this.statement.setString(9, this.libro.getIsbn());
        this.statement.setFloat(10, this.libro.getPrecio());
        this.statement.setInt(11, this.libro.getStock());
        this.statement.setString(12, this.libro.getUrl_portada());
        this.statement.setString(13, this.libro.getEditorial());
        this.statement.setInt(14, this.libro.getGenero().getId_genero());
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setString(1, this.libro.getTitulo());
        this.statement.setString(2, this.libro.getDescripcion());
        this.statement.setInt(3, this.libro.getAnho());
        this.statement.setFloat(4, this.libro.getPeso());
        this.statement.setFloat(5, this.libro.getAncho());
        this.statement.setFloat(6, this.libro.getAlto());
        this.statement.setInt(7, this.libro.getNumero_paginas());
        this.statement.setString(8, this.libro.getFormato());
        this.statement.setString(9, this.libro.getIsbn());
        this.statement.setFloat(10, this.libro.getPrecio());
        this.statement.setInt(11, this.libro.getStock());
        this.statement.setString(12, this.libro.getUrl_portada());
        this.statement.setString(13, this.libro.getEditorial());
        this.statement.setInt(14, this.libro.getGenero().getId_genero());
        this.statement.setInt(15, this.libro.getId_libro());
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.libro.getId_libro());
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        this.statement.setInt(1, this.libro.getId_libro());
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.libro = new LibrosDTO();
        this.libro.setId_libro(this.resultSet.getInt("ID_LIBRO"));
        this.libro.setTitulo(this.resultSet.getString("TITULO"));
        this.libro.setDescripcion(this.resultSet.getString("DESCRIPCION"));
        this.libro.setAnho(this.resultSet.getInt("ANHO"));
        this.libro.setPeso(this.resultSet.getFloat("PESO"));
        this.libro.setAncho(this.resultSet.getFloat("ANCHO"));
        this.libro.setAlto(this.resultSet.getFloat("ALTO"));
        this.libro.setNumero_paginas(this.resultSet.getInt("NUM_PAGINAS"));
        this.libro.setFormato(this.resultSet.getString("FORMATO"));
        this.libro.setIsbn(this.resultSet.getString("ISBN"));
        this.libro.setAlto(this.resultSet.getFloat("ALTO"));
        this.libro.setPrecio(this.resultSet.getFloat("PRECIO"));
        this.libro.setStock(this.resultSet.getInt("STOCK"));
        this.libro.setUrl_portada(this.resultSet.getString("URL_PORTADA")); 
        this.libro.setEditorial(this.resultSet.getString("EDITORIAL"));
        GenerosDTO genero = new GenerosDTO();
        genero.setId_genero(this.resultSet.getInt("ID_GENERO"));
        this.libro.setGenero(genero);
    }

    private void instanciarObjetoDelResultSetLista() throws SQLException {
        this.libro = new LibrosDTO();
        this.libro.setId_libro(this.resultSet.getInt("ID_LIBRO"));
        this.libro.setTitulo(this.resultSet.getString("TITULO"));
        this.libro.setPrecio(this.resultSet.getFloat("PRECIO"));
        this.libro.setUrl_portada(this.resultSet.getString("URL_PORTADA")); 
    }
    
    @Override
    protected void limpiarObjetoDelResultSet() {
        this.libro = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDelResultSetLista();
        lista.add(this.libro);
    }

    @Override
    public Integer insertar(LibrosDTO libro) {
        this.libro = libro;
        return super.insertar();
    }

    @Override
    public LibrosDTO obtenerPorId(Integer id_libro) {
        this.libro = new LibrosDTO();
        this.libro.setId_libro(id_libro);
        super.obtenerPorId();
        return this.libro;
    }

    @Override
    public ArrayList<LibrosDTO> listarPaginaLibros(int ultimo){
        String sql = generarSqlParaInicio(); 
        this.libro = new LibrosDTO();
        this.libro.setId_libro(ultimo);
        return (ArrayList<LibrosDTO>) super.listarTodos(sql,this::incluirValorDeParametrosPagina,this.libro);
    }
    
    private void incluirValorDeParametrosPagina(Object objetoParametros){
        LibrosDTO parametros = (LibrosDTO) objetoParametros;
        try {
            this.statement.setInt(1, parametros.getId_libro());
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private String generarSqlParaInicio(){
        String sql = "";
        sql += "SELECT ";
        sql += "ID_LIBRO, ";
        sql += "TITULO, ";
        sql += "PRECIO, ";
        sql += "URL_PORTADA ";
        sql += "FROM VEN_LIBROS ";
        sql += "WHERE ID_LIBRO > ?";
        return sql;
    }
    
    @Override
    public ArrayList<LibrosDTO> buscarLibro(String cadena_ingresada){
        String sql = generarSqlParaBusqueda();
//        sql += predicadoBusqueda()
        return (ArrayList<LibrosDTO>) super.listarTodos(sql, this::incluirValorDeParametrosBusqueda, cadena_ingresada);
    }
    
    private String generarSqlParaBusqueda(){
        String sql = "";
        sql += "SELECT ";
        sql += "l.ID_LIBRO, ";
        sql += "l.TITULO, ";
        sql += "l.PRECIO, ";
        sql += "l.URL_PORTADA ";
        sql += "FROM VEN_LIBROS l";
        sql += "JOIN VEN_AUTORES_LIBRO x ON x.ID_LIBRO = l.ID_LIBRO ";//falta
        sql += "WHERE x.AUTOR = '%?%'";
        return sql;
    }
    
    private void incluirValorDeParametrosBusqueda(Object objectParametros){
        String cadena = (String)objectParametros;
        try {
            this.statement.setString(1, cadena);
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
//    @Override
//    public ArrayList<LibrosDTO> listarTodos() {
//        return (ArrayList<LibrosDTO>) super.listarTodos();
//    }

    @Override
    public Integer modificar(LibrosDTO libro) {
        this.libro = libro;
        return super.modificar();
    }

    @Override
    public Integer eliminar(LibrosDTO libro) {
        this.libro = libro;
        return super.eliminar();
    }
}
