package pe.edu.pucp.librofly.persistance.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.librofly.model.PedidosDTO;
import pe.edu.pucp.librofly.model.ComprobantesDTO;
import pe.edu.pucp.librofly.persistance.dao.ComprobanteDAO;
import pe.edu.pucp.librofly.persistance.dao.PedidoDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.util.Columna;

public class ComprobanteDAOImpl extends DAOImplBase implements ComprobanteDAO{
    private ComprobantesDTO comprobante;

    public ComprobanteDAOImpl() {
        super("VEN_COMPROBANTES");
        this.retornarLlavePrimaria = true;
        this.comprobante = null;
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("ID_COMPROBANTE", true, true));
        this.listaColumnas.add(new Columna("TIPO", false, false));
        this.listaColumnas.add(new Columna("NUMERO_SERIE", false, false));
        this.listaColumnas.add(new Columna("RUC_CLIENTE", false, false));
        this.listaColumnas.add(new Columna("RAZON_SOCIAL", false, false));
        this.listaColumnas.add(new Columna("ID_PEDIDO", false, false));
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setString(1, this.comprobante.getTipo());
        this.statement.setString(2, this.comprobante.getNumero_serie());
        this.statement.setString(3, this.comprobante.getRuc_cliente());
        this.statement.setString(4, this.comprobante.getRazon_social());
        this.statement.setInt(5, this.comprobante.getPedido_id().getId_pedido());
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setString(1, this.comprobante.getTipo());
        this.statement.setString(2, this.comprobante.getNumero_serie());
        this.statement.setString(3, this.comprobante.getRuc_cliente());
        this.statement.setString(4, this.comprobante.getRazon_social());
        this.statement.setInt(5, this.comprobante.getPedido_id().getId_pedido());
        this.statement.setInt(6, this.comprobante.getId_comprobante());
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.comprobante.getId_comprobante());
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        this.statement.setInt(1, this.comprobante.getId_comprobante());
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.comprobante=new ComprobantesDTO();
        this.comprobante.setId_comprobante(this.resultSet.getInt("ID_COMPROBANTE"));
        this.comprobante.setTipo(this.resultSet.getString("TIPO"));
        this.comprobante.setNumero_serie(this.resultSet.getString("NUMERO_SERIE"));
        this.comprobante.setNumero_serie(this.resultSet.getString("RUC_CLIENTE"));
        this.comprobante.setNumero_serie(this.resultSet.getString("RAZON_SOCIAL"));
        
        PedidosDTO pedidoAux = new PedidosDTO();
        Integer id_pedido = this.resultSet.getInt("ID_PEDIDO");
        pedidoAux.setId_pedido(id_pedido);
        this.comprobante.setPedido_id(pedidoAux);
    }

    @Override
    protected void limpiarObjetoDelResultSet() {
        this.comprobante = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDelResultSet();
        lista.add(this.comprobante);
    }

    @Override
    public Integer insertar(ComprobantesDTO comprobante) {
        this.comprobante = comprobante;
        return super.insertar();
    }

    @Override
    public ComprobantesDTO obtenerPorId(Integer id_comprobante) {
        this.comprobante = new ComprobantesDTO();
        this.comprobante.setId_comprobante(id_comprobante);
        super.obtenerPorId();
        return this.comprobante;
    }

    @Override
    public ArrayList<ComprobantesDTO> listarTodos() {
        return (ArrayList<ComprobantesDTO>) super.listarTodos();
    }

    @Override
    public Integer modificar(ComprobantesDTO comprobante) {
        this.comprobante = comprobante;
        return super.modificar();
    }

    @Override
    public Integer eliminar(ComprobantesDTO comprobante) {
        this.comprobante = comprobante;
        return super.eliminar();
    }
}
