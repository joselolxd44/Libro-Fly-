/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.persistance.dao;

import pe.edu.pucp.librofly.model.LineasPedidoDTO;

/**
 *
 * @author USUARIO
 */
public interface LineaPedidoDAO {
    public Integer insertar(LineasPedidoDTO linea_pedido);
    
    public LineasPedidoDTO obtenerPorId(Integer id_pedido,Integer id_libro);
    
//    public ArrayList<ComprobantesDTO> listarTodos();

    public Integer modificar(LineasPedidoDTO linea_pedido);
    
    public Integer eliminar(LineasPedidoDTO linea_pedido);
    
}
