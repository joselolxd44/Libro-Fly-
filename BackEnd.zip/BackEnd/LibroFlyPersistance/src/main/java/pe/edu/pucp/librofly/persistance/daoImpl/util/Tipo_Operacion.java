package pe.edu.pucp.librofly.persistance.daoImpl.util;

public enum Tipo_Operacion {
    INSERTAR, MODIFICAR, ELIMINAR
}
