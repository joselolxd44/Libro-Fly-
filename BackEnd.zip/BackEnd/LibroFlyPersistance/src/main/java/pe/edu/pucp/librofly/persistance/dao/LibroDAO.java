package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.LibrosDTO;

public interface LibroDAO {
    public Integer insertar(LibrosDTO libro);
    
    public LibrosDTO obtenerPorId(Integer libroId);
    
    public ArrayList<LibrosDTO> listarPaginaLibros(int ultimo);
    public ArrayList<LibrosDTO> buscarLibro(String cadena_ingresada);

    public Integer modificar(LibrosDTO libro);
    
    public Integer eliminar(LibrosDTO libro);
}
