/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.persistance.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import pe.edu.pucp.librofly.model.CarritosDTO;
import pe.edu.pucp.librofly.model.LibrosDTO;
import pe.edu.pucp.librofly.model.LineasCarritoDTO;
import pe.edu.pucp.librofly.model.UsuariosDTO;
import pe.edu.pucp.librofly.persistance.dao.LineaCarritoDAO;
import pe.edu.pucp.librofly.persistance.daoImpl.util.Columna;

/**
 *
 * @author USUARIO
 */
public class LineaCarritoDAOImpl extends DAOImplBase implements LineaCarritoDAO{
    private LineasCarritoDTO linea_carrito;

    public LineaCarritoDAOImpl() {
        super("VEN_LINEAS_CARRITO");
        this.retornarLlavePrimaria = false;
        this.linea_carrito = null;
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("ID_USUARIO", true, false));
        this.listaColumnas.add(new Columna("ID_LIBRO", true, false));
        this.listaColumnas.add(new Columna("CANTIDAD", false, false));
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setInt(1, this.linea_carrito.getUsuario().getId_usuario());
        this.statement.setInt(2, this.linea_carrito.getLibro().getId_libro());
        this.statement.setInt(3, this.linea_carrito.getCantidad());
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setInt(1, this.linea_carrito.getCantidad());
        this.statement.setInt(2, this.linea_carrito.getUsuario().getId_usuario());
        this.statement.setInt(3, this.linea_carrito.getLibro().getId_libro());
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.linea_carrito.getUsuario().getId_usuario());
        this.statement.setInt(2, this.linea_carrito.getLibro().getId_libro());
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        this.statement.setInt(1, this.linea_carrito.getUsuario().getId_usuario());
        this.statement.setInt(2, this.linea_carrito.getLibro().getId_libro());
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.linea_carrito = new LineasCarritoDTO();
        this.linea_carrito.setCantidad(this.resultSet.getInt("CANTIDAD"));
    }

    protected void instanciarObjetoDelResultSetLista() throws SQLException {
        this.linea_carrito = new LineasCarritoDTO();
        LibrosDTO libro = new LibrosDTO();
        libro.setId_libro(this.resultSet.getInt("ID_LIBRO"));
        libro.setTitulo(this.resultSet.getString("TITULO"));
        libro.setPrecio(this.resultSet.getFloat("PRECIO"));
        this.linea_carrito.setLibro(libro);
        this.linea_carrito.setCantidad(this.resultSet.getInt("CANTIDAD"));
    }

    @Override
    protected void limpiarObjetoDelResultSet() {
        this.linea_carrito = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDelResultSetLista();
        lista.add(this.linea_carrito);
    }

    @Override
    public Integer insertar(LineasCarritoDTO linea_carrito) {
        this.linea_carrito = linea_carrito;
        return super.insertar();
    }

    @Override
    public LineasCarritoDTO obtenerPorId(Integer id_usuario,Integer id_libro) {
        this.linea_carrito = new LineasCarritoDTO();
        
        UsuariosDTO usuario = new UsuariosDTO();
        usuario.setId_usuario(id_usuario);
        this.linea_carrito.setUsuario(usuario);
        
        LibrosDTO libro = new LibrosDTO();
        libro.setId_libro(id_libro);
        this.linea_carrito.setLibro(libro);
        
        super.obtenerPorId();
        return this.linea_carrito;
    }

    @Override
    public ArrayList<LineasCarritoDTO> listarTodos() {
        return (ArrayList<LineasCarritoDTO>) super.listarTodos();
    }

    @Override
    public Integer modificar(LineasCarritoDTO linea_carrito) {
        this.linea_carrito = linea_carrito;
        return super.modificar();
    }

    @Override
    public Integer eliminar(LineasCarritoDTO linea_carrito) {
        this.linea_carrito = linea_carrito;
        return super.eliminar();
    }
    
    @Override
    public ArrayList<LineasCarritoDTO> listarCarritoUsuario(Integer id_usuario){
        String sql = generarSqlParaListarCarrito();
        this.linea_carrito = new LineasCarritoDTO();
        UsuariosDTO usuario = new UsuariosDTO();
        usuario.setId_usuario(id_usuario);
        this.linea_carrito.setUsuario(usuario);
        return (ArrayList<LineasCarritoDTO>) super.listarTodos(sql, this::incluirValorDeParametrosParaListar, this.linea_carrito);
    }
    
    private void incluirValorDeParametrosParaListar(Object parametros){
        LineasCarritoDTO linea_carrito = (LineasCarritoDTO) parametros;
        try {
            this.statement.setInt(1, linea_carrito.getUsuario().getId_usuario());
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public void vaciarCarrito(Integer id_usuario){
        String sql = generarSqlParaVaciarCarrito();
        this.linea_carrito = new LineasCarritoDTO();
        UsuariosDTO usuario = new UsuariosDTO();
        usuario.setId_usuario(id_usuario);
        this.linea_carrito.setUsuario(usuario);
        super.ejecutarProcedimientoAlmacenado(sql, this::incluirValorDeParametrosParaVaciar, this.linea_carrito, true);
    }
    
    private void incluirValorDeParametrosParaVaciar(Object parametros){
        LineasCarritoDTO linea_carrito = (LineasCarritoDTO) parametros;
        try {
            this.statement.setInt(1, linea_carrito.getUsuario().getId_usuario());
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private String generarSqlParaVaciarCarrito(){
        String sql = "";
        sql += "DELETE FROM ";
        sql += "VEN_LINEAS_CARRITO ";
        sql += "WHERE ";
        sql += "ID_USUARIO = ?";
        return sql;
    }
    
    private String generarSqlParaListarCarrito(){
        String sql = "";
        sql += "SELECT ";
        sql += "L.ID_LIBRO, ";
        sql += "L.TITULO, ";
        sql += "L.PRECIO, ";
        sql += "C.CANTIDAD ";
        sql += "FROM ";
        sql += "VEN_LINEAS_CARRITO C ";
        sql += "JOIN VEN_LIBROS L ON L.ID_LIBRO = C.ID_LIBRO ";
        sql += "WHERE ";
        sql += "C.ID_USUARIO = ?";
        return sql;
    }
}
