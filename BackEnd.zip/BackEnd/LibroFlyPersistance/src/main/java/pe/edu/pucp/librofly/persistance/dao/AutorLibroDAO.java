/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pe.edu.pucp.librofly.persistance.dao;

import java.util.ArrayList;
import pe.edu.pucp.librofly.model.AutoresLibroDTO;

/**
 *
 * @author USUARIO
 */
public interface AutorLibroDAO {
    
    public Integer insertar(AutoresLibroDTO autor_libro);
    
    public ArrayList<AutoresLibroDTO> listarAutoresDeLibro(Integer id_libro);
    
    public Integer eliminar(AutoresLibroDTO autor);
}
