/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.model;

/**
 *
 * @author USUARIO
 */
public class EditorialesDTO {
    private Integer id_editorial;
    private String nombre;
    private String pais;
    
    public EditorialesDTO(){
        this.id_editorial = null;
        this.nombre = null;
        this.pais = null;
    }
    
    public EditorialesDTO(Integer id_editorial, String nombre, String pais){
        this.id_editorial = id_editorial;
        this.nombre = nombre;
        this.pais = pais;
    }

    /**
     * @return the id_editorial
     */
    public Integer getId_editorial() {
        return id_editorial;
    }

    /**
     * @param id_editorial the id_editorial to set
     */
    public void setId_editorial(Integer id_editorial) {
        this.id_editorial = id_editorial;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the pais
     */
    public String getPais() {
        return pais;
    }

    /**
     * @param pais the pais to set
     */
    public void setPais(String pais) {
        this.pais = pais;
    }
}
