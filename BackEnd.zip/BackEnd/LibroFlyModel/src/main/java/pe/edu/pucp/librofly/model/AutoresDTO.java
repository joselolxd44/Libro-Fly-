/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.model;

/**
 *
 * @author USUARIO
 */
public class AutoresDTO {
    private Integer id_autor;
    private String nombre_completo;
    
    public AutoresDTO(){
        this.id_autor = null;
        this.nombre_completo = null;
    }
    
    public AutoresDTO(Integer id_autor, String nombre_completo){
        this.id_autor = id_autor;
        this.nombre_completo = nombre_completo;
    }

    /**
     * @return the id_autor
     */
    public Integer getId_autor() {
        return id_autor;
    }

    /**
     * @param id_autor the id_autor to set
     */
    public void setId_autor(Integer id_autor) {
        this.id_autor = id_autor;
    }

//    /**
//     * @return the nombre
//     */
//    public String getNombre() {
//        return nombre;
//    }
//
//    /**
//     * @param nombre the nombre to set
//     */
//    public void setNombre(String nombre) {
//        this.nombre = nombre;
//    }
//
//    /**
//     * @return the apellidos
//     */
//    public String getApellidos() {
//        return apellidos;
//    }
//
//    /**
//     * @param apellidos the apellidos to set
//     */
//    public void setApellidos(String apellidos) {
//        this.apellidos = apellidos;
//    }
//
//    /**
//     * @return the pais
//     */
//    public String getPais() {
//        return pais;
//    }
//
//    /**
//     * @param pais the pais to set
//     */
//    public void setPais(String pais) {
//        this.pais = pais;
//    }

    /**
     * @return the nombre_completo
     */
    public String getNombre_completo() {
        return nombre_completo;
    }

    /**
     * @param nombre_completo the nombre_completo to set
     */
    public void setNombre_completo(String nombre_completo) {
        this.nombre_completo = nombre_completo;
    }
}
