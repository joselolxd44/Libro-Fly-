package pe.edu.pucp.librofly.model;

import java.util.Date;

public class PedidosDTO {
    private Integer id_pedido;
    private Date fecha;
    private Float total;
    private String estado;
    private Integer cantidad;
    private UsuariosDTO cliente;
    private MetodosPagoDTO metodo_pago;

    public PedidosDTO() {
        this.id_pedido = null;
        this.fecha = null;
        this.total = null;
        this.estado = null;
        this.cantidad = null;
        this.cliente = null;
        this.metodo_pago = null;
    }
    
    public PedidosDTO(Integer id_pedido, Date fecha, Float total, String estado, Integer cantidad, UsuariosDTO cliente, MetodosPagoDTO metodo_pago) {
        this.id_pedido = id_pedido;
        this.fecha = fecha;
        this.total = total;
        this.estado = estado;
        this.cantidad = cantidad;
        this.cliente = cliente;
        this.metodo_pago = metodo_pago;
    }

    /**
     * @return the id_pedido
     */
    public Integer getId_pedido() {
        return id_pedido;
    }

    /**
     * @param id_pedido the id_pedido to set
     */
    public void setId_pedido(Integer id_pedido) {
        this.id_pedido = id_pedido;
    }

    /**
     * @return the fecha
     */
    public Date getFecha() {
        return fecha;
    }

    /**
     * @param fecha the fecha to set
     */
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    /**
     * @return the total
     */
    public Float getTotal() {
        return total;
    }

    /**
     * @param total the total to set
     */
    public void setTotal(Float total) {
        this.total = total;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * @return the cantidad
     */
    public Integer getCantidad() {
        return cantidad;
    }

    /**
     * @param cantidad the cantidad to set
     */
    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    /**
     * @return the cliente
     */
    public UsuariosDTO getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(UsuariosDTO cliente_id) {
        this.cliente = cliente_id;
    }

    /**
     * @return the metodo_pago
     */
    public MetodosPagoDTO getMetodo_pago() {
        return metodo_pago;
    }

    /**
     * @param metodo_pago the metodo_pago to set
     */
    public void setMetodo_pago(MetodosPagoDTO metodo_pago) {
        this.metodo_pago = metodo_pago;
    }
    
    
}
