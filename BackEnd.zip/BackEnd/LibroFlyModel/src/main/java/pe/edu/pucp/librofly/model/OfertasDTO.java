/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.model;

/**
 *
 * @author USUARIO
 */
public class OfertasDTO {
    private Integer id_oferta;
//    private 
}
