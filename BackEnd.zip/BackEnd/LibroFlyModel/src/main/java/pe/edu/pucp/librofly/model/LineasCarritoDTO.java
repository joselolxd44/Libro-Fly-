/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.model;

/**
 *
 * @author USUARIO
 */
public class LineasCarritoDTO {
    private UsuariosDTO usuario;
    private LibrosDTO libro;
    private Integer cantidad;

    public LineasCarritoDTO(){
        this.usuario = null;
        this.libro = null;
        this.cantidad = null;
    }
    
    public LineasCarritoDTO(UsuariosDTO usuario,LibrosDTO libro, Integer cantidad){
        this.usuario = usuario;
        this.libro = libro;
        this.cantidad = cantidad;
    }
    /**
     * @return the usuario
     */
    public UsuariosDTO getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(UsuariosDTO usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the libro
     */
    public LibrosDTO getLibro() {
        return libro;
    }

    /**
     * @param libro the libro to set
     */
    public void setLibro(LibrosDTO libro) {
        this.libro = libro;
    }

    /**
     * @return the cantidad
     */
    public Integer getCantidad() {
        return cantidad;
    }

    /**
     * @param cantidad the cantidad to set
     */
    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }
}
