/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.model;

/**
 *
 * @author USUARIO
 */
public class AutoresLibroDTO {
    private AutoresDTO autor;
    private LibrosDTO libro;
    
    public AutoresLibroDTO(){
        this.autor = null;
        this.libro = null;
    }
    
    public AutoresLibroDTO(AutoresDTO autor, LibrosDTO libro){
        this.autor = autor;
        this.libro = libro;
    }

    /**
     * @return the autor
     */
    public AutoresDTO getAutor() {
        return autor;
    }

    /**
     * @param autor the autor to set
     */
    public void setAutor(AutoresDTO autor) {
        this.autor = autor;
    }

    /**
     * @return the libro
     */
    public LibrosDTO getLibro() {
        return libro;
    }

    /**
     * @param libro the libro to set
     */
    public void setLibro(LibrosDTO libro) {
        this.libro = libro;
    }
}
