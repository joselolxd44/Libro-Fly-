/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.model;

/**
 *
 * @author USUARIO
 */
public class CarritosDTO {
    private Integer id_carrito;
    private UsuariosDTO usuario;
    private Integer cantidad_lineas;
    
    public CarritosDTO(){
        this.id_carrito = null;
        this.usuario = null;
        this.cantidad_lineas = null;
    }
    
    public CarritosDTO(Integer id_carrito,UsuariosDTO usuario, Integer cantidad_lineas){
        this.id_carrito = id_carrito;
        this.usuario = usuario;
        this.cantidad_lineas = cantidad_lineas;
    }

    /**
     * @return the id_carrito
     */
    public Integer getId_carrito() {
        return id_carrito;
    }

    /**
     * @param id_carrito the id_carrito to set
     */
    public void setId_carrito(Integer id_carrito) {
        this.id_carrito = id_carrito;
    }

    /**
     * @return the usuario
     */
    public UsuariosDTO getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(UsuariosDTO usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the cantidad_lineas
     */
    public Integer getCantidad_lineas() {
        return cantidad_lineas;
    }

    /**
     * @param cantidad_lineas the cantidad_lineas to set
     */
    public void setCantidad_lineas(Integer cantidad_lineas) {
        this.cantidad_lineas = cantidad_lineas;
    }
}
