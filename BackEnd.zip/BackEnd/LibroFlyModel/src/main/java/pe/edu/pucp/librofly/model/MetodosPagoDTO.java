package pe.edu.pucp.librofly.model;

public class MetodosPagoDTO {
    private Integer id_metodo_pago;
    private String tipo_metodo;
    
    public MetodosPagoDTO() {
        this.id_metodo_pago = null;
        this.tipo_metodo = null;
    }

    public MetodosPagoDTO(Integer id_metodo_pago, String tipo_metodo) {
        this.id_metodo_pago = id_metodo_pago;
        this.tipo_metodo = tipo_metodo;
    }
    
    /**
     * @return the id_metodo_pago
     */
    public Integer getId_metodo_pago() {
        return id_metodo_pago;
    }

    /**
     * @param id_metodo_pago the id_metodo_pago to set
     */
    public void setId_metodo_pago(Integer id_metodo_pago) {
        this.id_metodo_pago = id_metodo_pago;
    }

    /**
     * @return the tipo_metodo
     */
    public String getTipo_metodo() {
        return tipo_metodo;
    }

    /**
     * @param tipo_metodo the tipo_metodo to set
     */
    public void setTipo_metodo(String tipo_metodo) {
        this.tipo_metodo = tipo_metodo;
    }
    
    
}

