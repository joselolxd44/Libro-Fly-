package pe.edu.pucp.librofly.model;

public class LibrosDTO {
    private Integer id_libro;
    private String titulo;
    private String descripcion;
    private String editorial;
    private Integer anho;
    private Float peso;
    private Float ancho;
    private Float alto;
    private Integer numero_paginas;
    private String formato;
    private String isbn;
    private Float precio;
    private Integer stock;
    private String url_portada;
    private GenerosDTO genero;
    
    public LibrosDTO() {
        this.id_libro = null;
        this.titulo = null;
        this.descripcion = null;
        this.editorial = null;
        this.anho = null;
        this.peso = null;
        this.ancho = null;
        this.alto = null;
        this.numero_paginas = null;
        this.formato = null;
        this.isbn = null;
        this.precio = null;
        this.stock = null;
        this.url_portada = null;
        this.genero = null;
    }

    public LibrosDTO(Integer id_libro, String titulo, String descripcion,
            String editorial, Integer anho, Float peso, Float ancho, Float alto,
            Integer numero_paginas, String formato, String isbn, Float precio, 
            Integer stock, String url_portada, GenerosDTO genero) {
        this.id_libro = id_libro;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.editorial = editorial;
        this.anho = anho;
        this.peso = peso;
        this.ancho = ancho;
        this.alto = alto;
        this.numero_paginas = numero_paginas;
        this.formato = formato;
        this.isbn = isbn;
        this.precio = precio;
        this.stock = stock;
        this.url_portada = url_portada;
        this.genero = genero;
    }
    
    /**
     * @return the id_libro
     */
    public Integer getId_libro() {
        return id_libro;
    }

    /**
     * @param id_libro the id_libro to set
     */
    public void setId_libro(Integer id_libro) {
        this.id_libro = id_libro;
    }

    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo the titulo to set
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

//    /**
//     * @return the autor
//     */
//    public AutoresDTO getAutor() {
//        return autor;
//    }
//
//    /**
//     * @param autor the autor to set
//     */
//    public void setAutor(AutoresDTO autor) {
//        this.autor = autor;
//    }

    /**
     * @return the editorial
     */
    public String getEditorial() {
        return editorial;
    }

    /**
     * @param editorial the editorial to set
     */
    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    /**
     * @return the isbn
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * @param isbn the isbn to set
     */
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    /**
     * @return the precio
     */
    public Float getPrecio() {
        return this.precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    /**
     * @return the stock
     */
    public Integer getStock() {
        return this.stock;
    }

    /**
     * @param stock the stock to set
     */
    public void setStock(Integer stock) {
        this.stock = stock;
    }

//    /**
//     * @return the disponibilidad
//     */
//    public String getDisponibilidad() {
//        return disponibilidad;
//    }
//
//    /**
//     * @param disponibilidad the disponibilidad to set
//     */
//    public void setDisponibilidad(String disponibilidad) {
//        this.disponibilidad = disponibilidad;
//    }

    /**
     * @return the url_portada
     */
    public String getUrl_portada() {
        return url_portada;
    }

    /**
     * @param url_portada the url_portada to set
     */
    public void setUrl_portada(String url_portada) {
        this.url_portada = url_portada;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return the anho
     */
    public Integer getAnho() {
        return anho;
    }

    /**
     * @param anho the anho to set
     */
    public void setAnho(Integer anho) {
        this.anho = anho;
    }

    /**
     * @return the peso
     */
    public Float getPeso() {
        return peso;
    }

    /**
     * @param peso the peso to set
     */
    public void setPeso(Float peso) {
        this.peso = peso;
    }

    /**
     * @return the ancho
     */
    public Float getAncho() {
        return ancho;
    }

    /**
     * @param ancho the ancho to set
     */
    public void setAncho(Float ancho) {
        this.ancho = ancho;
    }

    /**
     * @return the alto
     */
    public Float getAlto() {
        return alto;
    }

    /**
     * @param alto the alto to set
     */
    public void setAlto(Float alto) {
        this.alto = alto;
    }

    /**
     * @return the formato
     */
    public String getFormato() {
        return formato;
    }

    /**
     * @param formato the formato to set
     */
    public void setFormato(String formato) {
        this.formato = formato;
    }

    /**
     * @return the numero_paginas
     */
    public Integer getNumero_paginas() {
        return numero_paginas;
    }

    /**
     * @param numero_paginas the numero_paginas to set
     */
    public void setNumero_paginas(Integer numero_paginas) {
        this.numero_paginas = numero_paginas;
    }

    /**
     * @return the genero
     */
    public GenerosDTO getGenero() {
        return genero;
    }

    /**
     * @param genero the genero to set
     */
    public void setGenero(GenerosDTO genero) {
        this.genero = genero;
    }
    
    
}
