/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.model;

/**
 *
 * @author USUARIO
 */
public class LibroGeneroDTO {
    private LibrosDTO libro;
    private GenerosDTO genero;

    public LibroGeneroDTO(){
        this.libro = null;
        this.genero = null;
    }
    
    public LibroGeneroDTO(LibrosDTO libro, GenerosDTO genero){
        this.libro = libro;
        this.genero = genero;
    }
    
    /**
     * @return the libro
     */
    public LibrosDTO getLibro() {
        return libro;
    }

    /**
     * @param libro the libro to set
     */
    public void setLibro(LibrosDTO libro) {
        this.libro = libro;
    }

    /**
     * @return the genero
     */
    public GenerosDTO getGenero() {
        return genero;
    }

    /**
     * @param genero the genero to set
     */
    public void setGenero(GenerosDTO genero) {
        this.genero = genero;
    }
}
