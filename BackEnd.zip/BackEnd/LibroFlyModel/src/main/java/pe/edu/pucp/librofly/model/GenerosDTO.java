package pe.edu.pucp.librofly.model;

public class GenerosDTO {
    private Integer id_genero;
    private String descripcion;
    private GenerosDTO genero_principal_id;
    
    public GenerosDTO() {
        this.id_genero = null;
        this.descripcion = null;
        this.genero_principal_id = null;
    }

    public GenerosDTO(Integer id_genero, String descripcion, GenerosDTO genero_principal_id) {
        this.id_genero = id_genero;
        this.descripcion = descripcion;
        this.genero_principal_id = genero_principal_id;
    }

    /**
     * @return the id_genero
     */
    public Integer getId_genero() {
        return id_genero;
    }

    /**
     * @param id_genero the id_genero to set
     */
    public void setId_genero(Integer id_genero) {
        this.id_genero = id_genero;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return the genero_principal_id
     */
    public GenerosDTO getGenero_principal_id() {
        return genero_principal_id;
    }

    /**
     * @param genero_principal_id the genero_principal_id to set
     */
    public void setGenero_principal_id(GenerosDTO genero_principal_id) {
        this.genero_principal_id = genero_principal_id;
    }
    
    
    
}
