/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.librofly.model;

/**
 *
 * @author USUARIO
 */
public class LineasPedidoDTO {
    private PedidosDTO pedido;
    private LibrosDTO libro;
    private Integer cantidad;
    private Float subtotal;

    public LineasPedidoDTO(){
        this.pedido = null;
        this.libro = null;
        this.cantidad = null;
        this.subtotal = null;
    }
    
    public LineasPedidoDTO(PedidosDTO pedido, LibrosDTO libro, Integer cantidad,
            Float subtotal){
        this.pedido = pedido;
        this.libro = libro;
        this.cantidad = cantidad;
        this.subtotal = subtotal;
    }
    
    /**
     * @return the id_pedido
     */
    public PedidosDTO getPedido() {
        return pedido;
    }

    /**
     * @param pedido the pedido to set
     */
    public void setPedido(PedidosDTO pedido) {
        this.pedido = pedido;
    }

    /**
     * @return the libro
     */
    public LibrosDTO getLibro() {
        return libro;
    }

    /**
     * @param libro the libro to set
     */
    public void setLibro(LibrosDTO libro) {
        this.libro = libro;
    }

    /**
     * @return the cantidad
     */
    public Integer getCantidad() {
        return cantidad;
    }

    /**
     * @param cantidad the cantidad to set
     */
    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    /**
     * @return the subtotal
     */
    public Float getSubtotal() {
        return subtotal;
    }

    /**
     * @param subtotal the subtotal to set
     */
    public void setSubtotal(Float subtotal) {
        this.subtotal = subtotal;
    }
    
    
}
