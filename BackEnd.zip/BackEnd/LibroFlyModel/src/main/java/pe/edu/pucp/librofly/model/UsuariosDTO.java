package pe.edu.pucp.librofly.model;

public class UsuariosDTO {

    private Integer id_usuario;
    private String correo;
    private String contrasenha;
    private String nombres;
    private String apellidos;
    private String direccion_envio;
    private String telefono;
    private TipoDocumento tipo_documento;
    private String numero_documento;
    private String rol; //Para administrador
    private String tipo;
    
    public UsuariosDTO() {
        this.id_usuario = null;
        this.correo = null;
        this.contrasenha = null;
        this.nombres = null;
        this.apellidos = null;
        this.direccion_envio = null;
        this.telefono = null;
        this.tipo_documento = null;
        this.numero_documento = null;
        this.rol = null;
        this.tipo = null;
    }

    public UsuariosDTO(Integer id_usuario, String correo, String contrasenha, String nombres, String apellidos,
            String direccion_envio, String telefono, TipoDocumento tipo_documento, String numero_documento, String rol, String tipo) {
        this.id_usuario = id_usuario;
        this.correo = correo;
        this.contrasenha = contrasenha;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.direccion_envio = direccion_envio;
        this.telefono = telefono;
        this.tipo_documento = tipo_documento;
        this.numero_documento = numero_documento;
        this.rol = rol;
        this.tipo = tipo;
    }

    /**
     * @return the id_usuario
     */
    public Integer getId_usuario() {
        return id_usuario;
    }

    /**
     * @param id_usuario the id_usuario to set
     */
    public void setId_usuario(Integer id_usuario) {
        this.id_usuario = id_usuario;
    }

    /**
     * @return the correo
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * @param correo the correo to set
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * @return the contrasenha
     */
    public String getContrasenha() {
        return contrasenha;
    }

    /**
     * @param contrasenha the contrasenha to set
     */
    public void setContrasenha(String contrasenha) {
        this.contrasenha = contrasenha;
    }

    /**
     * @return the nombres
     */
    public String getNombres() {
        return nombres;
    }

    /**
     * @param nombres the nombres to set
     */
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    /**
     * @return the apellidos
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * @param apellidos the apellidos to set
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    /**
     * @return the direccion_envio
     */
    public String getDireccion_envio() {
        return direccion_envio;
    }

    /**
     * @param direccion_envio the direccion_envio to set
     */
    public void setDireccion_envio(String direccion_envio) {
        this.direccion_envio = direccion_envio;
    }

    /**
     * @return the telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * @param telefono the telefono to set
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * @return the tipo_documento
     */
    public TipoDocumento getTipo_documento() {
        return tipo_documento;
    }

    /**
     * @param tipo_documento the tipo_documento to set
     */
    public void setTipo_documento(TipoDocumento tipo_documento) {
        this.tipo_documento = tipo_documento;
    }

    /**
     * @return the numero_documento
     */
    public String getNumero_documento() {
        return numero_documento;
    }

    /**
     * @param numero_documento the numero_documento to set
     */
    public void setNumero_documento(String numero_documento) {
        this.numero_documento = numero_documento;
    }

    /**
     * @return the rol
     */
    public String getRol() {
        return rol;
    }

    /**
     * @param rol the rol to set
     */
    public void setRol(String rol) {
        this.rol = rol;
    }

    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    

}
