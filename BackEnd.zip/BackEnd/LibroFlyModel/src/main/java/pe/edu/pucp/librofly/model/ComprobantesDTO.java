package pe.edu.pucp.librofly.model;

public class ComprobantesDTO {
    private Integer id_comprobante;
    private String tipo;
    private String numero_serie;
    private String ruc_cliente;
    private String razon_social;
    private PedidosDTO pedido_id;
    
    public ComprobantesDTO() {
        this.id_comprobante = null;
        this.tipo = null;
        this.numero_serie = null;
        this.ruc_cliente = null;
        this.razon_social = null;
        this.pedido_id = null;
    }

    public ComprobantesDTO(Integer id_comprobante, String tipo, String numero_serie, 
            String ruc_cliente, String razon_social, PedidosDTO pedido_id) {
        this.id_comprobante = id_comprobante;
        this.tipo = tipo;
        this.numero_serie = numero_serie;
        this.ruc_cliente = ruc_cliente;
        this.razon_social = razon_social;
        this.pedido_id = pedido_id;
    }

    /**
     * @return the id_comprobante
     */
    public Integer getId_comprobante() {
        return id_comprobante;
    }

    /**
     * @param id_comprobante the id_comprobante to set
     */
    public void setId_comprobante(Integer id_comprobante) {
        this.id_comprobante = id_comprobante;
    }

    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the numero_serie
     */
    public String getNumero_serie() {
        return numero_serie;
    }

    /**
     * @param numero_serie the numero_serie to set
     */
    public void setNumero_serie(String numero_serie) {
        this.numero_serie = numero_serie;
    }

    /**
     * @return the pedido_id
     */
    public PedidosDTO getPedido_id() {
        return pedido_id;
    }

    /**
     * @param pedido_id the pedido_id to set
     */
    public void setPedido_id(PedidosDTO pedido_id) {
        this.pedido_id = pedido_id;
    }

    /**
     * @return the ruc_cliente
     */
    public String getRuc_cliente() {
        return ruc_cliente;
    }

    /**
     * @param ruc_cliente the ruc_cliente to set
     */
    public void setRuc_cliente(String ruc_cliente) {
        this.ruc_cliente = ruc_cliente;
    }

    /**
     * @return the razon_social
     */
    public String getRazon_social() {
        return razon_social;
    }

    /**
     * @param razon_social the razon_social to set
     */
    public void setRazon_social(String razon_social) {
        this.razon_social = razon_social;
    }
    
    
}
