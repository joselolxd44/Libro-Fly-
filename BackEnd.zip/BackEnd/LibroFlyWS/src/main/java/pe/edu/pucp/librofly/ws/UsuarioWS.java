/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package pe.edu.pucp.librofly.ws;

import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.xml.ws.WebServiceException;
import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.librofly.bo.PedidoBO;
import pe.edu.pucp.librofly.bo.UsuarioBO;
import pe.edu.pucp.librofly.db.util.Cifrado;
import pe.edu.pucp.librofly.model.GenerosDTO;
import pe.edu.pucp.librofly.model.PedidosDTO;
import pe.edu.pucp.librofly.model.TipoDocumento;
import pe.edu.pucp.librofly.model.UsuariosDTO;

/**
 *
 * @author pied
 */
@WebService(serviceName = "UsuarioWS")
public class UsuarioWS {

    private final UsuarioBO usuarioBo;

    public UsuarioWS() {
        usuarioBo = new UsuarioBO();
    }

    @WebMethod(operationName = "verificarSesion")
    public Integer iniciarSesion(@WebParam(name = "correo") String correo, @WebParam(name = "contrasenha") String contrasenha) {
        try {
            return usuarioBo.iniciarSesion(correo, contrasenha);
        } catch (Exception ex) {
            throw new WebServiceException("Error al iniciar sesion: " + ex.getMessage());
        }
    }

    @WebMethod(operationName = "obtenerUsuarioPorId")
    public UsuariosDTO obtenerUsuarioPorId(@WebParam(name = "idUsuario") Integer id) {
        try {
            UsuariosDTO usuario = this.usuarioBo.obtenerPorId(id);
            return usuario;
        } catch (Exception ex) {
            throw new WebServiceException("Error al obtener usuario: " + ex.getMessage());
        }
    }

    @WebMethod(operationName = "listarPedidosUsuario")
    public List<PedidosDTO> listarPedidosUsuario(@WebParam(name = "usuario")Integer id_usuario) {
        try {
            PedidoBO pedido = new PedidoBO();
            return pedido.visualizarHistorialDeUsuario(id_usuario);
        } catch (Exception ex) {
            throw new WebServiceException("Error al listar pedidos: " + ex.getMessage());
        }
    }

    @WebMethod(operationName = "regitrarUsuario")
    public Integer regitrarNuevoUsuario(String correo, String contrasenha, String nombres, 
            String apellidos, String direccion_envio, String telefono, String tipo_documento, String numero_documento, String rol, String tipo) {
        try {
            return this.usuarioBo.registrarUsuario(correo, contrasenha, nombres, apellidos, direccion_envio, telefono, tipo_documento, numero_documento, rol, tipo);
        } catch (Exception ex) {
            throw new WebServiceException("Error al regitrar usuario: " + ex.getMessage());
        }
    }

    @WebMethod(operationName = "editarPerfil")
    public Integer editarPerfil(Integer id_usuario, String nombres, String apellidos, 
            String direccion_envio, String telefono, String tipo_documento, String numero_documento) {
        try {
            return this.usuarioBo.editarPerfil(id_usuario, nombres, apellidos, direccion_envio, telefono, tipo_documento, numero_documento);
        } catch (Exception ex) {
            throw new WebServiceException("Error al editar perfil: " + ex.getMessage());
        }
    }

    @WebMethod(operationName = "generosPorUsuario")
    public ArrayList<GenerosDTO> generosPorUsuario(@WebParam(name = "id")Integer id_usuario) {
        try {
            return this.usuarioBo.listarGenerosUsuario(id_usuario);
        } catch (Exception ex) {
            throw new WebServiceException("Error al generar listado: " + ex.getMessage());
        }
    }
    
    @WebMethod(operationName = "listarTiposDocumento")
    public ArrayList<String> listarTiposDocumento() {
        try {
            return this.usuarioBo.listarTiposDocumento();
        } catch (Exception ex) {
            throw new WebServiceException("Error al listar los tipos de documento: " + ex.getMessage());
        }
    }
}
