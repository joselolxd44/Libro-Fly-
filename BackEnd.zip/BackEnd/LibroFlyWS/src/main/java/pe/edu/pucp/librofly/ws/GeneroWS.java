/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package pe.edu.pucp.librofly.ws;

import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.xml.ws.WebServiceException;
import java.util.ArrayList;
import pe.edu.pucp.librofly.bo.GeneroBO;
import pe.edu.pucp.librofly.model.GenerosDTO;
/**
 *
 * @author pied
 */
@WebService(serviceName = "GeneroWS")
public class GeneroWS {
    private final GeneroBO generoBO;
    public GeneroWS() { 
        generoBO = new GeneroBO();
    }
    @WebMethod(operationName = "listarGeneros")
    public ArrayList<GenerosDTO> listarGeneros() { 
        try {
            return generoBO.generos();
        } catch(Exception ex){
            throw new WebServiceException("Error al listar generos: " + ex.getMessage());
        }
    }
}
