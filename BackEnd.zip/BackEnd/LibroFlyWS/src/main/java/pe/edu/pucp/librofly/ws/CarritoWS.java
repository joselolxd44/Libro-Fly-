/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package pe.edu.pucp.librofly.ws;

import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import java.util.ArrayList;
import jakarta.xml.ws.WebServiceException;
import pe.edu.pucp.librofly.bo.CarritoBO;
import pe.edu.pucp.librofly.model.LineasCarritoDTO;

/**
 *
 * @author USUARIO
 */
@WebService(serviceName = "CarritoWS")
public class CarritoWS {
    private final CarritoBO carritoBO;
    /**
     * This is a sample web service operation
     */
    public CarritoWS(){
        this.carritoBO = new CarritoBO();
    }
    
    @WebMethod(operationName = "insertarLineaCarrito")
    public Integer insertarLineaCarrito(Integer id_usuario, Integer id_libro, Integer cantidad) {
        try {
            return this.carritoBO.insertarLineaCarrito(id_usuario, id_libro, cantidad);
        }catch(Exception ex) {
            throw new WebServiceException("Error al insertar linea carrito: " + ex.getMessage());
        }
    }
    
    @WebMethod(operationName = "modificarLineaCarrito")
    public Integer modificarLineaCarrito(Integer id_usuario, Integer id_libro, Integer cantidad) {
        try {
            return this.carritoBO.modificarLineaCarrito(id_usuario, id_libro,cantidad);
        }catch(Exception ex) {
            throw new WebServiceException("Error al modificar linea carrito: " + ex.getMessage());
        }
    }
    
    @WebMethod(operationName = "eliminarLineaCarrito")
    public Integer eliminarLineaCarrito(Integer id_usuario, Integer id_libro) {
        try {
            return this.carritoBO.eliminarLineaCarrito(id_usuario, id_libro);
        }catch(Exception ex) {
            throw new WebServiceException("Error al eliminar linea carrito: " + ex.getMessage());
        }
    }
    
    @WebMethod(operationName = "vaciarCarrito")
    public Integer vaciarCarrito(Integer id_usuario) {
        try {
            return this.carritoBO.vaciarCarrito(id_usuario);
        }catch(Exception ex) {
            throw new WebServiceException("Error al eliminar linea carrito: " + ex.getMessage());
        }
    }
    
    @WebMethod(operationName = "listarCarritoUsuario")
    public ArrayList<LineasCarritoDTO> listarCarritoUsuario(Integer id_usuario) {
        try {
            return this.carritoBO.listarCarritoUsuario(id_usuario);
        }catch(Exception ex) {
            throw new WebServiceException("Error al eliminar linea carrito: " + ex.getMessage());
        }
    }
}
