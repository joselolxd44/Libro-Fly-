/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package pe.edu.pucp.librofly.ws;

import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.xml.ws.WebServiceException;
import java.util.ArrayList;
import pe.edu.pucp.librofly.bo.LibroBO;
import pe.edu.pucp.librofly.model.AutoresDTO;
import pe.edu.pucp.librofly.model.AutoresLibroDTO;
import pe.edu.pucp.librofly.model.LibrosDTO;
/**
 *
 * @author pied
 */

@WebService(serviceName = "LibroWS")
public class LibroWS {
    private final LibroBO libroBo;
    public LibroWS() {
        this.libroBo = new LibroBO();
    }
    
    @WebMethod(operationName = "insertarLibro")
    public Integer insertarLibro(String titulo, String descripcion, Integer anho, 
            Float peso, Float ancho, Float alto, Integer numero_paginas, 
            String formato, String autor, String editorial, String isbn, 
            Float precio, Integer stock, String url_portada, Integer id_genero) { 
        try {
            return libroBo.Insertar(titulo, descripcion, anho, peso, ancho, alto, 
                    numero_paginas, formato, autor, editorial, isbn, precio, stock, url_portada, id_genero);
        }catch(Exception ex) {
            throw new WebServiceException("Error al insertar libro: " + ex.getMessage());
        }
    }
    
    @WebMethod(operationName = "eliminarLibro")
    public Integer eliminarLibro(Integer id_libro) { 
        try {
            return libroBo.Eliminar(id_libro);
        }catch(Exception ex) {
            throw new WebServiceException("Error al insertar libro: " + ex.getMessage());
        }
    }
    
    @WebMethod(operationName = "listarLibros")
    public ArrayList<LibrosDTO> listarLibros() { 
        try {
            return libroBo.visualizarCatalogo();
        } catch(Exception ex){
            throw new WebServiceException("Error al listar libros: " + ex.getMessage());
        }
    }
    
    @WebMethod(operationName = "obtenerLibroPorId")
    public LibrosDTO obtenerLibroPorId(@WebParam(name = "libro_id") int libro_id) {
        try {
            return libroBo.ObtenerPorId(libro_id);
        } catch(Exception ex){
            throw new WebServiceException("Error al listar libros: " + ex.getMessage());
        }
    }
    
    @WebMethod(operationName = "modificarLibro")
    public Integer modificarLibro(Integer id_libro, Float precio, Integer stock) { 
        try { 
            return libroBo.Modificar(id_libro, precio, stock);
        }catch (Exception ex) { 
            throw new WebServiceException("Error al listar libros: " + ex.getMessage());
        }
    }
    
    public ArrayList<AutoresLibroDTO> listarAutoresLibro(Integer id_libro){
        return libroBo.listarAutoresLibro(id_libro);
    } 
}
